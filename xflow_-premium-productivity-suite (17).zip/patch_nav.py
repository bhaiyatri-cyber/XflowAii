with open('app/src/main/java/com/example/ui/Navigation.kt', 'r') as f:
    content = f.read()

if 'const val DAILY_REPORT = "daily_report"' not in content:
    content = content.replace(
        'const val OVERTIME = "overtime"',
        'const val OVERTIME = "overtime"\n    const val DAILY_REPORT = "daily_report"'
    )

    nav_target = '        composable(Routes.OVERTIME) {\n            OvertimeScreen(viewModel = viewModel, onBack = { navController.popBackStack() })\n        }'
    nav_replacement = nav_target + '\n        composable(Routes.DAILY_REPORT) {\n            DailyReportScreen(viewModel = viewModel, onBack = { navController.popBackStack() })\n        }'
    
    content = content.replace(nav_target, nav_replacement)
    
    with open('app/src/main/java/com/example/ui/Navigation.kt', 'w') as f:
        f.write(content)
    print("Patched Navigation.kt")
else:
    print("Already patched Navigation.kt")
