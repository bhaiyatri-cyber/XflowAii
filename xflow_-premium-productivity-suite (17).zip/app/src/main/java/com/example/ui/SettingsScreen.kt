package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AvTimer
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.XFlowViewModel

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToPdf: () -> Unit, onNavigateToPermissions: () -> Unit, onNavigateToAbout: () -> Unit, onNavigateToBackup: () -> Unit, onNavigateToThemeSettings: () -> Unit, onNavigateToOvertime: () -> Unit,  onNavigateToChatbot: () -> Unit, onNavigateToDataDrive: () -> Unit, onNavigateToYouTube: () -> Unit, onNavigateToChatGPT: () -> Unit, onNavigateToDailyReport: () -> Unit = {}) {
    var showStatsDialog by remember { mutableStateOf(false) }
    val todayHours by viewModel.todayHours.collectAsStateWithLifecycle()
    val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    var showPremiumDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(24.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.AvTimer,
                    contentDescription = "XFlow Logo",
                    tint = XFlowAccent,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "XFlow",
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Version 1.0.0",
                    color = XFlowTextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Spacer(modifier = Modifier.height(32.dp))
            
            
            SettingsSection("Data & Web") {
                SettingsItem(icon = Icons.Filled.Public, title = "Data Drive", subtitle = "Secure In-App Browser & Storage", onClick = onNavigateToDataDrive)
                SettingsItem(icon = Icons.Filled.PlayCircle, title = "YouTube", subtitle = "Watch videos in full screen", onClick = onNavigateToYouTube)
                SettingsItem(icon = Icons.Filled.Chat, title = "ChatGPT", subtitle = "AI Chat Assistant", onClick = onNavigateToChatGPT)
            }
            SettingsSection("XFlow AI (New)") {
                
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.Info, title = "Chatbot", onClick = onNavigateToChatbot)
            }
            SettingsSection("Permissions") {
                SettingsItem(icon = Icons.Default.Security, title = "Manage Permissions", onClick = onNavigateToPermissions)
            }
            SettingsSection("Personalization") {
                SettingsItem(icon = Icons.Default.Build, title = "Theme & Appearance", onClick = onNavigateToThemeSettings)
            }
            SettingsSection("App Details") {
                SettingsItem(icon = Icons.Default.Info, title = "App Version", subtitle = "1.1.1 (Build 1)", onClick = { showStatsDialog = true })
            }
            SettingsSection("Tools / Utilities") {
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "24h Daily Report", subtitle = "Study vs Wasted Time", onClick = onNavigateToDailyReport)
                SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { if (isPremium) onNavigateToPdf() else showPremiumDialog = true })
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "🔥 Overtime (PRO)", onClick = { if (isPremium) onNavigateToOvertime() else showPremiumDialog = true })
                SettingsItem(icon = Icons.Default.Build, title = "Backup & Restore", onClick = onNavigateToBackup)
            }
            SettingsSection("About / Branding") {
                SettingsItem(icon = Icons.Default.Info, title = "About XFlow", onClick = onNavigateToAbout)
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showPremiumDialog) {
        AlertDialog(
            onDismissRequest = { showPremiumDialog = false },
            title = { Text("Premium Feature", color = XFlowTextPrimary) },
            text = { Text("This feature is only available for Premium users. Please upgrade from the Home screen.", color = XFlowTextSecondary) },
            confirmButton = {
                TextButton(onClick = { showPremiumDialog = false }) {
                    Text("OK", color = XFlowAccent)
                }
            },
            containerColor = XFlowSurface
        )
    }
    if (showStatsDialog) {
        AlertDialog(
            onDismissRequest = { showStatsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AvTimer, contentDescription = "Logo", tint = XFlowAccent, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("App Stats", color = XFlowTextPrimary)
                }
            },
            text = {
                Column {
                    Text("Today's Focus: ${String.format("%.1f", todayHours)}h", color = XFlowTextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Lifetime Focus: ${String.format("%.1f", lifetimeHours)}h", color = XFlowTextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Total Sessions: ${history.size}", color = XFlowTextPrimary)
                }
            },
            confirmButton = {
                TextButton(onClick = { showStatsDialog = false }) {
                    Text("Cool!", color = XFlowAccent)
                }
            },
            containerColor = XFlowSurface,
            titleContentColor = XFlowTextPrimary,
            textContentColor = XFlowTextSecondary
        )
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            text = title,
            color = XFlowAccent,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp, start = 8.dp)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(XFlowSurface)
        ) {
            content()
        }
    }
}

@Composable
fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = XFlowTextSecondary, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = XFlowTextPrimary, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, color = XFlowTextSecondary, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
