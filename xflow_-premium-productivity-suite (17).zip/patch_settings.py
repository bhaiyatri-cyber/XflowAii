with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

target = """fun SettingsScreen(
    viewModel: XFlowViewModel,
    onBack: () -> Unit,
    onNavigateToPdf: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onNavigateToThemeSettings: () -> Unit,
    onNavigateToBackup: () -> Unit,
    onNavigateToOvertime: () -> Unit,
    onNavigateToChatbot: () -> Unit,
    onNavigateToDataDrive: () -> Unit,
    onNavigateToYouTube: () -> Unit,
    onNavigateToChatGPT: () -> Unit
) {"""

replacement = """fun SettingsScreen(
    viewModel: XFlowViewModel,
    onBack: () -> Unit,
    onNavigateToPdf: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onNavigateToThemeSettings: () -> Unit,
    onNavigateToBackup: () -> Unit,
    onNavigateToOvertime: () -> Unit,
    onNavigateToChatbot: () -> Unit,
    onNavigateToDataDrive: () -> Unit,
    onNavigateToYouTube: () -> Unit,
    onNavigateToChatGPT: () -> Unit,
    onNavigateToDailyReport: () -> Unit = {}
) {"""

content = content.replace(target, replacement)

target2 = """            SettingsSection("Tools / Utilities") {
                SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { if (isPremium) onNavigateToPdf() else showPremiumDialog = true })
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "🔥 Overtime (PRO)", onClick = { if (isPremium) onNavigateToOvertime() else showPremiumDialog = true })
                SettingsItem(icon = Icons.Default.Build, title = "Backup & Restore", onClick = onNavigateToBackup)
            }"""

replacement2 = """            SettingsSection("Tools / Utilities") {
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "24h Daily Report", subtitle = "Study vs Wasted Time", onClick = onNavigateToDailyReport)
                SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { if (isPremium) onNavigateToPdf() else showPremiumDialog = true })
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "🔥 Overtime (PRO)", onClick = { if (isPremium) onNavigateToOvertime() else showPremiumDialog = true })
                SettingsItem(icon = Icons.Default.Build, title = "Backup & Restore", onClick = onNavigateToBackup)
            }"""

content = content.replace(target2, replacement2)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)
print("Patched SettingsScreen.kt")
