with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

target = """            if (history.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No history yet.", color = XFlowTextSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(history) { session ->
                        HistoryCard(session, cardStyle = cardStyle)
                    }
                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }"""

replacement = """            if (history.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No history yet.", color = XFlowTextSecondary)
                }
            } else {
                val groupedHistory = history.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }.toSortedMap(compareByDescending { 
                    try { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).parse(it)?.time ?: 0L } catch(e: Exception) { 0L }
                })
                var expandedDates by remember { mutableStateOf(setOf(SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date()))) }
                
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    groupedHistory.forEach { (dateStr, sessions) ->
                        item {
                            val isExpanded = expandedDates.contains(dateStr)
                            val totalTime = sessions.sumOf { it.timeStudiedSeconds }
                            val hours = totalTime / 3600
                            val mins = (totalTime % 3600) / 60
                            val timeStr = if (hours > 0) "${hours}h ${mins}m" else "${mins}m"
                            
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    expandedDates = if (isExpanded) expandedDates - dateStr else expandedDates + dateStr
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = XFlowSurface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp).fillMaxWidth(), 
                                    horizontalArrangement = Arrangement.SpaceBetween, 
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(if (dateStr == SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())) "Today" else dateStr, color = XFlowTextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("${sessions.size} tasks • $timeStr", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Icon(
                                        imageVector = if (isExpanded) androidx.compose.material.icons.Icons.Default.run { androidx.compose.material.icons.filled.KeyboardArrowUp } else androidx.compose.material.icons.Icons.Default.run { androidx.compose.material.icons.filled.KeyboardArrowDown },
                                        contentDescription = "Toggle",
                                        tint = XFlowTextSecondary
                                    )
                                }
                            }
                        }
                        if (expandedDates.contains(dateStr)) {
                            items(sessions.sortedByDescending { it.date }) { session ->
                                Box(modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp)) {
                                    HistoryCard(session, cardStyle = cardStyle)
                                }
                            }
                            item { Spacer(modifier = Modifier.height(8.dp)) }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }"""

if 'import androidx.compose.material.icons.filled.KeyboardArrowDown' not in content:
    content = content.replace('import androidx.compose.material.icons.filled.ArrowBack', 'import androidx.compose.material.icons.filled.ArrowBack\nimport androidx.compose.material.icons.filled.KeyboardArrowDown\nimport androidx.compose.material.icons.filled.KeyboardArrowUp')

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
print("Patched HistoryScreen")
