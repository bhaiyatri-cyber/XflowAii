package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.serialization.json.*

class AiViewModel(application: Application) : AndroidViewModel(application) {
    private val db = XFlowDatabase.getDatabase(application)
    val currentSessionId = MutableStateFlow("default")
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val aiChats = currentSessionId.flatMapLatest { sessionId ->
        db.dao().getAllAiChats(sessionId)
    }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isGenerating = MutableStateFlow(false)

    
    val allSessions = db.dao().getAiChatSessions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allMockTests = db.dao().getAllMockTests().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun loadSession(sessionId: String) {
        currentSessionId.value = sessionId
    }
    
    fun createNewSession() {
        currentSessionId.value = "session_" + System.currentTimeMillis()
    }
    
    fun clearChat() {
        viewModelScope.launch {
            db.dao().deleteAllAiChats(currentSessionId.value)
        }
    }

    fun sendMessage(message: String) {
        viewModelScope.launch {
            db.dao().insertAiChat(AiChat(role = "user", message = message, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
            
            isGenerating.value = true
            
            // Gather context
            var contextStr = ""
            try {
                val schedules = db.dao().getAllSchedulesSync()
                val history = db.dao().getAllHistorySync()
                val totalStudied = history.sumOf { it.timeStudiedSeconds }
                val hours = totalStudied / 3600
                val mins = (totalStudied % 3600) / 60
                val activeCount = schedules.count { it.isActive }
                contextStr = "USER CONTEXT: The user has active schedules: $activeCount. Total time studied: ${hours}h ${mins}m. Use this context to give personalized advice."
            } catch (e: Exception) {
                // Ignore context errors
            }



            if (BuildConfig.GEMINI_API_KEY.isEmpty() || !BuildConfig.GEMINI_API_KEY.startsWith("AIza")) {
                kotlinx.coroutines.delay(1000)
                if (message.lowercase().contains("mock test") || message.lowercase().contains("test")) {
                    val testTitle = "Demo Mock Test (Offline)"
                    val mockJson = "{\"title\": \"Demo Mock Test (Offline)\", \"questions\": [{\"q\": \"What is 2+2?\", \"options\": [\"3\", \"4\", \"5\", \"6\"], \"answerIndex\": 1}, {\"q\": \"What is the capital of France?\", \"options\": [\"Berlin\", \"Madrid\", \"Paris\", \"Rome\"], \"answerIndex\": 2}, {\"q\": \"Which planet is known as the Red Planet?\", \"options\": [\"Venus\", \"Mars\", \"Jupiter\", \"Saturn\"], \"answerIndex\": 1}]}"
                    val insertedId = db.dao().insertMockTest(MockTest(
                        title = testTitle,
                        testDataJson = mockJson,
                        date = System.currentTimeMillis()
                    ))
                    db.dao().insertAiChat(AiChat(role = "model", message = "[MOCK_TEST_CARD:$insertedId:$testTitle]", timestamp = System.currentTimeMillis()))
                } else if (message.lowercase().contains("schedule")) {
                    val schedName = "Demo Offline Schedule"
                    db.dao().insertSchedule(
                        Schedule(
                            subject = schedName,
                            description = "This is a demo schedule.",
                            isDurationMode = true,
                            durationMinutes = 25,
                            startTimeStr = "",
                            endTimeStr = "",
                            isOnlineMode = false,
                            selectedAppPackage = null,
                            isActive = true
                        )
                    )
                    db.dao().insertAiChat(AiChat(role = "model", message = "🎉 Schedule '$schedName' created successfully! You can view it on your Home screen.", timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
                } else {
                    val reply = "I am running in offline mode. Please configure a valid Gemini API Key (starting with 'AIza') in Settings/Secrets to enable full AI chat. For now, try asking me to 'create a mock test' or 'create a schedule'."
                    db.dao().insertAiChat(AiChat(role = "model", message = reply, timestamp = System.currentTimeMillis()))
                }
                isGenerating.value = false
                return@launch
            }
            try {
                // Construct history carefully to ensure strictly alternating roles for Gemini
                val currentChats = aiChats.value.toList()
                val filteredChats = if (currentChats.isNotEmpty() && currentChats.last().role == "user" && currentChats.last().message == message) {
                    currentChats.dropLast(1)
                } else {
                    currentChats
                }

                val recentChats = filteredChats.takeLast(10).toMutableList()
                while (recentChats.isNotEmpty() && recentChats.first().role != "user") {
                    recentChats.removeAt(0)
                }
                
                var lastRole = ""
                val validHistory = mutableListOf<AiChat>()
                for (chat in recentChats) {
                    val role = if (chat.role == "model") "model" else "user"
                    if (role != lastRole) {
                        validHistory.add(chat)
                        lastRole = role
                    }
                }
                
                if (validHistory.isNotEmpty() && validHistory.last().role != "model") {
                    validHistory.removeAt(validHistory.lastIndex)
                }

                val history = validHistory.map { chat ->
                    Content(role = if (chat.role == "model") "model" else "user", parts = listOf(Part(text = chat.message)))
                }.toMutableList()

                history.add(Content(role = "user", parts = listOf(Part(text = message))))

                val tools = listOf(
                    buildJsonObject {
                        putJsonArray("functionDeclarations") {

                            addJsonObject {
                                put("name", "createMockTest")
                                put("description", "Create a mock test with multiple choice questions.")
                                putJsonObject("parameters") {
                                    put("type", "OBJECT")
                                    putJsonObject("properties") {
                                        putJsonObject("title") {
                                            put("type", "STRING")
                                            put("description", "Title of the mock test")
                                        }
                                        putJsonObject("questions") {
                                            put("type", "ARRAY")
                                            put("description", "List of questions")
                                            putJsonObject("items") {
                                                put("type", "OBJECT")
                                                putJsonObject("properties") {
                                                    putJsonObject("q") {
                                                        put("type", "STRING")
                                                    }
                                                    putJsonObject("options") {
                                                        put("type", "ARRAY")
                                                        put("description", "List of exactly 4 options")
                                                        putJsonObject("items") {
                                                            put("type", "STRING")
                                                        }
                                                    }
                                                    putJsonObject("answerIndex") {
                                                        put("type", "INTEGER")
                                                        put("description", "0-based index of the correct option")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    putJsonArray("required") {
                                        add("title")
                                        add("questions")
                                    }
                                }
                            }
                            addJsonObject {
                                put("name", "createSchedule")
                                put("description", "Create a new focus schedule or task.")
                                putJsonObject("parameters") {
                                    put("type", "OBJECT")
                                    putJsonObject("properties") {
                                        putJsonObject("name") {
                                            put("type", "STRING")
                                            put("description", "The name of the schedule or task")
                                        }
                                        putJsonObject("description") {
                                            put("type", "STRING")
                                            put("description", "Details, time, or apps to block")
                                        }
                                    }
                                    putJsonArray("required") {
                                        add("name")
                                    }
                                }
                            }
                        }
                    }
                )

                val request = GenerateContentRequest(
                    contents = history,
                    tools = tools,
                    systemInstruction = Content(parts = listOf(Part(text = "You are XFlow AI, a helpful assistant. You help users with study tips, productivity, and focus techniques. If the user asks to create a schedule, use the createSchedule function. If the user asks for a mock test, use the createMockTest function. $contextStr")))
                )
                
                val response = RetrofitClient.service.generateContent(BuildConfig.GEMINI_API_KEY, request)
                val firstPart = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()
                
                if (firstPart?.functionCall != null) {
                    val functionCall = firstPart.functionCall
                    val name = functionCall["name"]?.jsonPrimitive?.content ?: ""
                    if (name == "createMockTest") {
                        val args = functionCall["args"]?.jsonObject
                        val title = args?.get("title")?.jsonPrimitive?.content ?: "Generated Mock Test"
                        val testDataJson = args.toString()
                        
                        val insertedId = db.dao().insertMockTest(
                            MockTest(
                                title = title,
                                testDataJson = testDataJson,
                                date = System.currentTimeMillis()
                            )
                        )
                        
                        db.dao().insertAiChat(AiChat(role = "model", message = "[MOCK_TEST_CARD:$insertedId:$title]", timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
                    } else if (name == "createSchedule") {
                        val args = functionCall["args"]?.jsonObject
                        val schedName = args?.get("name")?.jsonPrimitive?.content ?: "New Schedule"
                        val schedDesc = args?.get("description")?.jsonPrimitive?.content ?: ""
                        
                        db.dao().insertSchedule(
                            Schedule(
                                subject = schedName,
                                description = schedDesc,
                                isDurationMode = true,
                                durationMinutes = 25,
                                startTimeStr = "",
                                endTimeStr = "",
                                isOnlineMode = false,
                                selectedAppPackage = null,
                                isActive = true
                            )
                        )
                        
                        db.dao().insertAiChat(AiChat(role = "model", message = "🎉 Schedule '$schedName' created successfully! You can view it on your Home screen.", timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
                    }
                } else {
                    val responseText = firstPart?.text ?: "I'm sorry, I couldn't generate a response."
                    db.dao().insertAiChat(AiChat(role = "model", message = responseText, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
                }
                
            } catch (e: Exception) {
                val errorMessage = e.message ?: ""
                val msg = if (errorMessage.contains("429") || errorMessage.contains("quota", ignoreCase = true) || errorMessage.contains("exhausted", ignoreCase = true)) {
                    "Daily limit reached for AI chatting. The API quota has been exhausted and will reset tomorrow."
                } else {
                    "Error: ${e.message}. (Make sure you have configured a valid GEMINI_API_KEY in Settings/Secrets)."
                }
                db.dao().insertAiChat(AiChat(role = "model", message = msg, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
            } finally {
                isGenerating.value = false
            }
        }
    }
}
