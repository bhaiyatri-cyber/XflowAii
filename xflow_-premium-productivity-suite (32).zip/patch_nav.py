with open('app/src/main/java/com/example/ui/Navigation.kt', 'r') as f:
    content = f.read()

content = content.replace('const val HISTORY = "history"\n    const val PROGRESS = "progress"', 'const val HISTORY = "history"\n    const val PROGRESS = "progress"\n    const val TODAY_HISTORY = "today_history"\n    const val ALL_TIME_HISTORY = "all_time_history"')

content = content.replace('onNavigateToProgress = { navController.navigate(Routes.PROGRESS) }', 'onNavigateToTodayHistory = { navController.navigate(Routes.TODAY_HISTORY) },\n                onNavigateToAllTimeHistory = { navController.navigate(Routes.ALL_TIME_HISTORY) }')

if 'composable(Routes.TODAY_HISTORY)' not in content:
    nav_comp = """        composable(Routes.TODAY_HISTORY) {
            TodayHistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.ALL_TIME_HISTORY) {
            AllTimeHistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }"""
    
    content = content.replace('        composable(Routes.PROGRESS) {\n            ProgressScreen(\n                viewModel = viewModel,\n                onBack = { navController.popBackStack() }\n            )\n        }', nav_comp)

with open('app/src/main/java/com/example/ui/Navigation.kt', 'w') as f:
    f.write(content)
