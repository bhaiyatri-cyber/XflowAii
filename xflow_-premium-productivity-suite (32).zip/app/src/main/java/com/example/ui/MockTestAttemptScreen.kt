package com.example.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.data.MockTest
import com.example.data.XFlowDatabase
import com.example.ui.theme.XFlowAccent
import com.example.ui.theme.XFlowBackground
import com.example.ui.theme.XFlowSurface
import com.example.ui.theme.XFlowSurfaceVariant
import com.example.ui.theme.XFlowTextPrimary
import com.example.ui.theme.XFlowTextSecondary
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.ui.platform.LocalContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockTestAttemptScreen(navController: NavController, testId: Int) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { XFlowDatabase.getDatabase(context).dao() }
    var mockTest by remember { mutableStateOf<MockTest?>(null) }
    var currentQuestionIndex by remember { mutableIntStateOf(0) }
    var userAnswers by remember { mutableStateOf<Map<Int, Int>>(emptyMap()) }
    var showResults by remember { mutableStateOf(false) }

    LaunchedEffect(testId) {
        mockTest = dao.getMockTestById(testId)
        mockTest?.let { test ->
            if (test.isCompleted) {
                showResults = true
                val ansJson = JSONObject(test.userAnswersJson)
                val ansMap = mutableMapOf<Int, Int>()
                ansJson.keys().forEach { key ->
                    ansMap[key.toInt()] = ansJson.getInt(key)
                }
                userAnswers = ansMap
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(mockTest?.title ?: "Mock Test", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        if (mockTest == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = XFlowAccent)
            }
        } else {
            val testData = JSONObject(mockTest!!.testDataJson)
            val questionsArray = testData.optJSONArray("questions") ?: JSONArray()
            val totalQuestions = questionsArray.length()

            if (totalQuestions == 0) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No questions found.", color = XFlowTextPrimary)
                }
                return@Scaffold
            }

            if (showResults) {
                MockTestResults(
                    test = mockTest!!,
                    questionsArray = questionsArray,
                    userAnswers = userAnswers,
                    padding = padding
                )
            } else {
                val currentQuestion = questionsArray.getJSONObject(currentQuestionIndex)
                val qText = currentQuestion.getString("q")
                val optionsArray = currentQuestion.getJSONArray("options")
                
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Question ${currentQuestionIndex + 1} of $totalQuestions",
                        color = XFlowTextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = qText,
                        color = XFlowTextPrimary,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    for (i in 0 until optionsArray.length()) {
                        val optionText = optionsArray.getString(i)
                        val isSelected = userAnswers[currentQuestionIndex] == i
                        
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .clickable {
                                    val newAnswers = userAnswers.toMutableMap()
                                    newAnswers[currentQuestionIndex] = i
                                    userAnswers = newAnswers
                                },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) XFlowAccent.copy(alpha = 0.2f) else XFlowSurfaceVariant
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 0.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = null,
                                    colors = RadioButtonDefaults.colors(selectedColor = XFlowAccent, unselectedColor = XFlowTextSecondary)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(text = optionText, color = XFlowTextPrimary)
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        if (currentQuestionIndex > 0) {
                            OutlinedButton(
                                onClick = { currentQuestionIndex-- },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = XFlowAccent)
                            ) {
                                Text("Previous")
                            }
                        } else {
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        
                        if (currentQuestionIndex < totalQuestions - 1) {
                            Button(
                                onClick = { currentQuestionIndex++ },
                                colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                                enabled = userAnswers.containsKey(currentQuestionIndex)
                            ) {
                                Text("Next")
                            }
                        } else {
                            Button(
                                onClick = {
                                    var score = 0
                                    for (i in 0 until totalQuestions) {
                                        val q = questionsArray.getJSONObject(i)
                                        val ansIndex = q.getInt("answerIndex")
                                        if (userAnswers[i] == ansIndex) {
                                            score++
                                        }
                                    }
                                    
                                    val ansJson = JSONObject()
                                    userAnswers.forEach { (k, v) -> ansJson.put(k.toString(), v) }
                                    
                                    val updatedTest = mockTest!!.copy(
                                        score = score,
                                        totalQuestions = totalQuestions,
                                        isCompleted = true,
                                        userAnswersJson = ansJson.toString()
                                    )
                                    scope.launch {
                                        dao.updateMockTest(updatedTest)
                                        mockTest = updatedTest
                                        showResults = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                                enabled = userAnswers.size == totalQuestions
                            ) {
                                Text("Submit")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MockTestResults(test: MockTest, questionsArray: JSONArray, userAnswers: Map<Int, Int>, padding: PaddingValues) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "Results",
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Score: ${test.score} / ${test.totalQuestions}",
            color = XFlowAccent,
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(modifier = Modifier.height(24.dp))
        
        for (i in 0 until test.totalQuestions) {
            val q = questionsArray.getJSONObject(i)
            val qText = q.getString("q")
            val optionsArray = q.getJSONArray("options")
            val correctIndex = q.getInt("answerIndex")
            val selectedIndex = userAnswers[i] ?: -1
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Q${i + 1}: $qText", color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    for (j in 0 until optionsArray.length()) {
                        val optionText = optionsArray.getString(j)
                        val isCorrect = j == correctIndex
                        val isSelected = j == selectedIndex
                        
                        val textColor = when {
                            isCorrect -> Color(0xFF4CAF50)
                            isSelected && !isCorrect -> Color(0xFFF44336)
                            else -> XFlowTextSecondary
                        }
                        
                        Text(
                            text = "- $optionText",
                            color = textColor,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
