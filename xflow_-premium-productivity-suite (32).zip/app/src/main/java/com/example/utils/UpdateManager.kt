package com.example.utils

import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.example.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class UpdateManager(context: Context) {

    private val context = context.applicationContext

    private val REPO_API_URL = "https://api.github.com/repos/bhaiyatri-cyber/XflowAii/releases/latest"
    private val TAG = "UpdateManager"
    private val NOTIFICATION_ID = 1001
    private val CHANNEL_ID = "xflow_update_channel"
    private val prefs: SharedPreferences = context.getSharedPreferences("xflow_updates", Context.MODE_PRIVATE)

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == DownloadManager.ACTION_DOWNLOAD_COMPLETE) {
                val downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                if (downloadId != -1L && context != null) {
                    try {
                        val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                        val query = DownloadManager.Query().setFilterById(downloadId)
                        val cursor = downloadManager.query(query)
                        if (cursor != null && cursor.moveToFirst()) {
                            val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                            if (statusIndex >= 0) {
                                val status = cursor.getInt(statusIndex)
                                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                                    showInstallNotification()
                                } else {
                                    Log.e(TAG, "Download failed with status: $status")
                                }
                            }
                            cursor.close()
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error checking download status", e)
                    }
                }
            }
        }
    }

    init {
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(
                downloadReceiver,
                IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                Context.RECEIVER_EXPORTED
            )
        } else {
            context.registerReceiver(
                downloadReceiver,
                IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
            )
        }
    }

    fun checkForUpdate() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = URL(REPO_API_URL)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.setRequestProperty("Accept", "application/vnd.github.v3+json")

                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    val reader = BufferedReader(InputStreamReader(connection.inputStream))
                    val response = StringBuilder()
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        response.append(line)
                    }
                    reader.close()

                    val json = JSONObject(response.toString())
                    val tagName = json.getString("tag_name")
                    val versionStr = tagName.replace("v", "")
                    val latestVersion = versionStr.toIntOrNull() ?: 0
                    val currentVersion = BuildConfig.VERSION_CODE

                    Log.d(TAG, "Latest version: \$latestVersion, Current version: \$currentVersion")

                    val lastDownloadedVersion = prefs.getInt("last_downloaded_version", 0)
                    if (latestVersion > currentVersion && latestVersion > lastDownloadedVersion) {
                        val assets = json.getJSONArray("assets")
                        if (assets.length() > 0) {
                            val downloadUrl = assets.getJSONObject(0).getString("browser_download_url")
                            
                            // Save this version so we don't download it again if user doesn't install it or if versionCode wasn't bumped
                            prefs.edit().putInt("last_downloaded_version", latestVersion).apply()
                            
                            // Delete old apks before downloading the new one
                            cleanupOldUpdates()
                            
                            withContext(Dispatchers.Main) {
                                startDownload(downloadUrl)
                            }
                        }
                    } else if (latestVersion > currentVersion && latestVersion <= lastDownloadedVersion) {
                        Log.d(TAG, "Already downloaded version $latestVersion but not installed. Skipping automatic download.")
                        // We could show the install notification again here if the file exists
                        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                        if (dir != null && dir.exists()) {
                            val file = java.io.File(dir, "update.apk")
                            if (file.exists()) {
                                // The file is already here, just show the notification
                                showInstallNotification()
                            }
                        }
                    } else {
                        Log.d(TAG, "App is up to date. Cleaning up any old downloaded APKs.")
                        cleanupOldUpdates()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to check for update", e)
            }
        }
    }

    private fun startDownload(url: String) {
        try {
            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val request = DownloadManager.Request(Uri.parse(url))
            request.setTitle("XFlow Update")
            request.setDescription("Downloading new version...")
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
            request.setAllowedOverRoaming(true)
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            request.setDestinationInExternalFilesDir(
                context,
                Environment.DIRECTORY_DOWNLOADS,
                "update.apk"
            )
            downloadManager.enqueue(request)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start download", e)
        }
    }

    private fun showInstallNotification() {
        val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "update.apk")
        if (!file.exists()) return

        val uri = FileProvider.getUriForFile(
            context,
            BuildConfig.APPLICATION_ID + ".fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("✅ Update Ready")
            .setContentText("Tap to install now")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        try {
            notificationManager.notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
            Log.e(TAG, "Missing POST_NOTIFICATIONS permission", e)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to show notification", e)
        }
        
        // Also try to start it automatically if app is in foreground
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start install intent. User can tap notification instead.", e)
        }
    }

    private fun cleanupOldUpdates() {
        try {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            if (dir != null && dir.exists()) {
                // Delete all .apk files in the directory to prevent storage from filling up
                dir.listFiles()?.forEach { file ->
                    if (file.name.endsWith(".apk")) {
                        file.delete()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to cleanup", e)
        }
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "XFlow Updates"
            val descriptionText = "Notifications for app updates"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
