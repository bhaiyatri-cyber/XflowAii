with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('${${TimeUtils.formatHours(todayHours)}', '${TimeUtils.formatHours(todayHours)}')
content = content.replace('${${TimeUtils.formatHours(lifetimeHours)}', '${TimeUtils.formatHours(lifetimeHours)}')

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)
