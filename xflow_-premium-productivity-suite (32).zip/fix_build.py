with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

if 'import java.util.Calendar' not in content:
    content = content.replace('import java.util.Date', 'import java.util.Date\nimport java.util.Calendar')

history_screen_code = """
@Composable
fun HistoryScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToTask: (Int) -> Unit) {
    AllTimeHistoryScreen(viewModel, onBack)
}
"""

if 'fun HistoryScreen' not in content:
    content += history_screen_code

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
print("Fixed HistoryScreen.kt imports and missing function")
