with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

if 'val todayOvertimeHours by' not in content:
    content = content.replace(
        'val todayHours by viewModel.todayHours.collectAsStateWithLifecycle()',
        'val todayHours by viewModel.todayHours.collectAsStateWithLifecycle()\n    val todayOvertimeHours by viewModel.todayOvertimeHours.collectAsStateWithLifecycle()'
    )
    
if 'val lifetimeOvertimeHours by' not in content:
    content = content.replace(
        'val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle()',
        'val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle()\n    val lifetimeOvertimeHours by viewModel.lifetimeOvertimeHours.collectAsStateWithLifecycle()'
    )

old_stat = """            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
            }"""

new_stat = """            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours) + if (todayOvertimeHours > 0f) String.format("\\n+%.1fh OT", todayOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours) + if (lifetimeOvertimeHours > 0f) String.format("\\n+%.1fh OT", lifetimeOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
            }"""

content = content.replace(old_stat, new_stat)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
print("Patched HomeScreen")
