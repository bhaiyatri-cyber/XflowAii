import re

with open('app/src/main/java/com/example/ui/Navigation.kt', 'r') as f:
    content = f.read()

content = content.replace(
    """        composable(Routes.CHATBOT) {
            ChatbotScreen(navController = navController, onBack = { navController.popBackStack() }, viewModel = viewModel)
        }""",
    """        composable(Routes.CHATBOT) {
            SimpleAiChatScreen(onBack = { navController.popBackStack() })
        }"""
)

with open('app/src/main/java/com/example/ui/Navigation.kt', 'w') as f:
    f.write(content)
