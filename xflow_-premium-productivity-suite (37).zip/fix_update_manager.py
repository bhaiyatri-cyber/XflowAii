import re
with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

old_block = """        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            androidx.core.content.ContextCompat.registerReceiver(context, 
                downloadReceiver,
                IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                Context.RECEIVER_EXPORTED
            )
        } else {
            androidx.core.content.ContextCompat.registerReceiver(
                context,
                downloadReceiver,
                IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                androidx.core.content.ContextCompat.RECEIVER_EXPORTED
            )
        }"""

new_block = """        androidx.core.content.ContextCompat.registerReceiver(
            context,
            downloadReceiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            androidx.core.content.ContextCompat.RECEIVER_EXPORTED
        )"""

content = content.replace(old_block, new_block)

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)

