import re

with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

loop_init = """    private fun startTrackingLoop() {
        isTrackingLoopRunning = true
        serviceScope.launch {
            var lastTick = System.currentTimeMillis()
            val accumulatedMs = mutableMapOf<Int, Long>()
            while (true) {
                val now = System.currentTimeMillis()
                val deltaMs = now - lastTick
                lastTick = now
"""

content = content.replace("""    private fun startTrackingLoop() {
        isTrackingLoopRunning = true
        serviceScope.launch {
            while (true) {""", loop_init)

block1_old = """                        if (schedule.selectedAppPackage == currentApp) {
                            trackingAny = true
                            if (schedule.elapsedSeconds < targetTime) {
                                // increment elapsed
                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Tracking: ${schedule.subject}"
                                    contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                                }
                            } else {
                                // elapsed is at target, increment overtime
                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "🔥 Overtime: ${schedule.subject}"
                                    contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                                }
                            }
                        } else {"""

block1_new = """                        if (schedule.selectedAppPackage == currentApp) {
                            trackingAny = true
                            val currentAcc = accumulatedMs.getOrDefault(schedule.id, 0L) + deltaMs
                            val addSeconds = (currentAcc / 1000).toInt()
                            accumulatedMs[schedule.id] = currentAcc % 1000
                            
                            val newElapsed = if (schedule.elapsedSeconds < targetTime) Math.min(schedule.elapsedSeconds + addSeconds, targetTime) else schedule.elapsedSeconds
                            val newOvertime = if (schedule.elapsedSeconds + addSeconds > targetTime) schedule.overtimeSeconds + (schedule.elapsedSeconds + addSeconds - Math.max(schedule.elapsedSeconds, targetTime)) else schedule.overtimeSeconds
                            
                            if (addSeconds > 0) {
                                if (newElapsed > schedule.elapsedSeconds) db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                if (newOvertime > schedule.overtimeSeconds) db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                            }
                            
                            if (newElapsed < targetTime) {
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Tracking: ${schedule.subject}"
                                    contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                                }
                            } else {
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "🔥 Overtime: ${schedule.subject}"
                                    contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                                }
                            }
                        } else {"""

content = content.replace(block1_old, block1_new)

block2_old = """                        if (!isScreenOn) {
                            trackingAny = true
                            if (schedule.elapsedSeconds < targetTime) {
                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Offline Tracking: ${schedule.subject}"
                                    contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                                }
                            } else {
                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "🔥 Offline Overtime: ${schedule.subject}"
                                    contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                                }
                            }
                        } else {"""

block2_new = """                        if (!isScreenOn) {
                            trackingAny = true
                            val currentAcc = accumulatedMs.getOrDefault(schedule.id, 0L) + deltaMs
                            val addSeconds = (currentAcc / 1000).toInt()
                            accumulatedMs[schedule.id] = currentAcc % 1000
                            
                            val newElapsed = if (schedule.elapsedSeconds < targetTime) Math.min(schedule.elapsedSeconds + addSeconds, targetTime) else schedule.elapsedSeconds
                            val newOvertime = if (schedule.elapsedSeconds + addSeconds > targetTime) schedule.overtimeSeconds + (schedule.elapsedSeconds + addSeconds - Math.max(schedule.elapsedSeconds, targetTime)) else schedule.overtimeSeconds
                            
                            if (addSeconds > 0) {
                                if (newElapsed > schedule.elapsedSeconds) db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                if (newOvertime > schedule.overtimeSeconds) db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                            }
                            
                            if (newElapsed < targetTime) {
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Offline Tracking: ${schedule.subject}"
                                    contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                                }
                            } else {
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "🔥 Offline Overtime: ${schedule.subject}"
                                    contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                                }
                            }
                        } else {"""

content = content.replace(block2_old, block2_new)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)

print("Updates applied")
