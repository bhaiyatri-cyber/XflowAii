package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "schedules")
data class Schedule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val description: String,
    val isDurationMode: Boolean,
    val durationMinutes: Int, // for duration mode
    val startTimeStr: String, // for exact time mode
    val endTimeStr: String,
    val isOnlineMode: Boolean,
    val selectedAppPackage: String?,
    val isActive: Boolean = true,
    val elapsedSeconds: Int = 0,
    val isRunning: Boolean = false,
    val overtimeSeconds: Int = 0,
    val isFromStudyPlan: Boolean = false,
    val studyPlanId: Int = 0,
    val creationDate: Long = System.currentTimeMillis(),
    val hasBeenEdited: Boolean = false
)

@Entity(tableName = "history")
data class HistorySession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val scheduleId: Int,
    val subject: String,
    val mode: String, // Duration or Exact
    val date: Long,
    val timeStudiedSeconds: Int,
    val completionPercentage: Int,
    val status: String // Completed, Partial, Missed
)


@Entity(tableName = "overtime_entries")
data class OvertimeEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val scheduleId: Int,
    val subject: String,
    val overtimeSeconds: Int,
    val date: Long
)

@Entity(tableName = "study_plans")
data class StudyPlan(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val recurrenceDays: Int, // -1 for always, or number of days
    val createdAt: Long,
    val lastGeneratedDay: Long
)

@Entity(tableName = "study_plan_items")
data class StudyPlanItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val planId: Int,
    val subject: String,
    val description: String,
    val startTimeStr: String,
    val endTimeStr: String,
    val isOnlineMode: Boolean,
    val selectedAppPackage: String?
)


@Entity(tableName = "mock_tests")
data class MockTest(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val testDataJson: String,
    val date: Long,
    val score: Int? = null,
    val totalQuestions: Int = 0,
    val isCompleted: Boolean = false,
    val userAnswersJson: String = "{}"
)

@Entity(tableName = "ai_chats")
data class AiChat(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val role: String, // "user" or "model"
    val message: String,
    val timestamp: Long
)

@Dao

interface XFlowDao {
    @Query("SELECT * FROM schedules")
    suspend fun getAllSchedulesSync(): List<Schedule>

    @Query("SELECT * FROM history")
    suspend fun getAllHistorySync(): List<HistorySession>

    @Query("SELECT * FROM schedules WHERE isActive = 1")
    fun getActiveSchedules(): Flow<List<Schedule>>

    @Query("SELECT * FROM schedules WHERE isActive = 1")
    suspend fun getActiveSchedulesSync(): List<Schedule>

    
    @Query("SELECT * FROM ai_chats ORDER BY timestamp ASC")
    fun getAllAiChats(): Flow<List<AiChat>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAiChat(chat: AiChat)

    @Query("SELECT * FROM mock_tests ORDER BY date DESC")
    fun getAllMockTests(): Flow<List<MockTest>>

    @Query("SELECT * FROM mock_tests WHERE id = :id")
    suspend fun getMockTestById(id: Int): MockTest?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMockTest(test: MockTest): Long
    
    @androidx.room.Update
    suspend fun updateMockTest(test: MockTest)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
suspend fun insertSchedule(schedule: Schedule): Long
    
    @androidx.room.Update
    suspend fun updateSchedule(schedule: Schedule)

    @Query("UPDATE schedules SET isActive = 0 WHERE id = :id")
    suspend fun deactivateSchedule(id: Int)
    
    @Query("SELECT * FROM schedules WHERE id = :id")
    suspend fun getScheduleById(id: Int): Schedule?


    @Query("UPDATE schedules SET elapsedSeconds = :elapsed, isRunning = :running WHERE id = :id")
    suspend fun updateScheduleProgress(id: Int, elapsed: Int, running: Boolean)

    @Query("UPDATE schedules SET overtimeSeconds = :overtime WHERE id = :id")
    suspend fun updateScheduleOvertime(id: Int, overtime: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOvertimeEntry(entry: OvertimeEntry)

    @Query("SELECT * FROM overtime_entries ORDER BY date DESC")
    fun getAllOvertimeEntries(): Flow<List<OvertimeEntry>>


    @Query("SELECT * FROM history ORDER BY date DESC")
    fun getAllHistory(): Flow<List<HistorySession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(session: HistorySession)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudyPlan(plan: StudyPlan): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudyPlanItems(items: List<StudyPlanItem>)

    @Query("SELECT * FROM study_plans")
    suspend fun getAllStudyPlans(): List<StudyPlan>

    @Query("SELECT * FROM study_plan_items WHERE planId = :planId")
    suspend fun getStudyPlanItems(planId: Int): List<StudyPlanItem>

    @Query("UPDATE study_plans SET lastGeneratedDay = :day WHERE id = :planId")
    suspend fun updateStudyPlanGeneratedDay(planId: Int, day: Long)

    @Query("DELETE FROM ai_chats")
    suspend fun deleteAllAiChats()
}

@Database(entities = [Schedule::class, HistorySession::class, StudyPlan::class, StudyPlanItem::class, OvertimeEntry::class, MockTest::class, AiChat::class], version = 7, exportSchema = false)
abstract class XFlowDatabase : RoomDatabase() {
    abstract fun dao(): XFlowDao
    
    companion object {
        @Volatile
        private var INSTANCE: XFlowDatabase? = null

        fun getDatabase(context: android.content.Context): XFlowDatabase {
            return INSTANCE ?: synchronized(this) {
                val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
                    override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                        database.execSQL("ALTER TABLE schedules ADD COLUMN hasBeenEdited INTEGER NOT NULL DEFAULT 0")
                    }
                }
                
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    XFlowDatabase::class.java,
                    "xflow-db"
                )
                .addMigrations(MIGRATION_5_6)
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
