with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

content = content.replace(
    "androidx.core.content.ContextCompat.registerReceiver(context, \n                downloadReceiver,\n                IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)\n            )",
    "androidx.core.content.ContextCompat.registerReceiver(\n                context,\n                downloadReceiver,\n                IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),\n                androidx.core.content.ContextCompat.RECEIVER_EXPORTED\n            )"
)

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)
