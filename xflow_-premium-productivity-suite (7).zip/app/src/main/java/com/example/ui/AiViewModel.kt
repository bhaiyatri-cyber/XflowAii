package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.app.PendingIntent
import android.net.Uri
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import kotlinx.serialization.json.putJsonArray

class AiViewModel(application: Application) : AndroidViewModel(application) {
    private fun sendMockTestReadyNotification(title: String, testId: Int) {
        val context = getApplication<Application>()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "AiMockTestChannel"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "AI Mock Tests",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for AI generated mock tests"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("xflow://mock_test/$testId"))
        val pendingIntent = PendingIntent.getActivity(context, testId, deepLinkIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Mock Test Ready!")
            .setContentText("Your test '$title' has been generated and is ready to attempt. Tap to start!")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        notificationManager.notify(testId, builder.build())
    }

    private val db = XFlowDatabase.getDatabase(application)
    
    val aiChats = db.dao().getAllAiChats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val mockTests = db.dao().getAllMockTests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isGenerating = MutableStateFlow(false)

    fun clearChat() {
        viewModelScope.launch {
            db.dao().deleteAllAiChats()
        }
    }

    fun sendMessage(message: String) {
        viewModelScope.launch {
            // Check if user is asking for a mock test
            val isMockTestRequest = message.lowercase().contains("mock test") || message.lowercase().contains("test")
            
            db.dao().insertAiChat(AiChat(role = "user", message = message, timestamp = System.currentTimeMillis()))
            
            isGenerating.value = true
            
            val prompt = if (isMockTestRequest) {
                // Generate Mock Test
                "Generate a mock test based on this request: '$message'. Respond ONLY with a valid JSON format (No Markdown block quotes, just the raw JSON) following this structure: {\"title\": \"Title of Test\", \"questions\": [{\"q\": \"Question text\", \"options\": [\"Option 1\", \"Option 2\", \"Option 3\", \"Option 4\"], \"answerIndex\": 0}]}"
            } else {
                message
            }

            try {
                // Construct history
                val history = aiChats.value.takeLast(10).map { 
                    Content(role = it.role, parts = listOf(Part(text = it.message))) 
                }.toMutableList()
                history.add(Content(role = "user", parts = listOf(Part(text = prompt))))
                
                val request = GenerateContentRequest(
                    contents = history,
                    generationConfig = if (isMockTestRequest) {
                         GenerationConfig(
                             responseMimeType = "application/json"
                         )
                    } else null,
                    systemInstruction = Content(parts = listOf(Part(text = "You are XFlow AI, an assistant for the XFlow productivity and focus app. You help users with study tips, app customization, and you can generate Mock Tests when requested.")))
                )
                
                val response = RetrofitClient.service.generateContent(BuildConfig.GEMINI_API_KEY, request)
                var responseText = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "I'm sorry, I couldn't generate a response."
                
                if (isMockTestRequest) {
                    try {
                        // Validate JSON
                        if (responseText.startsWith("```json")) {
                            responseText = responseText.substringAfter("```json").substringBeforeLast("```").trim()
                        }
                        // Insert mock test
                        val testTitle = org.json.JSONObject(responseText).optString("title", "Generated Mock Test")
                        val insertedId = db.dao().insertMockTest(MockTest(
                            title = testTitle,
                            testDataJson = responseText,
                            date = System.currentTimeMillis()
                        ))
                        db.dao().insertAiChat(AiChat(role = "model", message = "I have generated a new Mock Test for you. You can find it in the AI Mock Tests section.", timestamp = System.currentTimeMillis()))
                        sendMockTestReadyNotification(testTitle, insertedId.toInt())
                    } catch (e: Exception) {
                        db.dao().insertAiChat(AiChat(role = "model", message = "Failed to parse mock test: ${e.message}", timestamp = System.currentTimeMillis()))
                    }
                } else {
                    db.dao().insertAiChat(AiChat(role = "model", message = responseText, timestamp = System.currentTimeMillis()))
                }
            } catch (e: Exception) {
                val errorMessage = e.message ?: ""
                val msg = if (errorMessage.contains("429") || errorMessage.contains("quota", ignoreCase = true) || errorMessage.contains("exhausted", ignoreCase = true)) {
                    "Daily limit reached for AI chatting. The API quota has been exhausted and will reset tomorrow (midnight Pacific Time)."
                } else {
                    "Error: ${e.message}. (Make sure you have configured a valid GEMINI_API_KEY in Settings/Secrets)."
                }
                db.dao().insertAiChat(AiChat(role = "model", message = msg, timestamp = System.currentTimeMillis()))
            } finally {
                isGenerating.value = false
            }
        }
    }
}
