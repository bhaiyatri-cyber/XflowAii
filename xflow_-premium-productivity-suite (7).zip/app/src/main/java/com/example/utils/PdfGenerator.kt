package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object PdfGenerator {
    
    fun getPdfsDirectory(context: Context): File {
        val pdfDir = File(context.filesDir, "pdfs")
        if (!pdfDir.exists()) pdfDir.mkdirs()
        return pdfDir
    }

    suspend fun createPdfFromImages(context: Context, imageUris: List<Uri>): File? = withContext(Dispatchers.IO) {
        if (imageUris.isEmpty()) return@withContext null
        val pdfDocument = PdfDocument()
        
        try {
            for ((index, uri) in imageUris.withIndex()) {
                val bitmap = getBitmap(context, uri) ?: continue
                
                // Keep original quality and dimensions
                val pageWidth = bitmap.width
                val pageHeight = bitmap.height
                
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                
                val canvas = page.canvas
                canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDocument.finishPage(page)
                
                bitmap.recycle()
            }
            
            val pdfDir = getPdfsDirectory(context)
            val pdfFile = File(pdfDir, "XFlow_Converted_${System.currentTimeMillis()}.pdf")
            pdfDocument.writeTo(FileOutputStream(pdfFile))
            return@withContext pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext null
        } finally {
            pdfDocument.close()
        }
    }

    private fun getBitmap(context: Context, uri: Uri): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri)) { decoder, info, _ ->
                    decoder.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
                    decoder.isMutableRequired = true
                    // No downscaling, keep original quality
                }
            } else {
                val options = android.graphics.BitmapFactory.Options()
                options.inJustDecodeBounds = true
                var inputStream = context.contentResolver.openInputStream(uri)
                android.graphics.BitmapFactory.decodeStream(inputStream, null, options)
                inputStream?.close()
                
                var inSampleSize = 1
                // No downscaling, keep original quality
                
                options.inJustDecodeBounds = false
                options.inSampleSize = inSampleSize
                inputStream = context.contentResolver.openInputStream(uri)
                val bitmap = android.graphics.BitmapFactory.decodeStream(inputStream, null, options)
                inputStream?.close()
                bitmap
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
    
    
    suspend fun appendImagesToPdf(context: Context, existingFile: File, newImageUris: List<Uri>): Boolean = withContext(Dispatchers.IO) {
        if (newImageUris.isEmpty()) return@withContext false
        val pdfDocument = PdfDocument()
        try {
            var pageIndex = 1
            val fileDescriptor = android.os.ParcelFileDescriptor.open(existingFile, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
            val pdfRenderer = android.graphics.pdf.PdfRenderer(fileDescriptor)
            
            for (i in 0 until pdfRenderer.pageCount) {
                val rendererPage = pdfRenderer.openPage(i)
                val bitmap = Bitmap.createBitmap(rendererPage.width, rendererPage.height, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(android.graphics.Color.WHITE)
                rendererPage.render(bitmap, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                rendererPage.close()
                
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, pageIndex++).create()
                val page = pdfDocument.startPage(pageInfo)
                page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDocument.finishPage(page)
                bitmap.recycle()
            }
            pdfRenderer.close()
            fileDescriptor.close()

            for (uri in newImageUris) {
                val bitmap = getBitmap(context, uri) ?: continue
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, pageIndex++).create()
                val page = pdfDocument.startPage(pageInfo)
                page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDocument.finishPage(page)
                bitmap.recycle()
            }
            
            val tempFile = File(existingFile.parent, existingFile.name + ".tmp")
            pdfDocument.writeTo(FileOutputStream(tempFile))
            pdfDocument.close()
            
            if (existingFile.delete()) {
                tempFile.renameTo(existingFile)
            } else {
                tempFile.renameTo(existingFile)
            }
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        }
    }

    fun getSavedPdfs(context: Context): List<File> {
        val pdfDir = getPdfsDirectory(context)
        return pdfDir.listFiles()?.filter { it.extension == "pdf" }?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
    
    fun renamePdf(file: File, newName: String): File? {
        var safeName = newName
        if (!safeName.lowercase().endsWith(".pdf")) {
            safeName += ".pdf"
        }
        val newFile = File(file.parentFile, safeName)
        if (file.renameTo(newFile)) {
            return newFile
        }
        return null
    }

    suspend fun savePdfToDownloads(context: Context, file: File): Boolean = withContext(Dispatchers.IO) {
        try {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = context.contentResolver.insert(MediaStore.Files.getContentUri("external"), contentValues)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(file).use { input ->
                        input.copyTo(out)
                    }
                }
                return@withContext true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext false
    }
}
