with open('app/src/main/java/com/example/ui/MockTestAttemptScreen.kt', 'r') as f:
    content = f.read()

old_submit = """            if (!isSubmitted) {
                Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.BottomCenter) {
                    Button(
                        onClick = {
                            scope.launch {
                                // Calculate score"""

new_submit = """            if (!isSubmitted) {
                var showConfirmDialog by remember { mutableStateOf(false) }
                
                if (showConfirmDialog) {
                    AlertDialog(
                        onDismissRequest = { showConfirmDialog = false },
                        title = { Text("Submit Test", color = XFlowTextPrimary) },
                        text = { Text("Are you sure you want to submit your test?", color = XFlowTextSecondary) },
                        confirmButton = {
                            TextButton(onClick = {
                                showConfirmDialog = false
                                scope.launch {
                                    // Calculate score
                                    var score = 0
                                    val total = questions?.length() ?: 0
                                    val answersJson = JSONObject()
                                    
                                    for (i in 0 until total) {
                                        val correctIndex = questions!!.optJSONObject(i)?.optInt("answerIndex", -1) ?: -1
                                        val selected = userAnswers[i]
                                        if (selected != null) {
                                            answersJson.put(i.toString(), selected)
                                            if (selected == correctIndex) score++
                                        }
                                    }
                                    
                                    val updatedTest = mockTest!!.copy(
                                        score = score,
                                        totalQuestions = total,
                                        isCompleted = true,
                                        userAnswersJson = answersJson.toString()
                                    )
                                    withContext(Dispatchers.IO) {
                                        db.dao().updateMockTest(updatedTest)
                                    }
                                    mockTest = updatedTest
                                    isSubmitted = true
                                }
                            }) {
                                Text("Submit", color = XFlowAccent)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showConfirmDialog = false }) {
                                Text("Cancel", color = XFlowTextSecondary)
                            }
                        },
                        containerColor = XFlowSurface
                    )
                }
                
                Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.BottomCenter) {
                    Button(
                        onClick = { showConfirmDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent)
                    ) {
                        Text("Submit Test", color = Color.White)
                    }
                }
            }
"""

# The script logic needs to be exact to replace the bottom button logic safely
content = content.replace("""            if (!isSubmitted) {
                Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.BottomCenter) {
                    Button(
                        onClick = {
                            scope.launch {
                                // Calculate score
                                var score = 0
                                val total = questions?.length() ?: 0
                                val answersJson = JSONObject()
                                
                                for (i in 0 until total) {
                                    val correctIndex = questions!!.optJSONObject(i)?.optInt("answerIndex", -1) ?: -1
                                    val selected = userAnswers[i]
                                    if (selected != null) {
                                        answersJson.put(i.toString(), selected)
                                        if (selected == correctIndex) score++
                                    }
                                }
                                
                                val updatedTest = mockTest!!.copy(
                                    score = score,
                                    totalQuestions = total,
                                    isCompleted = true,
                                    userAnswersJson = answersJson.toString()
                                )
                                withContext(Dispatchers.IO) {
                                    db.dao().updateMockTest(updatedTest)
                                }
                                mockTest = updatedTest
                                isSubmitted = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent)
                    ) {
                        Text("Submit Test", color = Color.White)
                    }
                }
            }""", new_submit)

with open('app/src/main/java/com/example/ui/MockTestAttemptScreen.kt', 'w') as f:
    f.write(content)
