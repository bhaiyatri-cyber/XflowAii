package com.example.ui

import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.animation.core.*
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Article
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import com.example.ui.theme.*
import androidx.navigation.NavController
import com.example.data.AiChat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiScreen(navController: NavController, viewModel: AiViewModel = viewModel(), xFlowViewModel: XFlowViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var selectedItem by remember { mutableStateOf("Chat") }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = XFlowSurface
            ) {
                Spacer(Modifier.height(12.dp))
                Text(
                    "XFlow AI Menu",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.titleLarge,
                    color = XFlowTextPrimary
                )
                HorizontalDivider(color = XFlowSurfaceVariant)
                NavigationDrawerItem(
                    label = { Text("Chat History", color = XFlowTextPrimary) },
                    selected = selectedItem == "Chat",
                    onClick = {
                        selectedItem = "Chat"
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = XFlowSurfaceVariant,
                        unselectedContainerColor = Color.Transparent
                    )
                )
                val isPremium by xFlowViewModel.isPremium.collectAsStateWithLifecycle()
                var showPremiumDialog by remember { mutableStateOf(false) }
                
                if (showPremiumDialog) {
                    AlertDialog(
                        onDismissRequest = { showPremiumDialog = false },
                        title = { Text("Premium Feature", color = XFlowTextPrimary) },
                        text = { Text("Mock Tests are only available for Premium users.", color = XFlowTextSecondary) },
                        confirmButton = { TextButton(onClick = { showPremiumDialog = false }) { Text("OK", color = XFlowAccent) } },
                        containerColor = XFlowSurface
                    )
                }
                
                NavigationDrawerItem(
                    label = { Text("AI Mock Tests (Pro)", color = XFlowTextPrimary) },
                    selected = selectedItem == "MockTests",
                    onClick = {
                        if (isPremium) {
                            selectedItem = "MockTests"
                        } else {
                            showPremiumDialog = true
                        }
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = XFlowSurfaceVariant,
                        unselectedContainerColor = Color.Transparent
                    )
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (selectedItem == "Chat") "XFlow AI" else "Mock Tests", color = XFlowTextPrimary) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = XFlowTextPrimary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
                )
            },
            containerColor = XFlowBackground
        ) { padding ->
            Box(modifier = Modifier.padding(padding)) {
                if (selectedItem == "Chat") {
                    val isPremium by xFlowViewModel.isPremium.collectAsStateWithLifecycle()
                    ChatContent(viewModel, isPremium)
                } else {
                    MockTestsContent(viewModel, navController)
                }
            }
        }
    }
}

@Composable
fun ChatContent(viewModel: AiViewModel, isPremium: Boolean) {
    val aiChats by viewModel.aiChats.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()

    LaunchedEffect(aiChats.size) {
        if (aiChats.isNotEmpty()) {
            listState.animateScrollToItem(aiChats.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize().imePadding()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (aiChats.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                        Text("How can I help you today?", color = XFlowTextSecondary)
                    }
                }
            }
            items(aiChats) { chat ->
                ChatBubble(chat)
            }
            if (isGenerating) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "AI",
                                tint = XFlowAccent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            TypingIndicator()
                        }
                    }
                }
            }
        }

        if (isPremium) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask anything or 'Create a mock test'...") },
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = XFlowAccent,
                        unfocusedBorderColor = XFlowSurfaceVariant,
                        focusedTextColor = XFlowTextPrimary
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank() && !isGenerating) {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(XFlowAccent, RoundedCornerShape(24.dp))
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                }
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurfaceVariant)
            ) {
                Text(
                    "AI Chat is a Premium feature.",
                    modifier = Modifier.padding(16.dp),
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}

@Composable
fun ChatBubble(chat: AiChat) {
    val isUser = chat.role == "user"
    var displayedText by remember { mutableStateOf(if (isUser) chat.message else "") }
    
    if (!isUser) {
        LaunchedEffect(chat.message) {
            val words = chat.message.split(" ")
            var currentText = ""
            for (word in words) {
                currentText += "$word "
                displayedText = currentText
                kotlinx.coroutines.delay(50) // Adjust delay for typing speed
            }
            displayedText = chat.message
        }
    }

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        if (isUser) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = 16.dp,
                        bottomEnd = 4.dp
                    ))
                    .background(XFlowAccent)
                    .padding(12.dp)
            ) {
                Text(
                    text = displayedText,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth(0.95f).padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "AI",
                    tint = XFlowAccent,
                    modifier = Modifier.size(24.dp).padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = displayedText,
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun MockTestsContent(viewModel: AiViewModel, navController: NavController) {
    val mockTests by viewModel.mockTests.collectAsStateWithLifecycle()

    if (mockTests.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Article, contentDescription = null, tint = XFlowTextSecondary, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text("No Mock Tests Yet", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Ask AI to generate a mock test in Chat.", color = XFlowTextSecondary)
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(mockTests) { test ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        navController.navigate("mock_test/${test.id}")
                    },
                    colors = CardDefaults.cardColors(containerColor = XFlowSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(test.title, color = XFlowTextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        val title = org.json.JSONObject(test.testDataJson).optString("title", test.title)
                        Text(title, color = XFlowTextPrimary)
                        Spacer(modifier = Modifier.height(8.dp))
                        val questions = org.json.JSONObject(test.testDataJson).optJSONArray("questions")
                        Text("Questions: ${questions?.length() ?: 0}", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                        if (test.isCompleted) {
                            Text("Score: ${test.score}/${test.totalQuestions}", color = XFlowAccent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        } else {
                            Text("Not Attempted", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TypingIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "")
    val alpha1 by infiniteTransition.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(400, delayMillis = 0), repeatMode = RepeatMode.Reverse),
        label = ""
    )
    val alpha2 by infiniteTransition.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(400, delayMillis = 200), repeatMode = RepeatMode.Reverse),
        label = ""
    )
    val alpha3 by infiniteTransition.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(400, delayMillis = 400), repeatMode = RepeatMode.Reverse),
        label = ""
    )
    
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha1)))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha2)))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha3)))
    }
}
