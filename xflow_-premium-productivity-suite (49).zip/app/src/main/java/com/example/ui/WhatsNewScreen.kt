package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.clip
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

@Composable
fun WhatsNewScreen(isFirstInstall: Boolean = false, onDismiss: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = XFlowBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_app_logo),
                contentDescription = "New Logo",
                modifier = Modifier.size(120.dp).clip(RoundedCornerShape(24.dp))
            )
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = if (isFirstInstall) "Welcome to XFlow Premium!" else "App Updated to ${com.example.BuildConfig.VERSION_NAME}!",
                style = MaterialTheme.typography.headlineMedium,
                color = XFlowTextPrimary,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(32.dp))
            
            Card(
                colors = CardDefaults.cardColors(containerColor = XFlowSurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = if (isFirstInstall) "What you can do with XFlow:" else "What's New in this version:",
                        style = MaterialTheme.typography.titleLarge,
                        color = XFlowTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                                                            val changes = if (isFirstInstall) listOf(
                        "Study Plans & Timers: Create and manage strict focus schedules to maximize your productivity.",
                        "AI Chat & Mock Tests: Use our Gemini-powered AI Assistant to generate quizzes, get focus tips, and more.",
                        "Premium Themes: Customize your experience with beautiful card styles and premium UI components.",
                        "Detailed Analytics: Track your daily and lifetime study hours, streaks, and focus metrics."
                    ) else listOf(
                        "Mock Tests: Generate and take custom MCQ mock tests on any topic using the new AI Assistant.",
                        "Fixed Chat Overlap: Corrected visual bugs in the AI Assistant chat interface where messages would overlap.",
                        "Updated Notification Icon: Notifications now display the premium app logo instead of the old default icon."
                    )




                    
                    changes.forEach { change ->
                        Row(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(
                                text = "•",
                                style = MaterialTheme.typography.bodyLarge,
                                color = XFlowAccent,
                                modifier = Modifier.padding(end = 8.dp)
                            )
                            Text(
                                text = change,
                                style = MaterialTheme.typography.bodyLarge,
                                color = XFlowTextSecondary
                            )
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text("Awesome, Let's Go!", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
