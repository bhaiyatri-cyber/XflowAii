package com.example.ui

enum class StudyStatus {
    COMPLETED, RUNNING, PAUSED, UPCOMING, MISSED
}

fun getResultStatus(percentage: Int): String {
    return when {
        percentage >= 100 -> "Excellent"
        percentage >= 80 -> "Good"
        percentage >= 50 -> "Fair"
        else -> "Needs Improvement"
    }
}
