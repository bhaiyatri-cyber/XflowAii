package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.UpdateInfo
import com.example.ui.theme.XFlowAccent
import com.example.ui.theme.XFlowSurface
import com.example.ui.theme.XFlowTextPrimary
import com.example.ui.theme.XFlowTextSecondary

@Composable
fun UpdatePromptCard(
    updateInfo: UpdateInfo,
    onUpdateNow: () -> Unit,
    onLater: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = XFlowSurface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.ic_app_logo),
                    contentDescription = "App Logo",
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Update Available",
                        style = MaterialTheme.typography.titleMedium,
                        color = XFlowTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Version ${updateInfo.versionName}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = XFlowTextSecondary
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
                        Text(
                text = "What's New in XFlow:",
                style = MaterialTheme.typography.bodyMedium,
                color = XFlowTextPrimary,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            val features = listOf(
                "✨ AI Chatbot & Study Assistant",
                "📄 PDF & Image to PDF Tools",
                "📝 Mock Test Attempts",
                "☁️ Cloud Backup & Restore",
                "💾 Data Drive Storage",
                "📅 Advanced Study Planner"
            )
            
            features.forEach { feature ->
                Text(
                    text = feature,
                    style = MaterialTheme.typography.bodyMedium,
                    color = XFlowTextSecondary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Release Notes: " + updateInfo.releaseNotes,
                style = MaterialTheme.typography.bodySmall,
                color = XFlowTextSecondary
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onLater) {
                    Text("Later", color = XFlowTextSecondary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onUpdateNow,
                    colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent)
                ) {
                    Text("Update Now", color = Color.White)
                }
            }
        }
    }
}
