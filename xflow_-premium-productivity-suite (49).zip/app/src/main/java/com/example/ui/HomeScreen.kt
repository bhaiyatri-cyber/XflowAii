package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.Schedule
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*
import com.example.utils.TimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: XFlowViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToCreate: () -> Unit,
    onNavigateToTask: (Int) -> Unit,
    onNavigateToTodayHistory: () -> Unit,
    onNavigateToAllTimeHistory: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToStudyPlan: () -> Unit
) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("xflow_prefs", android.content.Context.MODE_PRIVATE)
    val lastOpenedVersion = prefs.getInt("last_opened_version", 0)
    val currentVersion = com.example.BuildConfig.VERSION_CODE
    var showWhatsNew by remember { mutableStateOf(false) }

    val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle(initialValue = emptyList())
    val todayHours by viewModel.todayHours.collectAsStateWithLifecycle(initialValue = 0f)
    val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle(initialValue = 0f)
    val currentStreak by viewModel.currentStreak.collectAsStateWithLifecycle(initialValue = 0f)
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle(initialValue = false)
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle(initialValue = "Default")

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current

    LaunchedEffect(Unit) {
        if (lastOpenedVersion < currentVersion) {
            showWhatsNew = true
            val updateTimeKey = "update_time_$currentVersion"
            if (prefs.getLong(updateTimeKey, 0L) == 0L) {
                prefs.edit().putLong(updateTimeKey, System.currentTimeMillis()).apply()
            }
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                viewModel.checkAndRolloverStudyPlans()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val hasActiveSchedules = activeSchedules.isNotEmpty()
    LaunchedEffect(hasActiveSchedules) {
        if (activeSchedules.isNotEmpty()) {
            val intent = android.content.Intent(context, com.example.service.TrackingService::class.java)
            try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    if (showWhatsNew) {
        WhatsNewScreen(
            isFirstInstall = lastOpenedVersion == 0,
            onDismiss = {
                showWhatsNew = false
                prefs.edit().putInt("last_opened_version", currentVersion).apply()
            }
        )
        return
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToCreate,
                containerColor = XFlowAccent,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Schedule")
            }
        },
        containerColor = XFlowBackground
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(16.dp)) }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DynamicHeader()
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = XFlowTextSecondary)
                    }
                }
            }
            
            item {
                StatCardRow(
                    todayHours = todayHours,
                    lifetimeHours = lifetimeHours,
                    currentStreak = currentStreak.toInt()
                )
            }
            
            item {
                Button(
                    onClick = onNavigateToStudyPlan,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant)
                ) {
                    Text("Study Plans (Premium)", color = XFlowAccent)
                }
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TextButton(onClick = onNavigateToTodayHistory) {
                        Text("Today's History", color = XFlowTextPrimary)
                    }
                    TextButton(onClick = onNavigateToAllTimeHistory) {
                        Text("All-Time History", color = XFlowTextPrimary)
                    }
                }
            }
            
            item {
                Text(
                    text = "Active Schedules",
                    style = MaterialTheme.typography.titleLarge,
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            
            if (activeSchedules.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No active schedules. Create one!", color = XFlowTextSecondary)
                    }
                }
            } else {
                items(activeSchedules, key = { it.id }) { schedule ->
                    ScheduleCard(
                        schedule = schedule,
                        isPremium = isPremium,
                        cardStyle = cardStyle,
                        onClick = { onNavigateToTask(schedule.id) }
                    )
                }
            }
            
            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }
}

@Composable
fun DynamicHeader() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000L)
        }
    }
    val calendar = Calendar.getInstance().apply { time = now }
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val icon = when (hour) {
        in 5..11 -> "☀️"
        in 12..16 -> "🌤️"
        in 17..19 -> "🌇"
        else -> "🌙"
    }
    val format = if (android.text.format.DateFormat.is24HourFormat(LocalContext.current)) "HH:mm" else "hh:mm a"
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.ic_app_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "$icon ${SimpleDateFormat(format, Locale.getDefault()).format(now)}",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = XFlowAccent
        )
    }
}

@Composable
fun StatCardRow(todayHours: Float, lifetimeHours: Float, currentStreak: Int) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard("Today", TimeUtils.formatHours(todayHours), Modifier.weight(1f))
        StatCard("Total", TimeUtils.formatHours(lifetimeHours), Modifier.weight(1f))
        StatCard("Streak", "$currentStreak \uD83D\uDD25", Modifier.weight(1f))
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = XFlowSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = title, color = XFlowTextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, color = XFlowAccent, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun ScheduleCard(
    schedule: Schedule,
    isPremium: Boolean,
    cardStyle: String,
    onClick: () -> Unit
) {
    val isImageStyle = cardStyle == "Image" && schedule.isFromStudyPlan
    val isGradientStyle = cardStyle == "Gradient"
    val isOutlinedStyle = cardStyle == "Outlined"
    val isSoftStyle = cardStyle == "Soft"
    
    val finalContainerColor = when {
        isImageStyle || isGradientStyle -> Color.Transparent
        isSoftStyle -> XFlowSurfaceVariant.copy(alpha = 0.3f)
        isOutlinedStyle -> Color.Transparent
        else -> XFlowSurface
    }
    val defaultElev = when {
        isPremium -> 4.dp
        isOutlinedStyle || isSoftStyle -> 0.dp
        else -> 2.dp
    }
    val strokeWidth = when {
        isPremium -> 2.dp
        isOutlinedStyle -> 1.dp
        isSoftStyle -> 0.dp
        else -> 1.dp
    }
    val finalBorderColor = if (isOutlinedStyle) XFlowTextSecondary.copy(alpha=0.3f) else XFlowSurfaceVariant

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = finalContainerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = defaultElev),
        border = androidx.compose.foundation.BorderStroke(strokeWidth, finalBorderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.3f),
                                    Color(0xFF8B5CF6).copy(alpha = 0.3f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else if (isGradientStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.1f),
                                    XFlowSurface,
                                    XFlowAccent.copy(alpha = 0.05f)
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = schedule.subject,
                    style = MaterialTheme.typography.titleLarge,
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                if (schedule.isDurationMode) {
                    Text(
                        text = "Duration: ${schedule.durationMinutes} mins",
                        style = MaterialTheme.typography.bodyMedium,
                        color = XFlowTextSecondary
                    )
                } else {
                    Text(
                        text = "${schedule.startTimeStr} - ${schedule.endTimeStr}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = XFlowTextSecondary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { 
                        if (schedule.isDurationMode && schedule.durationMinutes > 0) {
                            (schedule.elapsedSeconds / (schedule.durationMinutes * 60f)).coerceIn(0f, 1f)
                        } else {
                            0f
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = XFlowAccent,
                    trackColor = XFlowSurfaceVariant
                )
            }
        }
    }
}

@Composable

fun Badge(text: String, isAccent: Boolean = false) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isAccent) XFlowSupport.copy(alpha=0.2f) else XFlowSurfaceVariant)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            color = if (isAccent) XFlowSupport else XFlowTextSecondary,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
