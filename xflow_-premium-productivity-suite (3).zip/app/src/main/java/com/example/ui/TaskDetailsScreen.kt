package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext

import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailsScreen(id: Int, viewModel: XFlowViewModel, onBack: () -> Unit) {
    val schedules by viewModel.activeSchedules.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showEditDialog by remember { mutableStateOf(false) }
    var showPremiumDialog by remember { mutableStateOf(false) }
    
    val schedule = schedules.find { it.id == id }

    if (schedule == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val targetTime = if (schedule.isDurationMode) {
        schedule.durationMinutes * 60
    } else {
        try {
            val startParts = schedule.startTimeStr.split(":")
            val endParts = schedule.endTimeStr.split(":")
            val startMins = startParts[0].toInt() * 60 + startParts[1].toInt()
            val endMins = endParts[0].toInt() * 60 + endParts[1].toInt()
            val diff = if (endMins >= startMins) endMins - startMins else (24 * 60 - startMins) + endMins
            diff * 60
        } catch(e:Exception) { 3600 }
    }

    val progress = if (targetTime > 0) (schedule.elapsedSeconds.toFloat() / targetTime).coerceIn(0f, 1f) else 0f
    val percentage = (progress * 100).toInt()

    val status = when {
        schedule.elapsedSeconds >= targetTime -> StudyStatus.COMPLETED
        schedule.isRunning -> StudyStatus.RUNNING
        schedule.elapsedSeconds > 0 -> StudyStatus.PAUSED
        else -> StudyStatus.UPCOMING
    }

    val elapsedTimeStr = String.format("%02d:%02d:%02d", schedule.elapsedSeconds / 3600, (schedule.elapsedSeconds % 3600) / 60, schedule.elapsedSeconds % 60)
    val totalTimeStr = String.format("%02d:%02d:%02d", targetTime / 3600, (targetTime % 3600) / 60, targetTime % 60)
    val remainingTime = if (targetTime > schedule.elapsedSeconds) targetTime - schedule.elapsedSeconds else 0
    val remainingTimeStr = String.format("%02d:%02d:%02d", remainingTime / 3600, (remainingTime % 3600) / 60, remainingTime % 60)

    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(400),
        label = "progress"
    )

    val scale = remember { Animatable(1f) }

    LaunchedEffect(status) {
        if (status == StudyStatus.COMPLETED) {
            scale.animateTo(1.02f, animationSpec = tween(150))
            scale.animateTo(1f, animationSpec = tween(150))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Task Details", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        scaleX = scale.value
                        scaleY = scale.value
                    },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = schedule.subject,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = XFlowTextPrimary
                        )
                        if (schedule.isFromStudyPlan) {
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.Default.WorkspacePremium, contentDescription = "Premium", tint = Color(0xFFFFD700))
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = schedule.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = XFlowTextSecondary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (schedule.isOnlineMode) "Online (${schedule.selectedAppPackage})" else "Offline Mode",
                        style = MaterialTheme.typography.bodySmall,
                        color = XFlowAccent
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when (status) {
                                StudyStatus.UPCOMING -> "Upcoming"
                                StudyStatus.RUNNING -> "In Progress"
                                StudyStatus.PAUSED -> "Paused"
                                StudyStatus.COMPLETED -> "Completed"
                                StudyStatus.MISSED -> "Missed"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (status == StudyStatus.COMPLETED) XFlowSupport else XFlowTextPrimary
                        )

                        if (status == StudyStatus.COMPLETED) {
                            Text(
                                text = getResultStatus(percentage),
                                color = XFlowSupport,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Text(
                                text = "$percentage%",
                                color = XFlowAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = XFlowAccent,
                        trackColor = XFlowSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    HorizontalDivider(color = XFlowSurfaceVariant)

                    Spacer(modifier = Modifier.height(16.dp))

                    DetailRow("Live Timer", elapsedTimeStr, isHighlight = status == StudyStatus.RUNNING)
                    DetailRow("Planned Time", totalTimeStr)
                    DetailRow("Remaining", remainingTimeStr)
                    
                    if (!schedule.isDurationMode) {
                        DetailRow("Start Time", schedule.startTimeStr)
                        DetailRow("End Time", schedule.endTimeStr)
                    }

                    if (status == StudyStatus.COMPLETED) {
                        Spacer(modifier = Modifier.height(16.dp))
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn(tween(300)) + scaleIn(tween(350))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(XFlowSupport.copy(alpha = 0.1f))
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "🎉 Session Successfully Completed!",
                                    color = XFlowSupport,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    
                    if (status == StudyStatus.UPCOMING && !schedule.hasBeenEdited) {
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = { 
                                if (isPremium) {
                                    showEditDialog = true
                                } else {
                                    showPremiumDialog = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Edit Schedule (One-time, PRO)")
                        }
                    }
                }
            }
        }
        
        if (showEditDialog && schedule != null) {
            EditScheduleDialog(
                schedule = schedule,
                onDismiss = { showEditDialog = false },
                onSave = { updatedSchedule ->
                    viewModel.updateSchedule(updatedSchedule.copy(hasBeenEdited = true))
                    showEditDialog = false
                    Toast.makeText(context, "Schedule updated successfully!", Toast.LENGTH_SHORT).show()
                }
            )
        }
        
        PremiumDialog(
            showDialog = showPremiumDialog,
            onDismiss = { showPremiumDialog = false },
            viewModel = viewModel
        )
    }
}

@Composable
fun DetailRow(label: String, value: String, isHighlight: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = XFlowTextSecondary, style = MaterialTheme.typography.bodyMedium)
        Text(
            text = value,
            color = if (isHighlight) XFlowAccent else XFlowTextPrimary,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Medium,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun EditScheduleDialog(schedule: com.example.data.Schedule, onDismiss: () -> Unit, onSave: (com.example.data.Schedule) -> Unit) {
    var subject by remember { mutableStateOf(schedule.subject) }
    var description by remember { mutableStateOf(schedule.description) }
    var isOnlineMode by remember { mutableStateOf(schedule.isOnlineMode) }
    var durationMinutes by remember { mutableStateOf(schedule.durationMinutes.toString()) }
    var selectedAppPackage by remember { mutableStateOf(schedule.selectedAppPackage ?: "") }
    
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XFlowBackground)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Edit Schedule", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = XFlowTextPrimary)
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = XFlowAccent,
                        unfocusedBorderColor = XFlowSurfaceVariant,
                        focusedLabelColor = XFlowAccent,
                        unfocusedLabelColor = XFlowTextSecondary,
                        focusedTextColor = XFlowTextPrimary,
                        unfocusedTextColor = XFlowTextPrimary
                    )
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = XFlowAccent,
                        unfocusedBorderColor = XFlowSurfaceVariant,
                        focusedLabelColor = XFlowAccent,
                        unfocusedLabelColor = XFlowTextSecondary,
                        focusedTextColor = XFlowTextPrimary,
                        unfocusedTextColor = XFlowTextPrimary
                    )
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                if (schedule.isDurationMode) {
                    OutlinedTextField(
                        value = durationMinutes,
                        onValueChange = { durationMinutes = it },
                        label = { Text("Duration (minutes)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = XFlowAccent,
                            unfocusedBorderColor = XFlowSurfaceVariant,
                            focusedLabelColor = XFlowAccent,
                            unfocusedLabelColor = XFlowTextSecondary,
                            focusedTextColor = XFlowTextPrimary,
                            unfocusedTextColor = XFlowTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text("Tracking Type", color = XFlowTextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(XFlowSurfaceVariant)
                        .padding(4.dp)
                ) {
                    val options = listOf("Online", "Offline")
                    options.forEachIndexed { index, option ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isOnlineMode == (index == 0)) XFlowSurface else XFlowSurfaceVariant)
                                .clickable { isOnlineMode = index == 0 }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = option,
                                color = if (isOnlineMode == (index == 0)) XFlowTextPrimary else XFlowTextSecondary,
                                fontWeight = if (isOnlineMode == (index == 0)) FontWeight.Bold else FontWeight.Medium,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = XFlowTextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (subject.isNotBlank()) {
                                onSave(schedule.copy(
                                    subject = subject,
                                    description = description,
                                    isOnlineMode = isOnlineMode,
                                    durationMinutes = durationMinutes.toIntOrNull() ?: schedule.durationMinutes
                                ))
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = Color.White)
                    ) {
                        Text("Save Changes")
                    }
                }
            }
        }
    }
}
