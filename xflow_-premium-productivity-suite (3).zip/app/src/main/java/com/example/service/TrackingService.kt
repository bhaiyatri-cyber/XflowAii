package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.data.Schedule
import com.example.data.XFlowDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar

class TrackingService : Service() {
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    
    private lateinit var db: XFlowDatabase
    
    private val CHANNEL_ID = "TrackingChannel"
    private val ALERT_CHANNEL_ID = "xflow_alerts_vibrate"
    private val NOTIFICATION_ID = 1
    
    private val upcomingNotifiedSchedules = mutableSetOf<Int>()
    
    private var isTrackingLoopRunning = false
    private var wakeLock: android.os.PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        db = XFlowDatabase.getDatabase(this)
        createNotificationChannel()
        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        wakeLock = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "XFlow::TrackingWakeLock")
        wakeLock?.acquire()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val scheduleId = intent?.getIntExtra("schedule_id", -1) ?: -1
        
        val notification = createNotification("Initializing...", "Starting tracker")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (!isTrackingLoopRunning) {
            startTrackingLoop()
        }

        return START_STICKY
    }

    private fun startTrackingLoop() {
        isTrackingLoopRunning = true
        serviceScope.launch {
            while (true) {
                val activeSchedules = db.dao().getActiveSchedulesSync()
                if (activeSchedules.isEmpty()) {
                    stopForeground(true)
                    stopSelf()
                    isTrackingLoopRunning = false
                    break
                }
                
                val currentApp = getForegroundApp()
                var trackingAny = false
                var titleText = "XFlow Active"
                var contentText = "Monitoring..."
                
                val cal = Calendar.getInstance()
                val currentHour = cal.get(Calendar.HOUR_OF_DAY)
                val currentMin = cal.get(Calendar.MINUTE)
                val currentTotalMins = currentHour * 60 + currentMin

                for (schedule in activeSchedules) {
                    val isDuration = schedule.isDurationMode
                    var targetTime = 0
                    var shouldTrack = false
                    var waitingReason = ""
                    var autoComplete = false

                    if (isDuration) {
                        targetTime = schedule.durationMinutes * 60
                        shouldTrack = true
                    } else {
                        try {
                            val startParts = schedule.startTimeStr.split(":")
                            val endParts = schedule.endTimeStr.split(":")
                            val startMins = startParts[0].toInt() * 60 + startParts[1].toInt()
                            val endMins = endParts[0].toInt() * 60 + endParts[1].toInt()
                            
                            var durationMins = endMins - startMins
                            if (durationMins < 0) durationMins += 24 * 60
                            targetTime = durationMins * 60

                            if (currentTotalMins in startMins..endMins || (endMins < startMins && (currentTotalMins >= startMins || currentTotalMins <= endMins))) {
                                shouldTrack = true
                            } else if (currentTotalMins > endMins && startMins < endMins) {
                                // Past time
                                autoComplete = true
                            } else if (currentTotalMins < startMins && startMins < endMins) {
                                waitingReason = "Starts at ${schedule.startTimeStr}"
                            }
                        } catch (e: Exception) {
                            targetTime = 60 * 60 // fallback to 1h
                            shouldTrack = true
                        }
                    }

                    if (autoComplete) {
                        db.dao().insertHistory(
                            com.example.data.HistorySession(
                                scheduleId = schedule.id,
                                subject = schedule.subject,
                                mode = "Exact Time",
                                date = System.currentTimeMillis(),
                                timeStudiedSeconds = schedule.elapsedSeconds,
                                completionPercentage = if (targetTime > 0) ((schedule.elapsedSeconds.toFloat() / targetTime.toFloat()) * 100).toInt().coerceIn(0, 100) else 100,
                                status = "Completed"
                            )
                        )
                        db.dao().deactivateSchedule(schedule.id)
                        sendAlertNotification(
                            "Goal Reached \uD83C\uDF89",
                            "You've completed your focus session for '${schedule.subject}'!",
                            schedule.id + 2000
                        )
                        continue
                    }
                    
                    if (!shouldTrack) {
                        db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                        titleText = "Scheduled: ${schedule.subject}"
                        contentText = waitingReason
                        continue
                    }

                    if (schedule.isOnlineMode && schedule.selectedAppPackage != null) {
                        if (schedule.selectedAppPackage == currentApp) {
                            trackingAny = true
                            if (schedule.elapsedSeconds < targetTime) {
                                // increment elapsed
                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                titleText = "Tracking: ${schedule.subject}"
                                contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                            } else {
                                // elapsed is at target, increment overtime
                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                titleText = "🔥 Overtime: ${schedule.subject}"
                                contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                            }
                        } else {
                            if (schedule.elapsedSeconds >= targetTime) {
                                // Exited app during overtime or right after finishing
                                db.dao().insertHistory(
                                    com.example.data.HistorySession(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        mode = if (isDuration) "Duration" else "Exact Time",
                                        date = System.currentTimeMillis(),
                                        timeStudiedSeconds = schedule.elapsedSeconds,
                                        completionPercentage = 100,
                                        status = "Completed"
                                    )
                                )
                                if (schedule.overtimeSeconds > 0) {
                                    db.dao().insertOvertimeEntry(
                                        com.example.data.OvertimeEntry(
                                            scheduleId = schedule.id,
                                            subject = schedule.subject,
                                            overtimeSeconds = schedule.overtimeSeconds,
                                            date = System.currentTimeMillis()
                                        )
                                    )
                                }
                                db.dao().deactivateSchedule(schedule.id)
                                sendAlertNotification(
                                    "Goal Reached \uD83C\uDF89",
                                    "You've completed your focus session for '${schedule.subject}'!",
                                    schedule.id + 2000
                                )
                            } else {
                                db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                            }
                        }
                    } else if (!schedule.isOnlineMode) {
                        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                        val isScreenOn = powerManager.isInteractive
                        
                        if (!isScreenOn) {
                            trackingAny = true
                            if (schedule.elapsedSeconds < targetTime) {
                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                titleText = "Offline Tracking: ${schedule.subject}"
                                contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                            } else {
                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                titleText = "🔥 Offline Overtime: ${schedule.subject}"
                                contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                            }
                        } else {
                            if (schedule.elapsedSeconds >= targetTime) {
                                db.dao().insertHistory(
                                    com.example.data.HistorySession(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        mode = if (isDuration) "Duration" else "Exact Time",
                                        date = System.currentTimeMillis(),
                                        timeStudiedSeconds = schedule.elapsedSeconds,
                                        completionPercentage = 100,
                                        status = "Completed"
                                    )
                                )
                                if (schedule.overtimeSeconds > 0) {
                                    db.dao().insertOvertimeEntry(
                                        com.example.data.OvertimeEntry(
                                            scheduleId = schedule.id,
                                            subject = schedule.subject,
                                            overtimeSeconds = schedule.overtimeSeconds,
                                            date = System.currentTimeMillis()
                                        )
                                    )
                                }
                                db.dao().deactivateSchedule(schedule.id)
                                sendAlertNotification(
                                    "Goal Reached \uD83C\uDF89",
                                    "You've completed your focus session for '${schedule.subject}'!",
                                    schedule.id + 2000
                                )
                            } else {
                                db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                            }
                        }
                    }
                }
                
                updateNotification(titleText, contentText)
                
                delay(1000)
            }
        }
    }

    private fun getForegroundApp(): String? {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val startTime = endTime - 1000 * 60 * 60 * 24L // last 24 hours
        
        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        var event = UsageEvents.Event()
        var foregroundPackage: String? = null
        
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                foregroundPackage = event.packageName
            } else if (event.eventType == UsageEvents.Event.ACTIVITY_PAUSED) {
                if (foregroundPackage == event.packageName) {
                    foregroundPackage = null
                }
            }
        }
        return foregroundPackage
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Tracking Service Channel",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
            
            val alertChannel = NotificationChannel(
                ALERT_CHANNEL_ID,
                "Alerts",
                NotificationManager.IMPORTANCE_HIGH
            )
            alertChannel.enableVibration(true)
            alertChannel.vibrationPattern = longArrayOf(0, 2000)
            manager.createNotificationChannel(alertChannel)
        }
    }

    private fun sendAlertNotification(title: String, text: String, id: Int) {
        try {
            val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setAutoCancel(true)
                .setVibrate(longArrayOf(0, 2000))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()
                
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Permission not granted, ignore
        }
    }

    private fun createNotification(title: String, text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .build()
    }
    
    private fun updateNotification(title: String, text: String) {
        val notification = createNotification(title, text)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
    }
}
