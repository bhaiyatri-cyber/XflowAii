with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

import re

# Update Schedule entity
old_entity = """    val studyPlanId: Int = 0,
    val creationDate: Long = System.currentTimeMillis()
)"""
new_entity = """    val studyPlanId: Int = 0,
    val creationDate: Long = System.currentTimeMillis(),
    val hasBeenEdited: Boolean = false
)"""
content = content.replace(old_entity, new_entity)

# Add updateSchedule to DAO
old_dao = """    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: Schedule): Long"""
new_dao = """    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: Schedule): Long
    
    @androidx.room.Update
    suspend fun updateSchedule(schedule: Schedule)"""
content = content.replace(old_dao, new_dao)

# Add Migration and bump version
old_version = "version = 5"
new_version = "version = 6"
content = content.replace(old_version, new_version)

old_db_builder = """                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    XFlowDatabase::class.java,
                    "xflow-db"
                )
                .fallbackToDestructiveMigration()
                .build()"""
new_db_builder = """                val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
                    override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                        database.execSQL("ALTER TABLE schedules ADD COLUMN hasBeenEdited INTEGER NOT NULL DEFAULT 0")
                    }
                }
                
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    XFlowDatabase::class.java,
                    "xflow-db"
                )
                .addMigrations(MIGRATION_5_6)
                .fallbackToDestructiveMigration()
                .build()"""
content = content.replace(old_db_builder, new_db_builder)

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)
