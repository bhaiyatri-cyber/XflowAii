import re

with open('app/src/main/java/com/example/ui/AppUpdateScreen.kt', 'r') as f:
    content = f.read()

new_features = """            } else if (updateInfo?.isAvailable == true) {
                Text(
                    text = "New Update Available: ${updateInfo.versionName}",
                    style = MaterialTheme.typography.titleLarge,
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = XFlowSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "App Features & Improvements:",
                            style = MaterialTheme.typography.titleMedium,
                            color = XFlowTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        val features = listOf(
                            "✨ AI Chatbot & Study Assistant",
                            "📄 PDF & Image to PDF Tools",
                            "📝 Mock Test Attempts",
                            "☁️ Cloud Backup & Restore",
                            "💾 Data Drive Storage",
                            "📅 Advanced Study Planner"
                        )
                        features.forEach { feature ->
                            Text(
                                text = feature,
                                style = MaterialTheme.typography.bodyMedium,
                                color = XFlowTextSecondary,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Button(
                    onClick = onUpdateNow,
                    colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {"""

content = re.sub(r'\} else if \(updateInfo\?\.isAvailable == true\) \{[\s\S]*?\} \) \{', new_features, content)

with open('app/src/main/java/com/example/ui/AppUpdateScreen.kt', 'w') as f:
    f.write(content)
