import re

with open('app/src/main/java/com/example/ui/UpdatePromptCard.kt', 'r') as f:
    content = f.read()

new_features = """            Text(
                text = "What's New in XFlow:",
                style = MaterialTheme.typography.bodyMedium,
                color = XFlowTextPrimary,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            val features = listOf(
                "✨ AI Chatbot & Study Assistant",
                "📄 PDF & Image to PDF Tools",
                "📝 Mock Test Attempts",
                "☁️ Cloud Backup & Restore",
                "💾 Data Drive Storage",
                "📅 Advanced Study Planner"
            )
            
            features.forEach { feature ->
                Text(
                    text = feature,
                    style = MaterialTheme.typography.bodyMedium,
                    color = XFlowTextSecondary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Release Notes: " + updateInfo.releaseNotes,
                style = MaterialTheme.typography.bodySmall,
                color = XFlowTextSecondary
            )"""

content = re.sub(r'Text\(\s*text = "What\'s New:".*?color = XFlowTextSecondary\s*\)', new_features, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/UpdatePromptCard.kt', 'w') as f:
    f.write(content)
