package com.example.ui

import androidx.compose.runtime.saveable.rememberSaveable


import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.rememberDrawerState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AiChat
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotScreen(
    navController: androidx.navigation.NavController,
    onBack: () -> Unit,
    viewModel: XFlowViewModel,
    aiViewModel: AiViewModel = viewModel()
) {
    var inputText by remember { mutableStateOf("") }
    val aiChats by aiViewModel.aiChats.collectAsStateWithLifecycle()
    val isGenerating by aiViewModel.isGenerating.collectAsStateWithLifecycle()
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    val scope = rememberCoroutineScope()
    var expanded by remember { mutableStateOf(false) }

    LaunchedEffect(aiChats.size, isGenerating) {
        if (aiChats.isNotEmpty()) {
            listState.animateScrollToItem(aiChats.size - 1)
        }
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val allSessions by aiViewModel.allSessions.collectAsStateWithLifecycle()
    val allMockTests by aiViewModel.allMockTests.collectAsStateWithLifecycle()
    
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = XFlowSurface) {
                Spacer(Modifier.height(16.dp))
                Text("Chat History", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = XFlowTextPrimary)
                Divider(color = XFlowSurfaceVariant)
                
                NavigationDrawerItem(
                    label = { Text("New Chat") },
                    selected = false,
                    onClick = {
                        aiViewModel.createNewSession()
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = XFlowAccent.copy(alpha=0.1f), unselectedIconColor = XFlowAccent, unselectedTextColor = XFlowAccent)
                )
                
                LazyColumn(modifier = Modifier.weight(1f)) {
                    item {
                        Text("Past Sessions", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleSmall, color = XFlowTextSecondary)
                    }
                    items(allSessions) { session ->
                        NavigationDrawerItem(
                            label = { Text(if (session == "default") "Main Chat" else "Session: ${session.takeLast(6)}") },
                            selected = aiViewModel.currentSessionId.value == session,
                            onClick = {
                                aiViewModel.loadSession(session)
                                scope.launch { drawerState.close() }
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = XFlowSurfaceVariant,
                                unselectedContainerColor = Color.Transparent,
                                selectedTextColor = XFlowTextPrimary,
                                unselectedTextColor = XFlowTextPrimary
                            )
                        )
                    }
                    if (allMockTests.isNotEmpty()) {
                        item {
                            Divider(color = XFlowSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
                            Text("Mock Tests", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleSmall, color = XFlowTextSecondary)
                        }
                        items(allMockTests) { test ->
                            NavigationDrawerItem(
                                label = { Text(test.title) },
                                badge = { if (test.isCompleted) Text("${test.score}/${test.totalQuestions}") else Text("Pending") },
                                selected = false,
                                onClick = {
                                    navController.navigate("mock_test/${test.id}")
                                    scope.launch { drawerState.close() }
                                },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                colors = NavigationDrawerItemDefaults.colors(
                                    unselectedContainerColor = Color.Transparent,
                                    unselectedTextColor = XFlowTextPrimary
                                )
                            )
                        }
                    }
                }
            }
        }
    ) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("XFlow AI Assistant", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { expanded = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Menu", tint = Color.White)
                    }
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        containerColor = XFlowSurfaceVariant
                    ) {
                        DropdownMenuItem(
                            text = { Text("Clear Chat", color = XFlowTextPrimary) },
                            onClick = {
                                aiViewModel.clearChat()
                                expanded = false
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (aiChats.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = XFlowAccent, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text("How can I help you focus today?", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Powered by Gemini AI", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                
                items(aiChats) { chat ->
                    ChatBubble(chat = chat, navController = navController)
                }

                if (isGenerating) {
                    item {
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "AI",
                                tint = XFlowAccent,
                                modifier = Modifier.size(24.dp).padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            TypingIndicator()
                        }
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask a question...", color = XFlowTextSecondary) },
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = XFlowAccent,
                        unfocusedBorderColor = XFlowSurfaceVariant,
                        focusedContainerColor = XFlowSurfaceVariant,
                        unfocusedContainerColor = XFlowSurfaceVariant,
                        focusedTextColor = XFlowTextPrimary,
                        unfocusedTextColor = XFlowTextPrimary
                    ),
                    maxLines = 3
                )
                Spacer(modifier = Modifier.width(8.dp))
                FloatingActionButton(
                    onClick = {
                        if (inputText.isNotBlank() && !isGenerating) {
                            val msg = inputText
                            inputText = ""
                            aiViewModel.sendMessage(msg)
                        }
                    },
                    modifier = Modifier.size(48.dp),
                    containerColor = XFlowAccent,
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                }
            }
        }
    }
    } // End ModalNavigationDrawer
}

@Composable
fun ChatBubble(chat: AiChat, navController: androidx.navigation.NavController) {
    val isUser = chat.role == "user"
    
    if (chat.message.startsWith("[MOCK_TEST_CARD:")) {
        val parts = chat.message.removePrefix("[MOCK_TEST_CARD:").removeSuffix("]").split(":", limit = 2)
        if (parts.size == 2) {
            val testId = parts[0]
            val title = parts[1]
            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
                Card(
                    modifier = Modifier.fillMaxWidth(0.85f).clickable {
                        navController.navigate("mock_test/$testId")
                    },
                    colors = CardDefaults.cardColors(containerColor = XFlowSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(androidx.compose.material.icons.Icons.Filled.AutoAwesome, contentDescription = null, tint = XFlowAccent, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("AI Mock Test Generated", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                            Text(title, color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            return
        }
    }
    
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        if (isUser) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = 16.dp,
                        bottomEnd = 4.dp
                    ))
                    .background(XFlowAccent)
                    .padding(12.dp)
            ) {
                Text(
                    text = chat.message,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "AI",
                    tint = XFlowAccent,
                    modifier = Modifier.size(24.dp).padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                TypewriterText(
                    text = chat.message,
                    modifier = Modifier.weight(1f).padding(top = 2.dp)
                )
            }
        }
    }
}

@Composable
fun TypewriterText(text: String, modifier: Modifier = Modifier) {
    var textToDisplay by remember { mutableStateOf("") }
    var isFinished by rememberSaveable(text) { mutableStateOf(false) }
    var cursorVisible by remember { mutableStateOf(true) }

    LaunchedEffect(text) {
        if (isFinished) {
            textToDisplay = text
            return@LaunchedEffect
        }
        textToDisplay = ""
        
        val cursorJob = launch {
            while (true) {
                cursorVisible = !cursorVisible
                delay(300)
            }
        }
        
        val chars = text.toCharArray()
        for (i in chars.indices) {
            textToDisplay += chars[i]
            delay(15) 
        }
        
        isFinished = true
        cursorJob.cancel()
        cursorVisible = false
    }

    Text(
        text = textToDisplay + if (!isFinished && cursorVisible) " ▌" else "",
        color = XFlowTextPrimary,
        style = MaterialTheme.typography.bodyLarge,
        modifier = modifier
    )
}

@Composable
fun TypingIndicator() {
    val infiniteTransition = rememberInfiniteTransition()
    val alpha1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )
    val alpha2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing, delayMillis = 200),
            repeatMode = RepeatMode.Reverse
        )
    )
    val alpha3 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing, delayMillis = 400),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha1)))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha2)))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha3)))
    }
}
