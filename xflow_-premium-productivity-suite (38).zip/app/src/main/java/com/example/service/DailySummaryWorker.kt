package com.example.service

import android.content.Context
import com.example.R
import android.graphics.BitmapFactory
import android.os.Build
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.ExistingWorkPolicy
import androidx.core.app.NotificationCompat
import android.app.NotificationManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import com.example.data.XFlowDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import java.util.Calendar
import java.util.concurrent.TimeUnit

class DailySummaryWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            
            val prefs = context.getSharedPreferences("xflow_prefs", Context.MODE_PRIVATE)
            val isPremium = prefs.getBoolean("is_premium", false)
            
            if (!isPremium) {
                return@withContext Result.success()
            }

            val db = XFlowDatabase.getDatabase(context)
            val dao = db.dao()
            
            val cal = Calendar.getInstance()
            // We consider 'today' as the day that just ended since this runs around midnight.
            // If it runs at 00:00 - 02:00, we want yesterday's stats.
            if (cal.get(Calendar.HOUR_OF_DAY) < 4) {
                cal.add(Calendar.DAY_OF_YEAR, -1)
            }
            
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val startOfDay = cal.timeInMillis
            
            cal.set(Calendar.HOUR_OF_DAY, 23)
            cal.set(Calendar.MINUTE, 59)
            cal.set(Calendar.SECOND, 59)
            cal.set(Calendar.MILLISECOND, 999)
            val endOfDay = cal.timeInMillis

            val history = dao.getAllHistorySync().filter { it.date in startOfDay..endOfDay }
            val overtime = dao.getAllOvertimeEntries().first().filter { it.date in startOfDay..endOfDay }
            
            val totalSeconds = history.sumOf { it.timeStudiedSeconds } + overtime.sumOf { it.overtimeSeconds }
            
            if (totalSeconds > 0) {
                val h = totalSeconds / 3600
                val m = (totalSeconds % 3600) / 60
                
                val timeString = if (h > 0) "${h}h ${m}m" else "${m}m"
                val title = "🌙 Day Complete (PRO)"
                val message = "Great job today! You focused for $timeString. Rest well for tomorrow! 🚀"
                
                sendPremiumNotification(title, message, 10001)
            }
            
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        } finally {
            scheduleNext(context)
        }
    }
    
    private fun sendPremiumNotification(title: String, text: String, id: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    "xflow_daily_vibrate",
                    "Daily Summary",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                val manager = context.getSystemService(NotificationManager::class.java)
                channel.enableVibration(true)
                channel.vibrationPattern = longArrayOf(0, 2000)
                manager?.createNotificationChannel(channel)
            }
            
            val notification = NotificationCompat.Builder(context, "xflow_daily_vibrate")
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.star_on) // using a star icon for premium look
                .setColor(0xFFFFD700.toInt()) // Gold color
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setVibrate(longArrayOf(0, 2000))
                .build()
                
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Ignore
        }
    }
    
    companion object {
        fun scheduleNext(context: Context) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, 1)
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            
            var delay = cal.timeInMillis - System.currentTimeMillis()
            if (delay < 0) { // Should not happen, but just in case
                delay += 86400000
            }
            
            val req = OneTimeWorkRequestBuilder<DailySummaryWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .build()
                
            WorkManager.getInstance(context).enqueueUniqueWork(
                "DailySummaryWorker",
                ExistingWorkPolicy.REPLACE,
                req
            )
        }
    }
}
