package com.example.service

import android.content.Context
import com.example.R
import android.graphics.BitmapFactory
import android.content.Intent
import android.os.Build
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.core.app.NotificationCompat
import android.app.NotificationManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.net.Uri
import com.example.data.XFlowDatabase
import com.example.data.HistorySession
import com.example.data.Schedule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

class SchedulingWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val db = XFlowDatabase.getDatabase(context)
            val dao = db.dao()
            
            val plans = dao.getAllStudyPlans()
            val currentDayMillis = getCurrentDay()
            
            var generatedAny = false
            for (plan in plans) {
                if (plan.lastGeneratedDay < currentDayMillis) {
                    val creationDay = Calendar.getInstance().apply { timeInMillis = plan.createdAt; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                    val daysSinceCreation = (currentDayMillis - creationDay) / 86400000
                    if (plan.recurrenceDays == -1 || daysSinceCreation <= plan.recurrenceDays) {
                        val items = dao.getStudyPlanItems(plan.id)
                        for (item in items) {
                            val schedule = Schedule(
                                subject = item.subject,
                                description = item.description,
                                isDurationMode = false,
                                durationMinutes = 0,
                                startTimeStr = item.startTimeStr,
                                endTimeStr = item.endTimeStr,
                                isOnlineMode = item.isOnlineMode,
                                selectedAppPackage = item.selectedAppPackage,
                                isActive = true,
                                isFromStudyPlan = true,
                                studyPlanId = plan.id,
                                creationDate = System.currentTimeMillis()
                            )
                            dao.insertSchedule(schedule)
                        }
                        dao.updateStudyPlanGeneratedDay(plan.id, currentDayMillis)
                        generatedAny = true
                    }
                }
            }
            
            if (generatedAny) {
                val activeSchedules = dao.getActiveSchedulesSync()
                for (schedule in activeSchedules) {
                    if (schedule.creationDate < currentDayMillis && schedule.isFromStudyPlan) {
                        dao.insertHistory(
                            HistorySession(
                                scheduleId = schedule.id,
                                subject = schedule.subject,
                                mode = "Exact Time",
                                date = schedule.creationDate,
                                timeStudiedSeconds = schedule.elapsedSeconds,
                                completionPercentage = if (schedule.elapsedSeconds > 0) 50 else 0,
                                status = if (schedule.elapsedSeconds > 0) "Partial" else "Missed"
                            )
                        )
                        dao.deactivateSchedule(schedule.id)
                    }
                }
            }

            // Check upcoming schedules for notifications
            val activeSchedules = dao.getActiveSchedulesSync()
            if (activeSchedules.isNotEmpty()) {
                val cal = Calendar.getInstance()
                val currMins = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
                
                for (schedule in activeSchedules) {
                    if (!schedule.isDurationMode) {
                        try {
                            val startParts = schedule.startTimeStr.split(":")
                            val startMins = startParts[0].toInt() * 60 + startParts[1].toInt()
                            val diffStart = startMins - currMins
                            
                            // If starting in the next 15 minutes, send notification
                            if (diffStart in 0..15) {
                                sendAlertNotification(
                                    "Upcoming Focus Session",
                                    "Your schedule '${schedule.subject}' starts in $diffStart minutes.",
                                    schedule.id + 5000
                                )
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }

                // Try to start TrackingService
                val intent = Intent(context, TrackingService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        context.startForegroundService(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                    context.startService(intent)
                }
            }

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }

    private fun getCurrentDay(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun sendAlertNotification(title: String, text: String, id: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    "xflow_alerts_vibrate",
                    "Alerts",
                    NotificationManager.IMPORTANCE_HIGH
                )
                val manager = context.getSystemService(NotificationManager::class.java)
                channel.enableVibration(true)
                channel.vibrationPattern = longArrayOf(0, 2000)
                manager?.createNotificationChannel(channel)
            }
            val notification = NotificationCompat.Builder(context, "xflow_alerts_vibrate")
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setVibrate(longArrayOf(0, 2000))
                .build()
                
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Ignore
        }
    }
}
