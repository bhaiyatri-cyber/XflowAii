import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

old_logic = """    if (showWhatsNew) {
        WhatsNewScreen(onDismiss = {
            showWhatsNew = false
            prefs.edit().putInt("last_opened_version", currentVersion).apply()
        })
        return
    }"""

new_logic = """    if (showWhatsNew) {
        WhatsNewScreen(
            isFirstInstall = lastOpenedVersion == 0,
            onDismiss = {
                showWhatsNew = false
                prefs.edit().putInt("last_opened_version", currentVersion).apply()
            }
        )
        return
    }"""

content = content.replace(old_logic, new_logic)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)

