with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace('versionCode = 70', 'versionCode = 71').replace('versionName = "70.0"', 'versionName = "71.0"')

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)

