with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace('versionCode = 69', 'versionCode = 70').replace('versionName = "69.0"', 'versionName = "70.0"')

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)

