import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

old_history = """                // Construct history
                val history = aiChats.value.takeLast(10).map { 
                     Content(role = it.role, parts = listOf(Part(text = it.message))) 
                 }.toMutableList()
                history.add(Content(role = "user", parts = listOf(Part(text = prompt))))"""

new_history = """                // Construct history carefully to avoid race conditions with Flow and ensure alternating roles
                val safeChats = aiChats.value.toMutableList()
                // Remove the message we just inserted if it's already in the flow
                if (safeChats.isNotEmpty() && safeChats.last().role == "user" && safeChats.last().message == message) {
                    safeChats.removeLast()
                }
                
                // Ensure we only take the last 10 messages, and ensure the first one is a 'user' message
                var historySubList = safeChats.takeLast(10).toMutableList()
                while (historySubList.isNotEmpty() && historySubList.first().role != "user") {
                    historySubList.removeFirst()
                }
                
                // Ensure strict alternation (User, Model, User, Model)
                val alternatingChats = mutableListOf<AiChat>()
                var expectedRole = "user"
                for (chat in historySubList) {
                    if (chat.role == expectedRole) {
                        alternatingChats.add(chat)
                        expectedRole = if (expectedRole == "user") "model" else "user"
                    }
                }
                
                val history = alternatingChats.map { 
                     Content(role = it.role, parts = listOf(Part(text = it.message))) 
                 }.toMutableList()
                history.add(Content(role = "user", parts = listOf(Part(text = prompt))))"""

content = content.replace(old_history, new_history)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
