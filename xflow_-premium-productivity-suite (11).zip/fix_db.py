with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    db = f.read()

db = db.replace('@Entity(tableName = "ai_chats")\\n@Entity(tableName = "offline_chats")\\ndata class OfflineChat',
                '@Entity(tableName = "offline_chats")\\ndata class OfflineChat')

db = db.replace('\\ndata class AiChat', '\\n@Entity(tableName = "ai_chats")\\ndata class AiChat')

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(db)
