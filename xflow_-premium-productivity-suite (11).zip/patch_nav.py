with open('app/src/main/java/com/example/ui/Navigation.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import androidx.navigation.compose.rememberNavController',
    'import androidx.navigation.compose.rememberNavController\nimport androidx.navigation.navDeepLink'
)

old_home = "composable(Routes.HOME) {"
new_home = """composable(
            Routes.HOME,
            deepLinks = listOf(navDeepLink { uriPattern = "xflow://home" })
        ) {"""
content = content.replace(old_home, new_home)

old_mock = "composable(Routes.MOCK_TEST) {"
new_mock = """composable(
            Routes.MOCK_TEST,
            deepLinks = listOf(navDeepLink { uriPattern = "xflow://mock_test/{id}" })
        ) {"""
content = content.replace(old_mock, new_mock)

with open('app/src/main/java/com/example/ui/Navigation.kt', 'w') as f:
    f.write(content)
