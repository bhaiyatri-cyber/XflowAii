with open('app/src/main/java/com/example/data/GeminiApi.kt', 'r') as f:
    content = f.read()

import re
old_gen_config = """@Serializable
data class GenerationConfig(
    val responseFormat: ResponseFormat? = null,
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null,
    val responseModalities: List<String>? = null
)"""

new_gen_config = """@Serializable
data class GenerationConfig(
    val responseMimeType: String? = null,
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null,
    val responseModalities: List<String>? = null
)"""
content = content.replace(old_gen_config, new_gen_config)

with open('app/src/main/java/com/example/data/GeminiApi.kt', 'w') as f:
    f.write(content)
