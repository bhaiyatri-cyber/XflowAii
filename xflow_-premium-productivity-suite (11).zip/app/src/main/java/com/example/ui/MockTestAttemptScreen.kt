package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.data.MockTest
import com.example.data.XFlowDatabase
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockTestAttemptScreen(navController: NavController, testId: Int) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val db = XFlowDatabase.getDatabase(context)
    val scope = rememberCoroutineScope()
    
    var mockTest by remember { mutableStateOf<MockTest?>(null) }
    var testData by remember { mutableStateOf<JSONObject?>(null) }
    
    // State for user answers: map of question index to selected option index
    var userAnswers by remember { mutableStateOf(mapOf<Int, Int>()) }
    var isSubmitted by remember { mutableStateOf(false) }

    LaunchedEffect(testId) {
        val test = withContext(Dispatchers.IO) { db.dao().getMockTestById(testId) }
        mockTest = test
        isSubmitted = test?.isCompleted == true
        
        if (test != null) {
            try {
                testData = JSONObject(test.testDataJson)
                // Load existing answers if any
                val savedAnswers = JSONObject(test.userAnswersJson)
                val currentAnswers = mutableMapOf<Int, Int>()
                savedAnswers.keys().forEach { key ->
                    currentAnswers[key.toInt()] = savedAnswers.getInt(key)
                }
                userAnswers = currentAnswers
            } catch (e: Exception) {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(testData?.optString("title", "Mock Test") ?: "Loading...", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        if (mockTest == null || testData == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = XFlowAccent)
            }
        } else {
            val questions = testData!!.optJSONArray("questions")
            
            Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                
                if (isSubmitted) {
                    // Result Header
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = XFlowSurface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Test Submitted", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Score: ${mockTest?.score ?: 0} / ${questions?.length() ?: 0}", color = XFlowAccent, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                
                LazyColumn(
                    modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    val count = questions?.length() ?: 0
                    items(count) { i ->
                        val qObj = questions!!.optJSONObject(i)
                        val qText = qObj?.optString("q") ?: ""
                        val options = qObj?.optJSONArray("options")
                        val correctIndex = qObj?.optInt("answerIndex", -1) ?: -1
                        val selectedIndex = userAnswers[i]

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = XFlowSurface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Q${i + 1}. $qText", color = XFlowTextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                val optionsCount = options?.length() ?: 0
                                for (optIdx in 0 until optionsCount) {
                                    val optText = options!!.optString(optIdx)
                                    
                                    val isSelected = selectedIndex == optIdx
                                    val isCorrect = correctIndex == optIdx
                                    
                                    val bgColor = if (isSubmitted) {
                                        if (isCorrect) Color(0xFF4CAF50).copy(alpha = 0.2f)
                                        else if (isSelected) Color(0xFFF44336).copy(alpha = 0.2f)
                                        else XFlowSurfaceVariant
                                    } else {
                                        if (isSelected) XFlowAccent.copy(alpha = 0.2f) else XFlowSurfaceVariant
                                    }
                                    
                                    val borderColor = if (isSubmitted) {
                                        if (isCorrect) Color(0xFF4CAF50)
                                        else if (isSelected) Color(0xFFF44336)
                                        else Color.Transparent
                                    } else {
                                        if (isSelected) XFlowAccent else Color.Transparent
                                    }

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(bgColor)
                                            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                                            .clickable(enabled = !isSubmitted) {
                                                userAnswers = userAnswers.toMutableMap().apply { put(i, optIdx) }
                                            }
                                            .padding(12.dp)
                                    ) {
                                        Text(optText, color = XFlowTextPrimary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            if (!isSubmitted) {
                var showConfirmDialog by remember { mutableStateOf(false) }
                
                if (showConfirmDialog) {
                    AlertDialog(
                        onDismissRequest = { showConfirmDialog = false },
                        title = { Text("Submit Test", color = XFlowTextPrimary) },
                        text = { Text("Are you sure you want to submit your test?", color = XFlowTextSecondary) },
                        confirmButton = {
                            TextButton(onClick = {
                                showConfirmDialog = false
                                scope.launch {
                                    // Calculate score
                                    var score = 0
                                    val total = questions?.length() ?: 0
                                    val answersJson = JSONObject()
                                    
                                    for (i in 0 until total) {
                                        val correctIndex = questions!!.optJSONObject(i)?.optInt("answerIndex", -1) ?: -1
                                        val selected = userAnswers[i]
                                        if (selected != null) {
                                            answersJson.put(i.toString(), selected)
                                            if (selected == correctIndex) score++
                                        }
                                    }
                                    
                                    val updatedTest = mockTest!!.copy(
                                        score = score,
                                        totalQuestions = total,
                                        isCompleted = true,
                                        userAnswersJson = answersJson.toString()
                                    )
                                    withContext(Dispatchers.IO) {
                                        db.dao().updateMockTest(updatedTest)
                                    }
                                    mockTest = updatedTest
                                    isSubmitted = true
                                }
                            }) {
                                Text("Submit", color = XFlowAccent)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showConfirmDialog = false }) {
                                Text("Cancel", color = XFlowTextSecondary)
                            }
                        },
                        containerColor = XFlowSurface
                    )
                }
                
                Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.BottomCenter) {
                    Button(
                        onClick = { showConfirmDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent)
                    ) {
                        Text("Submit Test", color = Color.White)
                    }
                }
            }

        }
    }
}
