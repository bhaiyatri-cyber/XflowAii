import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

old_logic = """                // Construct history
                val history = aiChats.value.takeLast(10).map { 
                     Content(role = it.role, parts = listOf(Part(text = it.message))) 
                 }.toMutableList()
                history.add(Content(role = "user", parts = listOf(Part(text = prompt))))"""

new_logic = """                // Construct history carefully to ensure strictly alternating roles for Gemini
                val currentChats = aiChats.value.toList()
                // The newly inserted user message might or might not be in currentChats yet due to StateFlow delay.
                // We'll filter out the current message if it's there at the end.
                val filteredChats = if (currentChats.isNotEmpty() && currentChats.last().role == "user" && currentChats.last().message == message) {
                    currentChats.dropLast(1)
                } else {
                    currentChats
                }

                // Get last 10 messages
                val recentChats = filteredChats.takeLast(10).toMutableList()
                
                // Ensure the list starts with a user message (if we are sending history)
                while (recentChats.isNotEmpty() && recentChats.first().role != "user") {
                    recentChats.removeFirst()
                }

                // Ensure strictly alternating roles
                val alternatingChats = mutableListOf<AiChat>()
                var expectedRole = "user"
                for (chat in recentChats) {
                    if (chat.role == expectedRole) {
                        alternatingChats.add(chat)
                        expectedRole = if (expectedRole == "user") "model" else "user"
                    }
                }

                // If the last appended was a user message (because we dropped the model message or something),
                // we should drop it so the final prompt is the user message
                if (alternatingChats.isNotEmpty() && alternatingChats.last().role == "user") {
                    alternatingChats.removeLast()
                }

                val history = alternatingChats.map { 
                     Content(role = it.role, parts = listOf(Part(text = it.message))) 
                 }.toMutableList()
                 
                history.add(Content(role = "user", parts = listOf(Part(text = prompt))))"""

if old_logic in content:
    content = content.replace(old_logic, new_logic)
    with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
        f.write(content)
    print("Patched successfully")
else:
    print("Could not find the target code to patch")
