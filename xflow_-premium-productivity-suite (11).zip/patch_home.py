import re
with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Replace the block of `if (showPremiumDialog) { ... }` with `PremiumDialog(...)`
# Also remove `PremiumFeatureRow` since it's now in `PremiumDialog.kt`

# Find the `if (showPremiumDialog)` block
pattern_dialog = r'\s*if\s*\(showPremiumDialog\)\s*\{.*?Dialog.*?Maybe Later.*?\}\s*\}\s*\}\s*\}\s*\}'
content = re.sub(pattern_dialog, '\n    PremiumDialog(showPremiumDialog, { showPremiumDialog = false }, viewModel)', content, flags=re.DOTALL)

# Find and remove PremiumFeatureRow
pattern_row = r'@Composable\s*fun PremiumFeatureRow.*?\}'
content = re.sub(pattern_row, '', content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
