import re

with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

# Replace variables before loop
old_vars = """                val currentApp = getForegroundApp()
                var trackingAny = false
                var titleText = "XFlow Active"
                var contentText = "Monitoring..."
                
                val cal = Calendar.getInstance()"""

new_vars = """                val currentApp = getForegroundApp()
                var trackingAny = false
                var bestPriority = -1
                var bestUpcomingMins = Int.MAX_VALUE
                var titleText = "XFlow Active"
                var contentText = "Monitoring..."
                
                val cal = Calendar.getInstance()"""
content = content.replace(old_vars, new_vars)

# Replace !shouldTrack
old_not_track = """                    if (!shouldTrack) {
                        db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                        titleText = "Scheduled: ${schedule.subject}"
                        contentText = waitingReason
                        continue
                    }"""

new_not_track = """                    if (!shouldTrack) {
                        db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                        val startMins = try {
                            val parts = schedule.startTimeStr.split(":")
                            parts[0].toInt() * 60 + parts[1].toInt()
                        } catch (e: Exception) { Int.MAX_VALUE }
                        
                        if (bestPriority < 1 && startMins < bestUpcomingMins) {
                            bestPriority = 0
                            bestUpcomingMins = startMins
                            titleText = "Scheduled: ${schedule.subject}"
                            contentText = waitingReason
                        }
                        continue
                    }"""
content = content.replace(old_not_track, new_not_track)

# Replace active tracking (online < target)
old_online_tracking = """                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                titleText = "Tracking: ${schedule.subject}"
                                contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                            } else {"""
new_online_tracking = """                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Tracking: ${schedule.subject}"
                                    contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                                }
                            } else {"""
content = content.replace(old_online_tracking, new_online_tracking)

# Replace active overtime (online)
old_online_overtime = """                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                titleText = "🔥 Overtime: ${schedule.subject}"
                                contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                            }
                        } else {"""
new_online_overtime = """                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "🔥 Overtime: ${schedule.subject}"
                                    contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                                }
                            }
                        } else {"""
content = content.replace(old_online_overtime, new_online_overtime)

# Replace ready (online)
old_online_ready = """                            } else {
                                db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                            }
                        }
                    } else if (!schedule.isOnlineMode) {"""
new_online_ready = """                            } else {
                                db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                                if (bestPriority < 1) {
                                    bestPriority = 1
                                    titleText = "Ready: ${schedule.subject}"
                                    contentText = "Open ${schedule.selectedAppPackage} to start"
                                }
                            }
                        }
                    } else if (!schedule.isOnlineMode) {"""
content = content.replace(old_online_ready, new_online_ready)

# Replace active tracking (offline < target)
old_offline_tracking = """                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                titleText = "Offline Tracking: ${schedule.subject}"
                                contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                            } else {"""
new_offline_tracking = """                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Offline Tracking: ${schedule.subject}"
                                    contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                                }
                            } else {"""
content = content.replace(old_offline_tracking, new_offline_tracking)

# Replace active overtime (offline)
old_offline_overtime = """                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                titleText = "🔥 Offline Overtime: ${schedule.subject}"
                                contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                            }
                        } else {"""
new_offline_overtime = """                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "🔥 Offline Overtime: ${schedule.subject}"
                                    contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                                }
                            }
                        } else {"""
content = content.replace(old_offline_overtime, new_offline_overtime)

# Replace ready (offline)
old_offline_ready = """                            } else {
                                db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                            }
                        }
                    }
                }
                
                updateNotification(titleText, contentText)"""
new_offline_ready = """                            } else {
                                db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                                if (bestPriority < 1) {
                                    bestPriority = 1
                                    titleText = "Ready: ${schedule.subject}"
                                    contentText = "Turn off screen to start"
                                }
                            }
                        }
                    }
                }
                
                updateNotification(titleText, contentText)"""
content = content.replace(old_offline_ready, new_offline_ready)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)

