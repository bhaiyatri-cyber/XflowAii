with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'fun SettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToPdf: () -> Unit, onNavigateToPermissions: () -> Unit, onNavigateToAbout: () -> Unit, onNavigateToBackup: () -> Unit, onNavigateToThemeSettings: () -> Unit)',
    'fun SettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToPdf: () -> Unit, onNavigateToPermissions: () -> Unit, onNavigateToAbout: () -> Unit, onNavigateToBackup: () -> Unit, onNavigateToThemeSettings: () -> Unit, onNavigateToOvertime: () -> Unit)'
)

content = content.replace(
    'SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { if (isPremium) onNavigateToPdf() else showPremiumDialog = true })',
    'SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { if (isPremium) onNavigateToPdf() else showPremiumDialog = true })\n                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "🔥 Overtime (PRO)", onClick = { if (isPremium) onNavigateToOvertime() else showPremiumDialog = true })'
)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)
