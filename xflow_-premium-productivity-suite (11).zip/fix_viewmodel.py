import re

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

# Add overtimeEntries
content = content.replace(
    'val history: StateFlow<List<HistorySession>> = db.dao().getAllHistory()',
    'val history: StateFlow<List<HistorySession>> = db.dao().getAllHistory()\n        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())\n\n    val overtimeEntries: StateFlow<List<com.example.data.OvertimeEntry>> = db.dao().getAllOvertimeEntries()'
)

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(content)
