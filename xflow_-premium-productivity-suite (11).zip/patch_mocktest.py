import re

with open('app/src/main/java/com/example/ui/MockTestAttemptScreen.kt', 'r') as f:
    content = f.read()

# add border import
if 'import androidx.compose.foundation.border' not in content:
    content = content.replace('import androidx.compose.foundation.background', 'import androidx.compose.foundation.background\nimport androidx.compose.foundation.border')

old_code = """                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(bgColor)
                                            .let {
                                                if (borderColor != Color.Transparent) {
                                                    it.then(Modifier.background(borderColor.copy(alpha = 0.1f))) // Simple border effect via background overlay
                                                } else it
                                            }
                                            .clickable(enabled = !isSubmitted) {
                                                userAnswers = userAnswers.toMutableMap().apply { put(i, optIdx) }
                                            }
                                            .padding(12.dp)
                                    )"""

new_code = """                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(bgColor)
                                            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                                            .clickable(enabled = !isSubmitted) {
                                                userAnswers = userAnswers.toMutableMap().apply { put(i, optIdx) }
                                            }
                                            .padding(12.dp)
                                    )"""

content = content.replace(old_code, new_code)

with open('app/src/main/java/com/example/ui/MockTestAttemptScreen.kt', 'w') as f:
    f.write(content)
