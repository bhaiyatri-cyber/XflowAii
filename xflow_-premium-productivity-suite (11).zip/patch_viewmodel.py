with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import androidx.lifecycle.viewModelScope',
    'import androidx.lifecycle.viewModelScope\nimport com.example.BuildConfig'
)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
