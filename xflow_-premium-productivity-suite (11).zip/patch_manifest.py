import re

with open('app/src/main/AndroidManifest.xml', 'r') as f:
    content = f.read()

intent_filter = """            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="xflow" />
            </intent-filter>
"""
content = content.replace('            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />', intent_filter + '            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />')

with open('app/src/main/AndroidManifest.xml', 'w') as f:
    f.write(content)
