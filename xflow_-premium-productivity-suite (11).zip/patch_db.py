with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

# Add entities
entities_code = """
@Entity(tableName = "mock_tests")
data class MockTest(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val testDataJson: String,
    val date: Long,
    val score: Int? = null,
    val totalQuestions: Int = 0,
    val isCompleted: Boolean = false,
    val userAnswersJson: String = "{}"
)

@Entity(tableName = "ai_chats")
data class AiChat(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val role: String, // "user" or "model"
    val message: String,
    val timestamp: Long
)

@Dao
"""
content = content.replace('@Dao', entities_code)

# Add dao methods
dao_code = """
    @Query("SELECT * FROM ai_chats ORDER BY timestamp ASC")
    fun getAllAiChats(): Flow<List<AiChat>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAiChat(chat: AiChat)

    @Query("SELECT * FROM mock_tests ORDER BY date DESC")
    fun getAllMockTests(): Flow<List<MockTest>>

    @Query("SELECT * FROM mock_tests WHERE id = :id")
    suspend fun getMockTestById(id: Int): MockTest?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMockTest(test: MockTest): Long
    
    @androidx.room.Update
    suspend fun updateMockTest(test: MockTest)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
"""
content = content.replace('@Insert(onConflict = OnConflictStrategy.REPLACE)\n    suspend fun insertSchedule', dao_code + 'suspend fun insertSchedule')

# Update database annotation
content = content.replace('entities = [Schedule::class, HistorySession::class, StudyPlan::class, StudyPlanItem::class, OvertimeEntry::class], version = 6', 'entities = [Schedule::class, HistorySession::class, StudyPlan::class, StudyPlanItem::class, OvertimeEntry::class, MockTest::class, AiChat::class], version = 7')

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)
