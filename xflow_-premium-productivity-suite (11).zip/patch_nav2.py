with open('app/src/main/java/com/example/ui/Navigation.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'AiScreen(navController = navController)',
    'AiScreen(navController = navController, xFlowViewModel = viewModel)'
)

with open('app/src/main/java/com/example/ui/Navigation.kt', 'w') as f:
    f.write(content)
