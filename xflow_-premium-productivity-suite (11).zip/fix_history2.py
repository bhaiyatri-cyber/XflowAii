import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

pattern = re.compile(r'// Construct history.*?history\.add\(Content\(role = "user", parts = listOf\(Part\(text = prompt\)\)\)\)', re.DOTALL)

new_logic = """// Construct history carefully to ensure strictly alternating roles for Gemini
                val currentChats = aiChats.value.toList()
                val filteredChats = if (currentChats.isNotEmpty() && currentChats.last().role == "user" && currentChats.last().message == message) {
                    currentChats.dropLast(1)
                } else {
                    currentChats
                }

                val recentChats = filteredChats.takeLast(10).toMutableList()
                while (recentChats.isNotEmpty() && recentChats.first().role != "user") {
                    recentChats.removeFirst()
                }

                val alternatingChats = mutableListOf<AiChat>()
                var expectedRole = "user"
                for (chat in recentChats) {
                    if (chat.role == expectedRole) {
                        alternatingChats.add(chat)
                        expectedRole = if (expectedRole == "user") "model" else "user"
                    }
                }

                if (alternatingChats.isNotEmpty() && alternatingChats.last().role == "user") {
                    alternatingChats.removeLast()
                }

                val history = alternatingChats.map { 
                     Content(role = it.role, parts = listOf(Part(text = it.message))) 
                 }.toMutableList()
                 
                history.add(Content(role = "user", parts = listOf(Part(text = prompt))))"""

content = re.sub(pattern, new_logic, content)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
print("Patched 2 successfully")
