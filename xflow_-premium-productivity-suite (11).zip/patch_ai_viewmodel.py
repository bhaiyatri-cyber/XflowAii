import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

old_code = """                // Construct history
                val history = aiChats.value.takeLast(10).map { 
                     Content(role = it.role, parts = listOf(Part(text = it.message))) 
                 }.toMutableList()
                history.add(Content(role = "user", parts = listOf(Part(text = prompt))))"""

new_code = """                // Construct history
                val history = aiChats.value.takeLast(10).map { 
                     Content(role = it.role, parts = listOf(Part(text = it.message))) 
                 }.toMutableList()
                 
                if (isMockTestRequest && history.isNotEmpty()) {
                    history[history.size - 1] = Content(role = "user", parts = listOf(Part(text = prompt)))
                }"""

content = content.replace(old_code, new_code)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
