with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

# Add parameter
content = content.replace(
    "onNavigateToThemeSettings: () -> Unit, onNavigateToOvertime: () -> Unit)",
    "onNavigateToThemeSettings: () -> Unit, onNavigateToOvertime: () -> Unit, onNavigateToAiTest: () -> Unit)"
)

# Add section at the top
new_section = """
            SettingsSection("XFlow AI (New)") {
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.Build, title = "XFlow Ai Test", onClick = onNavigateToAiTest)
            }
            SettingsSection("Permissions") {"""

content = content.replace('SettingsSection("Permissions") {', new_section)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)
