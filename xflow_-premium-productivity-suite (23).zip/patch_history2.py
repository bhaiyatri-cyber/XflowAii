with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

target = """@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(viewModel: XFlowViewModel, onBack: () -> Unit) {"""

# We'll replace the entire ProgressScreen and HistoryScreen definitions

new_content = """@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayHistoryScreen(viewModel: XFlowViewModel, onBack: () -> Unit) {
    val history by viewModel.history.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()
    
    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    val todayStart = cal.timeInMillis
    
    val todayHistory = history.filter { it.date > todayStart }.sortedByDescending { it.date }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Today's History", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            if (todayHistory.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No sessions completed today.", color = XFlowTextSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(todayHistory) { session ->
                        HistoryCard(session, cardStyle = cardStyle)
                    }
                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AllTimeHistoryScreen(viewModel: XFlowViewModel, onBack: () -> Unit) {
    val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle()
    val currentStreak by viewModel.currentStreak.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("All Time History", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Timeline",
                    value = String.format("%.1fh", lifetimeHours),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Streak",
                    value = "$currentStreak 🔥",
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Achievements", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                AchievementBadge("Novice", "1h", lifetimeHours >= 1f, "🥉")
                AchievementBadge("Scholar", "10h", lifetimeHours >= 10f, "🥈")
                AchievementBadge("Master", "50h", lifetimeHours >= 50f, "🥇")
                AchievementBadge("Legend", "100h", lifetimeHours >= 100f, "🏆")
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text("History Folders", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            
            if (history.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No history yet.", color = XFlowTextSecondary)
                }
            } else {
                val groupedHistory = history.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }.toSortedMap(compareByDescending { 
                    try { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).parse(it)?.time ?: 0L } catch(e: Exception) { 0L }
                })
                var expandedDates by remember { mutableStateOf(setOf(SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date()))) }
                
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    groupedHistory.forEach { (dateStr, sessions) ->
                        item {
                            val isExpanded = expandedDates.contains(dateStr)
                            val totalTime = sessions.sumOf { it.timeStudiedSeconds }
                            val hours = totalTime / 3600
                            val mins = (totalTime % 3600) / 60
                            val timeStr = if (hours > 0) "${hours}h ${mins}m" else "${mins}m"
                            
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    expandedDates = if (isExpanded) expandedDates - dateStr else expandedDates + dateStr
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = XFlowSurface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp).fillMaxWidth(), 
                                    horizontalArrangement = Arrangement.SpaceBetween, 
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(if (dateStr == SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())) "Today" else dateStr, color = XFlowTextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("${sessions.size} tasks • $timeStr", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text(
                                        text = if (isExpanded) "▲" else "▼",
                                        color = XFlowTextSecondary,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }
                            }
                        }
                        if (expandedDates.contains(dateStr)) {
                            items(sessions.sortedByDescending { it.date }) { session ->
                                Box(modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp)) {
                                    HistoryCard(session, cardStyle = cardStyle)
                                }
                            }
                            item { Spacer(modifier = Modifier.height(8.dp)) }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }
        }
    }
}
"""

# Now we need to remove the old ProgressScreen and HistoryScreen definitions
# Let's find the indices
start_idx = content.find('@OptIn(ExperimentalMaterial3Api::class)\n@Composable\nfun ProgressScreen(')
end_idx = content.find('@OptIn(ExperimentalMaterial3Api::class)\n@Composable\nfun HistoryCard(')

if start_idx != -1 and end_idx != -1:
    old_screens = content[start_idx:end_idx]
    
    # Also remove `fun HistoryScreen` at the bottom
    content = content.replace(old_screens, new_content)
    
    # Let's remove fun HistoryScreen if it exists
    history_screen_def = """@Composable
fun HistoryScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToTask: (Int) -> Unit) {
    ProgressScreen(viewModel, onBack)
}"""
    content = content.replace(history_screen_def, "")
    
    with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
        f.write(content)
    print("Replaced ProgressScreen with TodayHistoryScreen and AllTimeHistoryScreen")
else:
    print("Could not find ProgressScreen or HistoryCard definition")
