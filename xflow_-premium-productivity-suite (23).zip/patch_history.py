with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

target = """            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours),
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))"""

replacement = """            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours),
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Achievements", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                AchievementBadge("Novice", "1h", lifetimeHours >= 1f, "🥉")
                AchievementBadge("Scholar", "10h", lifetimeHours >= 10f, "🥈")
                AchievementBadge("Master", "50h", lifetimeHours >= 50f, "🥇")
                AchievementBadge("Legend", "100h", lifetimeHours >= 100f, "🏆")
            }
            Spacer(modifier = Modifier.height(24.dp))"""

content = content.replace(target, replacement)

new_component = """
@Composable
fun AchievementBadge(name: String, req: String, isUnlocked: Boolean, icon: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (isUnlocked) XFlowAccent.copy(alpha = 0.2f) else XFlowSurfaceVariant)
                .border(2.dp, if (isUnlocked) XFlowAccent else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(if (isUnlocked) icon else "🔒", fontSize = 24.sp, modifier = if (isUnlocked) Modifier else Modifier.graphicsLayer(alpha = 0.5f))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(name, color = if (isUnlocked) XFlowTextPrimary else XFlowTextSecondary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        Text(req, color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
    }
}
"""

if 'fun AchievementBadge' not in content:
    content = content + new_component
    
    with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
        f.write(content)
    print("Patched HistoryScreen")
else:
    print("Already patched HistoryScreen")
