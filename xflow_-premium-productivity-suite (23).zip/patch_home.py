with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

target = """    val lifetimeOvertimeHours by viewModel.lifetimeOvertimeHours.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()"""
replacement = """    val lifetimeOvertimeHours by viewModel.lifetimeOvertimeHours.collectAsStateWithLifecycle()
    val currentStreak by viewModel.currentStreak.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()"""
content = content.replace(target, replacement)

target2 = """            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    overtimeText = if (todayOvertimeHours > 0f) String.format("+%.1fh OT", todayOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours),
                    overtimeText = if (lifetimeOvertimeHours > 0f) String.format("+%.1fh OT", lifetimeOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
            }"""
replacement2 = """            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    overtimeText = if (todayOvertimeHours > 0f) String.format("+%.1fh OT", todayOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours),
                    overtimeText = if (lifetimeOvertimeHours > 0f) String.format("+%.1fh OT", lifetimeOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
                StatCard(
                    title = "Streak",
                    value = "$currentStreak 🔥",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = XFlowAccent.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("💡", fontSize = 24.sp, modifier = Modifier.padding(end = 12.dp))
                    Column {
                        Text("AI Study Tip", fontWeight = FontWeight.Bold, color = XFlowAccent, style = MaterialTheme.typography.labelMedium)
                        Text("Consistent study sessions improve retention. Keep up the momentum!", color = XFlowTextPrimary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }"""
content = content.replace(target2, replacement2)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
print("Patched HomeScreen")
