package com.example.ui

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.OpenableColumns
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.XFlowAccent
import com.example.ui.theme.XFlowBackground
import com.example.ui.theme.XFlowSurface
import com.example.ui.theme.XFlowTextPrimary
import com.example.ui.theme.XFlowTextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataDriveScreen(onBack: () -> Unit) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Google Browser", "My Data")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Data Drive", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = XFlowBackground,
                contentColor = XFlowAccent,
                indicator = { tabPositions ->
                    TabRowDefaults.Indicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = XFlowAccent
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                color = if (selectedTab == index) XFlowAccent else XFlowTextSecondary,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            if (selectedTab == 0) {
                GoogleBrowser()
            } else {
                MyDataList()
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GoogleBrowser() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isDownloading by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.setSupportZoom(true)
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false

                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            return false // load in webview
                        }
                    }
                    webChromeClient = WebChromeClient()

                    setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
                        scope.launch {
                            isDownloading = true
                            try {
                                val fileName = URLUtil.guessFileName(url, contentDisposition, mimetype)
                                val dataDir = File(ctx.filesDir, "DataDrive")
                                if (!dataDir.exists()) dataDir.mkdirs()
                                val file = File(dataDir, fileName)

                                withContext(Dispatchers.IO) {
                                    val connection = URL(url).openConnection() as HttpURLConnection
                                    connection.requestMethod = "GET"
                                    connection.setRequestProperty("User-Agent", userAgent)
                                    val cookie = CookieManager.getInstance().getCookie(url)
                                    if (cookie != null) {
                                        connection.setRequestProperty("Cookie", cookie)
                                    }
                                    connection.connect()
                                    if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                                        val inputStream = connection.inputStream
                                        val outputStream = FileOutputStream(file)
                                        val buffer = ByteArray(1024)
                                        var bytesRead: Int
                                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                                            outputStream.write(buffer, 0, bytesRead)
                                        }
                                        outputStream.close()
                                        inputStream.close()
                                    }
                                }
                                Toast.makeText(ctx, "Downloaded: $fileName", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                e.printStackTrace()
                                Toast.makeText(ctx, "Download failed", Toast.LENGTH_SHORT).show()
                            } finally {
                                isDownloading = false
                            }
                        }
                    }
                    loadUrl("https://www.google.com")
                }
            },
            update = {
                // No update needed
            }
        )

        if (isDownloading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = XFlowAccent)
            }
        }
    }
}

@Composable
fun MyDataList() {
    val context = LocalContext.current
    val dataDir = File(context.filesDir, "DataDrive")
    var files by remember { mutableStateOf(dataDir.listFiles()?.toList() ?: emptyList<File>()) }
    val scope = rememberCoroutineScope()
    
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        var name = "uploaded_file"
                        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (cursor.moveToFirst() && nameIndex >= 0) {
                                name = cursor.getString(nameIndex)
                            }
                        }
                        if (!dataDir.exists()) dataDir.mkdirs()
                        val destFile = File(dataDir, name)
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(destFile).use { output ->
                                val buffer = ByteArray(4 * 1024)
                                var read: Int
                                while (input.read(buffer).also { read = it } != -1) {
                                    output.write(buffer, 0, read)
                                }
                                output.flush()
                            }
                        }
                    }
                    files = dataDir.listFiles()?.toList() ?: emptyList<File>()
                    Toast.makeText(context, "File uploaded", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, "Upload failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (files.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Folder, contentDescription = null, tint = XFlowTextSecondary, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("No files downloaded yet.", color = XFlowTextSecondary)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(files) { file ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = XFlowSurface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Folder, contentDescription = null, tint = XFlowAccent)
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = file.name, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                                Text(text = "${file.length() / 1024} KB", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = {
                                if (file.delete()) {
                                    files = dataDir.listFiles()?.toList() ?: emptyList<File>()
                                    Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show()
                                }
                            }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.8f))
                            }
                        }
                    }
                }
            }
        }
        
        FloatingActionButton(
            onClick = { launcher.launch("*/*") },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = XFlowAccent,
            contentColor = Color.White
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Upload File")
        }
    }
}
