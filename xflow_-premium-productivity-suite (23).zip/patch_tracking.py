with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

# Replace online mode progress update
content = content.replace(
    'if (newElapsed > schedule.elapsedSeconds) db.dao().updateScheduleProgress(schedule.id, newElapsed, true)',
    'db.dao().updateScheduleProgress(schedule.id, newElapsed, true)'
)

# Replace && schedule.isRunning for both online and offline
content = content.replace(
    'if (schedule.elapsedSeconds >= targetTime && schedule.isRunning) {',
    'if (schedule.elapsedSeconds >= targetTime) {'
)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)

print("Patched.")
