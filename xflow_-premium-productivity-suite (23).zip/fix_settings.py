with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

target = 'onNavigateToChatGPT: () -> Unit) {'
replacement = 'onNavigateToChatGPT: () -> Unit, onNavigateToDailyReport: () -> Unit = {}) {'

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
        f.write(content)
    print("Fixed SettingsScreen signature")
else:
    print("Target not found")
