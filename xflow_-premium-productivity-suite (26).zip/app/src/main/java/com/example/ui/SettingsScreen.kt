package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AvTimer
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Update
import androidx.compose.ui.window.Dialog
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.XFlowViewModel

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToPdf: () -> Unit, onNavigateToPermissions: () -> Unit, onNavigateToAbout: () -> Unit, onNavigateToBackup: () -> Unit, onNavigateToThemeSettings: () -> Unit, onNavigateToOvertime: () -> Unit,  onNavigateToChatbot: () -> Unit, onNavigateToDataDrive: () -> Unit, onNavigateToYouTube: () -> Unit, onNavigateToChatGPT: () -> Unit, onNavigateToDailyReport: () -> Unit = {}) {
    var showStatsDialog by remember { mutableStateOf(false) }
    var showAppSettings by remember { mutableStateOf(false) }
    var showDataOptions by remember { mutableStateOf(false) }
    var showToolOptions by remember { mutableStateOf(false) }
    val todayHours by viewModel.todayHours.collectAsStateWithLifecycle()
    val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    var showPremiumDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(24.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.AvTimer,
                    contentDescription = "XFlow Logo",
                    tint = XFlowAccent,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "XFlow",
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Version ${com.example.BuildConfig.VERSION_NAME}",
                    color = XFlowTextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Spacer(modifier = Modifier.height(32.dp))
            
            
            SettingsSection("Data & Web") {
                SettingsItem(icon = Icons.Filled.Public, title = "Data & Web Hub", subtitle = "Access Data Drive, YouTube & ChatGPT", onClick = { showDataOptions = true })
            }
            SettingsSection("XFlow AI (New)") {
                
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.Info, title = "Chatbot", onClick = onNavigateToChatbot)
            }
            SettingsSection("App Settings") {
                SettingsItem(icon = Icons.Default.Build, title = "App Settings", subtitle = "Permissions, Theme & Appearance", onClick = { showAppSettings = true })
            }
                        SettingsSection("Tools / Utilities") {
                SettingsItem(icon = Icons.Default.Build, title = "Tools Hub", subtitle = "Access all utilities & tools", onClick = { showToolOptions = true })
            }
            SettingsSection("About / Branding") {
                SettingsItem(icon = Icons.Default.Info, title = "About XFlow", onClick = onNavigateToAbout)
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
    

    if (showAppSettings) {
        ModalBottomSheet(
            onDismissRequest = { showAppSettings = false },
            containerColor = XFlowBackground,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("App Settings", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                Spacer(modifier = Modifier.height(8.dp))
                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Security, title = "Manage Permissions", onClick = { showAppSettings = false; onNavigateToPermissions() })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Build, title = "Theme & Appearance", onClick = { showAppSettings = false; onNavigateToThemeSettings() })
                }
                SettingsSection("") {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val prefs = context.getSharedPreferences("xflow_prefs", android.content.Context.MODE_PRIVATE)
                    val updateTime = prefs.getLong("update_time_${com.example.BuildConfig.VERSION_CODE}", 0L)
                    
                    // We need a live-updating string, so let's use a state that refreshes
                    var currentTime by remember { mutableStateOf(System.currentTimeMillis()) }
                    LaunchedEffect(Unit) {
                        while (true) {
                            kotlinx.coroutines.delay(60000)
                            currentTime = System.currentTimeMillis()
                        }
                    }
                    
                    val timeStr = if (updateTime > 0L) {
                        val diff = currentTime - updateTime
                        when {
                            diff < 60000 -> "updated just now"
                            diff < 3600000 -> "updated ${diff / 60000} min ago"
                            diff < 86400000 -> "updated ${diff / 3600000} hour(s) ago"
                            diff < 31536000000L -> "updated ${diff / 86400000} day(s) ago"
                            else -> "updated ${diff / 31536000000L} year(s) ago"
                        }
                    } else "updated recently"
                    
                    var showUpdateScreen by remember { mutableStateOf(false) }
                    
                    SettingsItem(icon = Icons.Default.Update, title = "App Update", subtitle = timeStr, onClick = { showUpdateScreen = true })
                    
                    if (showUpdateScreen) {
                        Dialog(
                            onDismissRequest = { showUpdateScreen = false },
                            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
                        ) {
                            WhatsNewScreen(onDismiss = { showUpdateScreen = false })
                        }
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
    if (showDataOptions) {
        ModalBottomSheet(
            onDismissRequest = { showDataOptions = false },
            containerColor = XFlowBackground,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Data & Web Hub", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                Spacer(modifier = Modifier.height(8.dp))
                SettingsSection("") {
                    SettingsItem(icon = Icons.Filled.Public, title = "Data Drive", subtitle = "Secure In-App Browser & Storage", onClick = { showDataOptions = false; onNavigateToDataDrive() })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Filled.PlayCircle, title = "YouTube", subtitle = "Watch videos in full screen", onClick = { showDataOptions = false; onNavigateToYouTube() })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Filled.Chat, title = "ChatGPT", subtitle = "AI Chat Assistant", onClick = { showDataOptions = false; onNavigateToChatGPT() })
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
    
    if (showToolOptions) {
        ModalBottomSheet(
            onDismissRequest = { showToolOptions = false },
            containerColor = XFlowBackground,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Tools Hub", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                Spacer(modifier = Modifier.height(8.dp))
                SettingsSection("") {
                    SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "24h Daily Report", subtitle = "Study vs Wasted Time", onClick = { showToolOptions = false; onNavigateToDailyReport() })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { showToolOptions = false; if (isPremium) onNavigateToPdf() else showPremiumDialog = true })
                }
                SettingsSection("") {
                    SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "🔥 Overtime (PRO)", onClick = { showToolOptions = false; if (isPremium) onNavigateToOvertime() else showPremiumDialog = true })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Build, title = "Backup & Restore", onClick = { showToolOptions = false; onNavigateToBackup() })
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (showPremiumDialog) {
        AlertDialog(
            onDismissRequest = { showPremiumDialog = false },
            title = { Text("Premium Feature", color = XFlowTextPrimary) },
            text = { Text("This feature is only available for Premium users. Please upgrade from the Home screen.", color = XFlowTextSecondary) },
            confirmButton = {
                TextButton(onClick = { showPremiumDialog = false }) {
                    Text("OK", color = XFlowAccent)
                }
            },
            containerColor = XFlowSurface
        )
    }
    if (showStatsDialog) {
        AlertDialog(
            onDismissRequest = { showStatsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AvTimer, contentDescription = "Logo", tint = XFlowAccent, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("App Stats", color = XFlowTextPrimary)
                }
            },
            text = {
                Column {
                    Text("Today's Focus: ${String.format("%.1f", todayHours)}h", color = XFlowTextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Lifetime Focus: ${String.format("%.1f", lifetimeHours)}h", color = XFlowTextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Total Sessions: ${history.size}", color = XFlowTextPrimary)
                }
            },
            confirmButton = {
                TextButton(onClick = { showStatsDialog = false }) {
                    Text("Cool!", color = XFlowAccent)
                }
            },
            containerColor = XFlowSurface,
            titleContentColor = XFlowTextPrimary,
            textContentColor = XFlowTextSecondary
        )
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        if (title.isNotEmpty()) {
            Text(
                text = title,
                color = XFlowAccent,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp, start = 8.dp)
            )
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(XFlowSurface)
        ) {
            content()
        }
    }
}

@Composable
fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = XFlowTextSecondary, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = XFlowTextPrimary, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, color = XFlowTextSecondary, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
