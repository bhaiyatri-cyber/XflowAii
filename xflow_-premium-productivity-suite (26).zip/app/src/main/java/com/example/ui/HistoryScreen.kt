package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material3.*
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.HistorySession
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayHistoryScreen(viewModel: XFlowViewModel, onBack: () -> Unit) {
    val history by viewModel.history.collectAsStateWithLifecycle()
    val overtimeEntries by viewModel.overtimeEntries.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()
    
    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    val todayStart = cal.timeInMillis
    
    val todayHistory = history.filter { it.date > todayStart }.sortedByDescending { it.date }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Today's History", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            val todayOvertime = overtimeEntries.filter { it.date > todayStart }
            if (todayHistory.isEmpty() && todayOvertime.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No sessions completed today.", color = XFlowTextSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (todayOvertime.isNotEmpty()) {
                        item {
                            OvertimeSummaryCard(
                                dateTitle = "Today",
                                totalSeconds = todayOvertime.sumOf { it.overtimeSeconds },
                                entries = todayOvertime,
                                cardStyle = cardStyle
                            )
                        }
                    }
                    items(todayHistory) { session ->
                        HistoryCard(session, cardStyle = cardStyle)
                    }
                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AllTimeHistoryScreen(viewModel: XFlowViewModel, onBack: () -> Unit) {
    val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle()
    val currentStreak by viewModel.currentStreak.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val overtimeEntries by viewModel.overtimeEntries.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("All Time History", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Timeline",
                    value = String.format("%.1fh", lifetimeHours),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Streak",
                    value = "$currentStreak 🔥",
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Achievements", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                AchievementBadge("Novice", "1h", lifetimeHours >= 1f, "🥉")
                AchievementBadge("Scholar", "10h", lifetimeHours >= 10f, "🥈")
                AchievementBadge("Master", "50h", lifetimeHours >= 50f, "🥇")
                AchievementBadge("Legend", "100h", lifetimeHours >= 100f, "🏆")
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text("History Folders", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            
            if (history.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No history yet.", color = XFlowTextSecondary)
                }
            } else {
                val groupedHistory = history.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }.toSortedMap(compareByDescending { 
                    try { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).parse(it)?.time ?: 0L } catch(e: Exception) { 0L }
                })
                val groupedOvertime = overtimeEntries.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }
                var expandedDates by remember { mutableStateOf(setOf(SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date()))) }
                
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    groupedHistory.forEach { (dateStr, sessions) ->
                        item {
                            val isExpanded = expandedDates.contains(dateStr)
                            val totalTime = sessions.sumOf { it.timeStudiedSeconds }
                            val hours = totalTime / 3600
                            val mins = (totalTime % 3600) / 60
                            val timeStr = if (hours > 0) "${hours}h ${mins}m" else "${mins}m"
                            
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    expandedDates = if (isExpanded) expandedDates - dateStr else expandedDates + dateStr
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = XFlowSurface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp).fillMaxWidth(), 
                                    horizontalArrangement = Arrangement.SpaceBetween, 
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(if (dateStr == SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())) "Today" else dateStr, color = XFlowTextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("${sessions.size} tasks • $timeStr", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Text(
                                        text = if (isExpanded) "▲" else "▼",
                                        color = XFlowTextSecondary,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }
                            }
                        }
                        if (expandedDates.contains(dateStr)) {
                            val overtimeForDate = groupedOvertime[dateStr]
                            if (!overtimeForDate.isNullOrEmpty()) {
                                item {
                                    Box(modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp)) {
                                        OvertimeSummaryCard(
                                            dateTitle = if (dateStr == SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())) "Today" else dateStr,
                                            totalSeconds = overtimeForDate.sumOf { it.overtimeSeconds },
                                            entries = overtimeForDate,
                                            cardStyle = cardStyle
                                        )
                                    }
                                }
                            }
                            items(sessions.sortedByDescending { it.date }) { session ->
                                Box(modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp)) {
                                    HistoryCard(session, cardStyle = cardStyle)
                                }
                            }
                            item { Spacer(modifier = Modifier.height(8.dp)) }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryCard(session: HistorySession, cardStyle: String = "Solid") {
    var showSheet by remember { mutableStateOf(false) }

    val progress = (session.completionPercentage.toFloat() / 100f).coerceIn(0f, 1f)

    val isImageStyle = cardStyle == "Image"
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showSheet = true },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isImageStyle) androidx.compose.ui.graphics.Color.Transparent else XFlowSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, XFlowSurfaceVariant)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.3f),
                                    androidx.compose.ui.graphics.Color(0xFF8B5CF6).copy(alpha = 0.3f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(session.subject, color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date(session.date)),
                    color = XFlowTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = if (session.status == "Completed") XFlowSupport else XFlowAccent,
                trackColor = XFlowSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Badge(text = session.status, isAccent = session.status == "Completed")
                Badge(text = session.mode)
                Badge(text = "${session.timeStudiedSeconds / 60} min")
            }
        }
    }

    if (showSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            containerColor = XFlowSurface,
            contentColor = XFlowTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = session.subject,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = XFlowTextPrimary
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault()).format(Date(session.date)),
                    style = MaterialTheme.typography.bodyMedium,
                    color = XFlowTextSecondary
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = session.status,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (session.status == "Completed") XFlowSupport else XFlowTextPrimary
                    )
                    Text(
                        text = "${session.completionPercentage}%",
                        color = XFlowAccent,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (session.status == "Completed") XFlowSupport else XFlowAccent,
                    trackColor = XFlowSurfaceVariant
                )

                Spacer(modifier = Modifier.height(20.dp))

                HorizontalDivider(color = XFlowSurfaceVariant)

                Spacer(modifier = Modifier.height(16.dp))

                val studiedStr = String.format("%02d:%02d:%02d", session.timeStudiedSeconds / 3600, (session.timeStudiedSeconds % 3600) / 60, session.timeStudiedSeconds % 60)
                DetailRow("Studied Time", studiedStr)
                DetailRow("Tracking Mode", session.mode)
                DetailRow("Completion", "${session.completionPercentage}%")
                
                AnimatedVisibility(
                    visible = session.status == "Completed",
                    enter = fadeIn(tween(300)) + scaleIn(tween(350))
                ) {
                    Column(modifier = Modifier.padding(top = 16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("✓ Session Completed", color = XFlowSupport, fontWeight = FontWeight.Bold)
                        Text(getResultStatus(session.completionPercentage), color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium)
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
    }


@Composable
fun AchievementBadge(name: String, req: String, isUnlocked: Boolean, icon: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(if (isUnlocked) XFlowAccent.copy(alpha = 0.2f) else XFlowSurfaceVariant)
                .border(2.dp, if (isUnlocked) XFlowAccent else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(if (isUnlocked) icon else "🔒", fontSize = 24.sp, modifier = if (isUnlocked) Modifier else Modifier.graphicsLayer(alpha = 0.5f))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(name, color = if (isUnlocked) XFlowTextPrimary else XFlowTextSecondary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        Text(req, color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
    }
}

@Composable
fun HistoryScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToTask: (Int) -> Unit) {
    AllTimeHistoryScreen(viewModel, onBack)
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OvertimeSummaryCard(dateTitle: String, totalSeconds: Int, entries: List<com.example.data.OvertimeEntry>, cardStyle: String = "Solid") {
    var showSheet by remember { mutableStateOf(false) }
    val isImageStyle = cardStyle == "Image"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showSheet = true },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isImageStyle) androidx.compose.ui.graphics.Color.Transparent else XFlowSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, XFlowAccent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.3f),
                                    androidx.compose.ui.graphics.Color(0xFF8B5CF6).copy(alpha = 0.3f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("🔥 Overtime $dateTitle", color = XFlowAccent, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    val formatTime = String.format("%02d:%02d:%02d", totalSeconds / 3600, (totalSeconds % 3600) / 60, totalSeconds % 60)
                    Text(formatTime, color = XFlowTextPrimary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            containerColor = XFlowSurface,
            contentColor = XFlowTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "Overtime Details",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = XFlowTextPrimary
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                val subjectMap = entries.groupBy { it.subject }.mapValues { (_, v) -> v.sumOf { it.overtimeSeconds } }
                
                subjectMap.forEach { (subject, seconds) ->
                    val studiedStr = String.format("%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60)
                    DetailRow(subject, studiedStr)
                }
                
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
