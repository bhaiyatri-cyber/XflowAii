import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Locate the showWhatsNew block
pattern = re.compile(r'    if \(showWhatsNew\) \{.*?\n    \}', re.DOTALL)
# Wait, it might be easier to use a Python script to do the replacement manually

