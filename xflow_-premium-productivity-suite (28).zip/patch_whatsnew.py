import re

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

old_changes = """                    val changes = listOf(
                        "Track your daily Overtime directly in the History tab.",
                        "New 'Overtime Today' card summarizes all extra effort.",
                        "Tap the Overtime card to see a detailed subject breakdown.",
                        "Full-screen beautiful update announcements.",
                        "Live update timer in the App Settings menu.",
                        "Removed clutter from dashboard stats.",
                        "Under-the-hood bug fixes and performance improvements."
                    )"""

new_changes = """                    val changes = listOf(
                        "Lock Screen Notifications: See tracking updates without unlocking your phone.",
                        "History Layout Fixes: Fixed the layout shrinking issue in the All Time history view.",
                        "Improved Overtime Tracking: Track daily and all-time overtime.",
                        "Under-the-hood bug fixes and UI performance improvements."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)

