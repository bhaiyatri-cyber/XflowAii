package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.PendingIntent
import android.net.Uri
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.data.Schedule
import com.example.data.XFlowDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar

class TrackingService : Service() {
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    
    private lateinit var db: XFlowDatabase
    
    private val CHANNEL_ID = "TrackingChannel"
    private val ALERT_CHANNEL_ID = "xflow_alerts_vibrate"
    private val NOTIFICATION_ID = 1
    
    private var isTrackingLoopRunning = false
    private var wakeLock: android.os.PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        db = XFlowDatabase.getDatabase(this)
        createNotificationChannel()
        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        wakeLock = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "XFlow::TrackingWakeLock")
        wakeLock?.acquire()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val scheduleId = intent?.getIntExtra("schedule_id", -1) ?: -1
        
        val notification = createNotification("Initializing...", "Starting tracker")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        if (!isTrackingLoopRunning) {
            startTrackingLoop()
        }
        return START_STICKY
    }

    private fun startTrackingLoop() {
        isTrackingLoopRunning = true
        serviceScope.launch {
            var lastTick = System.currentTimeMillis()
            val accumulatedMs = mutableMapOf<Int, Long>()
            while (true) {
                val now = System.currentTimeMillis()
                val deltaMs = now - lastTick
                lastTick = now
                val activeSchedules = db.dao().getActiveSchedulesSync()
                if (activeSchedules.isEmpty()) {
                    stopForeground(Service.STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    isTrackingLoopRunning = false
                    break
                }
                
                val currentApp = getForegroundApp()
                var trackingAny = false
                var bestPriority = -1
                var bestUpcomingMins = Int.MAX_VALUE
                var titleText = "XFlow Active"
                var contentText = "Monitoring..."
                
                val cal = Calendar.getInstance()
                val currentHour = cal.get(Calendar.HOUR_OF_DAY)
                val currentMin = cal.get(Calendar.MINUTE)
                val currentTotalMins = currentHour * 60 + currentMin

                                for (schedule in activeSchedules) {
                    val isDuration = schedule.isDurationMode
                    var targetTime = 0
                    var shouldTrack = false
                    var autoComplete = false
                    var waitingReason = ""
                    
                    if (isDuration) {
                        targetTime = schedule.durationMinutes * 60
                        shouldTrack = true
                    } else {
                        try {
                            val parts = schedule.startTimeStr.split(":")
                            val startMins = parts[0].toInt() * 60 + parts[1].toInt()
                            val parts2 = schedule.endTimeStr.split(":")
                            val endMins = parts2[0].toInt() * 60 + parts2[1].toInt()
                            
                            targetTime = if (endMins >= startMins) (endMins - startMins) * 60 else (24 * 60 - startMins + endMins) * 60
                            
                            if (currentTotalMins >= startMins && currentTotalMins < endMins) {
                                shouldTrack = true
                            } else if (currentTotalMins >= endMins && startMins < endMins) {
                                autoComplete = true
                            } else if (currentTotalMins < startMins && startMins < endMins) {
                                waitingReason = "Starts at ${schedule.startTimeStr}"
                            }
                        } catch (e: Exception) {
                            targetTime = 60 * 60 // fallback to 1h
                            shouldTrack = true
                        }
                    }

                    if (autoComplete) {
                        var wasActiveAtEnd = false
                        if (schedule.isOnlineMode && schedule.selectedAppPackage != null) {
                            if (schedule.selectedAppPackage == currentApp) {
                                wasActiveAtEnd = true
                            }
                        } else if (!schedule.isOnlineMode) {
                            val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                            val isScreenOn = powerManager.isInteractive
                            if (!isScreenOn) {
                                wasActiveAtEnd = true
                            }
                        }
                        
                        if (wasActiveAtEnd) {
                            shouldTrack = true
                            autoComplete = false
                        } else {
                            db.dao().insertHistory(
                                com.example.data.HistorySession(
                                    scheduleId = schedule.id,
                                    subject = schedule.subject,
                                    mode = "Exact Time",
                                    date = System.currentTimeMillis(),
                                    timeStudiedSeconds = schedule.elapsedSeconds,
                                    completionPercentage = if (targetTime > 0) ((schedule.elapsedSeconds.toFloat() / targetTime.toFloat()) * 100).toInt().coerceIn(0, 100) else 100,
                                    status = "Completed"
                                )
                            )
                            
                            if (schedule.overtimeSeconds > 0) {
                                db.dao().insertOvertimeEntry(
                                    com.example.data.OvertimeEntry(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        overtimeSeconds = schedule.overtimeSeconds,
                                        date = System.currentTimeMillis()
                                    )
                                )
                            }
                            
                            db.dao().deactivateSchedule(schedule.id)
                            sendAlertNotification(
                                "Session Saved",
                                if (schedule.overtimeSeconds > 0) "Completed with ${schedule.overtimeSeconds / 60}m overtime!" else "You've completed your focus session for '${schedule.subject}'.",
                                schedule.id + 2000
                            )
                            continue
                        }
                    }
                    
                    if (!shouldTrack) {
                        if (schedule.isRunning) db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                        val startMins = try {
                            val parts = schedule.startTimeStr.split(":")
                            parts[0].toInt() * 60 + parts[1].toInt()
                        } catch (e: Exception) { Int.MAX_VALUE }
                        
                        if (bestPriority < 1 && startMins < bestUpcomingMins) {
                            bestPriority = 0
                            bestUpcomingMins = startMins
                            titleText = "Scheduled: ${schedule.subject}"
                            contentText = waitingReason
                        }
                        continue
                    }

                    if (schedule.isOnlineMode && schedule.selectedAppPackage != null) {
                        if (schedule.selectedAppPackage == currentApp) {
                            trackingAny = true
                            val currentAcc = accumulatedMs.getOrDefault(schedule.id, 0L) + deltaMs
                            val addSeconds = (currentAcc / 1000).toInt()
                            accumulatedMs[schedule.id] = currentAcc % 1000
                            
                            val newElapsed = if (schedule.elapsedSeconds < targetTime) Math.min(schedule.elapsedSeconds + addSeconds, targetTime) else schedule.elapsedSeconds
                            val newOvertime = if (schedule.elapsedSeconds + addSeconds > targetTime) schedule.overtimeSeconds + (schedule.elapsedSeconds + addSeconds - Math.max(schedule.elapsedSeconds, targetTime)) else schedule.overtimeSeconds
                            
                            if (addSeconds > 0) {
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                if (newOvertime > schedule.overtimeSeconds) db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                
                                if (schedule.elapsedSeconds < targetTime && newElapsed >= targetTime) {
                                    sendAlertNotification(
                                        "Goal Reached",
                                        "You have completed your time for '${schedule.subject}'. Overtime tracking started!",
                                        schedule.id + 3000
                                    )
                                }
                            }
                            
                            if (newElapsed < targetTime) {
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Tracking: ${schedule.subject}"
                                    contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                                }
                            } else {
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Overtime: ${schedule.subject}"
                                    contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                                }
                            }
                        } else {
                            if (schedule.elapsedSeconds >= targetTime) {
                                db.dao().insertHistory(
                                    com.example.data.HistorySession(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        mode = if (isDuration) "Duration" else "Exact Time",
                                        date = System.currentTimeMillis(),
                                        timeStudiedSeconds = schedule.elapsedSeconds,
                                        completionPercentage = 100,
                                        status = "Completed"
                                    )
                                )
                                if (schedule.overtimeSeconds > 0) {
                                    db.dao().insertOvertimeEntry(
                                        com.example.data.OvertimeEntry(
                                            scheduleId = schedule.id,
                                            subject = schedule.subject,
                                            overtimeSeconds = schedule.overtimeSeconds,
                                            date = System.currentTimeMillis()
                                        )
                                    )
                                }
                                db.dao().deactivateSchedule(schedule.id)
                                
                                sendAlertNotification(
                                    "Session Saved",
                                    if (schedule.overtimeSeconds > 0) "Completed with ${schedule.overtimeSeconds / 60}m overtime!" else "You've completed your focus session for '${schedule.subject}'.",
                                    schedule.id + 2000
                                )
                            } else {
                                if (schedule.isRunning) db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                                if (bestPriority < 1) {
                                    bestPriority = 1
                                    titleText = "Ready: ${schedule.subject}"
                                    contentText = "Open ${schedule.selectedAppPackage} to start"
                                }
                            }
                        }
                    } else if (!schedule.isOnlineMode) {
                        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                        val isScreenOn = powerManager.isInteractive
                        
                        if (!isScreenOn) {
                            trackingAny = true
                            val currentAcc = accumulatedMs.getOrDefault(schedule.id, 0L) + deltaMs
                            val addSeconds = (currentAcc / 1000).toInt()
                            accumulatedMs[schedule.id] = currentAcc % 1000
                            
                            val newElapsed = if (schedule.elapsedSeconds < targetTime) Math.min(schedule.elapsedSeconds + addSeconds, targetTime) else schedule.elapsedSeconds
                            val newOvertime = if (schedule.elapsedSeconds + addSeconds > targetTime) schedule.overtimeSeconds + (schedule.elapsedSeconds + addSeconds - Math.max(schedule.elapsedSeconds, targetTime)) else schedule.overtimeSeconds
                            
                            if (addSeconds > 0) {
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                if (newOvertime > schedule.overtimeSeconds) db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                
                                if (schedule.elapsedSeconds < targetTime && newElapsed >= targetTime) {
                                    sendAlertNotification(
                                        "Goal Reached",
                                        "You have completed your time for '${schedule.subject}'. Overtime tracking started!",
                                        schedule.id + 3000
                                    )
                                }
                            }
                            
                            if (newElapsed < targetTime) {
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Offline Tracking: ${schedule.subject}"
                                    contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                                }
                            } else {
                                if (bestPriority < 2) {
                                    bestPriority = 2
                                    titleText = "Offline Overtime: ${schedule.subject}"
                                    contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                                }
                            }
                        } else {
                            if (schedule.elapsedSeconds >= targetTime) {
                                db.dao().insertHistory(
                                    com.example.data.HistorySession(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        mode = if (isDuration) "Duration" else "Exact Time",
                                        date = System.currentTimeMillis(),
                                        timeStudiedSeconds = schedule.elapsedSeconds,
                                        completionPercentage = 100,
                                        status = "Completed"
                                    )
                                )
                                if (schedule.overtimeSeconds > 0) {
                                    db.dao().insertOvertimeEntry(
                                        com.example.data.OvertimeEntry(
                                            scheduleId = schedule.id,
                                            subject = schedule.subject,
                                            overtimeSeconds = schedule.overtimeSeconds,
                                            date = System.currentTimeMillis()
                                        )
                                    )
                                }
                                db.dao().deactivateSchedule(schedule.id)
                                sendAlertNotification(
                                    "Session Saved",
                                    if (schedule.overtimeSeconds > 0) "Completed with ${schedule.overtimeSeconds / 60}m overtime!" else "You've completed your focus session for '${schedule.subject}'.",
                                    schedule.id + 2000
                                )
                            } else {
                                if (schedule.isRunning) db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                                if (bestPriority < 1) {
                                    bestPriority = 1
                                    titleText = "Ready: ${schedule.subject}"
                                    contentText = "Turn off screen to start"
                                }
                            }
                        }
                    }
                }
                
                updateNotification(titleText, contentText)
                
                delay(1000)
            }
        }
    }

    private fun getForegroundApp(): String? {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val startTime = endTime - 1000 * 60 * 60 * 24L // last 24 hours
        
        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        var event = UsageEvents.Event()
        var foregroundPackage: String? = null
        
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                foregroundPackage = event.packageName
            } else if (event.eventType == UsageEvents.Event.ACTIVITY_PAUSED) {
                if (foregroundPackage == event.packageName) {
                    foregroundPackage = null
                }
            }
        }
        return foregroundPackage
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Tracking Service Channel",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
            
            val alertChannel = NotificationChannel(
                ALERT_CHANNEL_ID,
                "Alerts",
                NotificationManager.IMPORTANCE_HIGH
            )
            alertChannel.enableVibration(true)
            alertChannel.vibrationPattern = longArrayOf(0, 2000)
            manager.createNotificationChannel(alertChannel)
        }
    }

    private fun sendAlertNotification(title: String, text: String, id: Int) {
        try {
            val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("xflow://home"))
            val pendingIntent = PendingIntent.getActivity(this, id, deepLinkIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            
            val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setAutoCancel(true)
                .setVibrate(longArrayOf(0, 2000))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()
                
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Permission not granted, ignore
        }
    }

    private fun createNotification(title: String, text: String): Notification {
        val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("xflow://home"))
        val pendingIntent = PendingIntent.getActivity(this, 0, deepLinkIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()
    }
    
    private fun updateNotification(title: String, text: String) {
        val notification = createNotification(title, text)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
    }
}
