import os

files = [
    'app/src/main/java/com/example/service/TrackingService.kt',
    'app/src/main/java/com/example/service/SchedulingWorker.kt',
    'app/src/main/java/com/example/service/DailySummaryWorker.kt',
    'app/src/main/java/com/example/utils/UpdateManager.kt'
]

for file_path in files:
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            content = f.read()
        
        if 'import com.example.R' not in content:
            if 'import android.app.Notification' in content or 'import androidx.core.app.NotificationCompat' in content:
                content = content.replace('import android.content.Context', 'import android.content.Context\nimport com.example.R\nimport android.graphics.BitmapFactory')
                if 'import android.graphics.BitmapFactory' not in content:
                    content = content.replace('import android.app.NotificationManager', 'import android.app.NotificationManager\nimport com.example.R\nimport android.graphics.BitmapFactory')

        if '.setSmallIcon(' in content:
            content = content.replace('.setSmallIcon(android.R.drawable.ic_menu_recent_history)', '.setSmallIcon(android.R.drawable.ic_menu_recent_history)\n                .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.app_logo))')
            content = content.replace('.setSmallIcon(android.R.drawable.star_on)', '.setSmallIcon(android.R.drawable.star_on)\n                .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.app_logo))')
            content = content.replace('.setSmallIcon(android.R.drawable.stat_sys_download_done)', '.setSmallIcon(android.R.drawable.stat_sys_download_done)\n                .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.app_logo))')

        with open(file_path, 'w') as f:
            f.write(content)
