with open('app/src/main/java/com/example/service/DailySummaryWorker.kt', 'r') as f:
    content = f.read()

# Update channel
content = content.replace(
    'val channel = NotificationChannel(\n                    "xflow_daily",',
    'val channel = NotificationChannel(\n                    "xflow_daily_vibrate",'
)
content = content.replace(
    'manager?.createNotificationChannel(channel)',
    'channel.enableVibration(true)\n                channel.vibrationPattern = longArrayOf(0, 2000)\n                manager?.createNotificationChannel(channel)'
)

# Update builder
content = content.replace(
    'val notification = NotificationCompat.Builder(context, "xflow_daily")',
    'val notification = NotificationCompat.Builder(context, "xflow_daily_vibrate")'
)

content = content.replace(
    '.setPriority(NotificationCompat.PRIORITY_DEFAULT)',
    '.setPriority(NotificationCompat.PRIORITY_DEFAULT)\n                .setVibrate(longArrayOf(0, 2000))'
)

with open('app/src/main/java/com/example/service/DailySummaryWorker.kt', 'w') as f:
    f.write(content)
