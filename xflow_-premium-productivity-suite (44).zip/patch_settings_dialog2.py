import re

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

old_end = """            titleContentColor = XFlowTextPrimary,
            textContentColor = XFlowTextSecondary
        )
    }
}"""

new_end = """            titleContentColor = XFlowTextPrimary,
            textContentColor = XFlowTextSecondary
        )
    }
    if (showUpdateScreen) {
        WhatsNewScreen(onDismiss = { showUpdateScreen = false })
    }
}"""

content = content.replace(old_end, new_end)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)

