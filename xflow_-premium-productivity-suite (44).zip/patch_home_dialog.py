import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Add imports for Context, LocalContext if needed
if "import androidx.compose.ui.platform.LocalContext" not in content:
    content = content.replace("import androidx.compose.runtime.*", "import androidx.compose.runtime.*\nimport androidx.compose.ui.platform.LocalContext\nimport android.content.Context")

# Insert What's New logic at the beginning of HomeScreen
whats_new_logic = """
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("xflow_prefs", Context.MODE_PRIVATE)
    val lastOpenedVersion = prefs.getInt("last_opened_version", 0)
    val currentVersion = com.example.BuildConfig.VERSION_CODE
    var showWhatsNew by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (lastOpenedVersion > 0 && lastOpenedVersion < currentVersion) {
            showWhatsNew = true
        } else if (lastOpenedVersion == 0) {
            // Fresh install, don't show what's new, just set it
            prefs.edit().putInt("last_opened_version", currentVersion).apply()
        }
    }

    if (showWhatsNew) {
        Dialog(onDismissRequest = { 
            showWhatsNew = false
            prefs.edit().putInt("last_opened_version", currentVersion).apply()
        }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = com.example.ui.theme.XFlowSurface),
                modifier = Modifier.padding(16.dp).fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = com.example.ui.theme.XFlowAccent,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "App Updated to ${com.example.BuildConfig.VERSION_NAME}!",
                        style = MaterialTheme.typography.headlineSmall,
                        color = com.example.ui.theme.XFlowTextPrimary,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "What's New in this version:\n\n• Cleaned up App Settings menu\n• Improved Theme & Appearance section\n• Enhanced layout and spacing\n• Removed clutter from dashboard stats\n• Under-the-hood bug fixes and performance improvements",
                        style = MaterialTheme.typography.bodyMedium,
                        color = com.example.ui.theme.XFlowTextSecondary
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { 
                            showWhatsNew = false
                            prefs.edit().putInt("last_opened_version", currentVersion).apply()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.XFlowAccent),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Awesome!", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
"""

home_screen_start = """) {
    val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()"""

content = content.replace(home_screen_start, ") {\n" + whats_new_logic + "\n    val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()")

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)

