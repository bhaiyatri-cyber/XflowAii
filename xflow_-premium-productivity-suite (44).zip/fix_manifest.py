with open('app/src/main/AndroidManifest.xml', 'r') as f:
    content = f.read()

work_manager_provider = """
        <provider
            android:name="androidx.startup.InitializationProvider"
            android:authorities="${applicationId}.androidx-startup"
            android:exported="false"
            tools:node="merge">
            <meta-data
                android:name="androidx.work.WorkManagerInitializer"
                android:value="androidx.startup"
                tools:node="remove" />
        </provider>
"""

content = content.replace('    <application', f'{work_manager_provider}    <application')
content = content.replace('xmlns:tools="http://schemas.android.com/tools">', 'xmlns:tools="http://schemas.android.com/tools">\n')

# Actually, the provider must be inside <application>. Let's redo.
with open('app/src/main/AndroidManifest.xml', 'r') as f:
    original = f.read()
    
original = original.replace(work_manager_provider, "")

provider_inside_app = """
        <provider
            android:name="androidx.startup.InitializationProvider"
            android:authorities="${applicationId}.androidx-startup"
            android:exported="false"
            tools:node="merge">
            <meta-data
                android:name="androidx.work.WorkManagerInitializer"
                android:value="androidx.startup"
                tools:node="remove" />
        </provider>
"""
if "androidx.startup.InitializationProvider" not in original:
    original = original.replace('</application>', f'{provider_inside_app}\n    </application>')

with open('app/src/main/AndroidManifest.xml', 'w') as f:
    f.write(original)

print("Manifest fixed")
