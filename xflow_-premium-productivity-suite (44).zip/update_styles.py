with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'val cardStyles = listOf("Solid", "Image")',
    'val cardStyles = listOf("Solid", "Image", "Gradient", "Outlined", "Soft")'
)

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'w') as f:
    f.write(content)
