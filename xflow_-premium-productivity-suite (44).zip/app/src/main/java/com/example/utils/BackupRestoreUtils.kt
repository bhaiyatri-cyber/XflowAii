package com.example.utils

import android.content.Context
import android.net.Uri
import com.example.data.HistorySession
import com.example.data.Schedule
import com.example.data.StudyPlan
import com.example.data.StudyPlanItem
import com.example.data.XFlowDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

object BackupRestoreUtils {

    suspend fun createBackup(context: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val db = XFlowDatabase.getDatabase(context)
            val dao = db.dao()

            val schedules = dao.getAllSchedulesSync()
            val history = dao.getAllHistorySync()
            val plans = dao.getAllStudyPlans()
            // We can also get items but let's just backup everything
            
            val rootObj = JSONObject()
            
            val schedulesArray = JSONArray()
            schedules.forEach { s ->
                val obj = JSONObject()
                obj.put("id", s.id)
                obj.put("subject", s.subject)
                obj.put("description", s.description)
                obj.put("isDurationMode", s.isDurationMode)
                obj.put("durationMinutes", s.durationMinutes)
                obj.put("startTimeStr", s.startTimeStr)
                obj.put("endTimeStr", s.endTimeStr)
                obj.put("isOnlineMode", s.isOnlineMode)
                obj.put("selectedAppPackage", s.selectedAppPackage ?: "")
                obj.put("isActive", s.isActive)
                obj.put("elapsedSeconds", s.elapsedSeconds)
                obj.put("overtimeSeconds", s.overtimeSeconds)
                obj.put("isRunning", s.isRunning)
                obj.put("isFromStudyPlan", s.isFromStudyPlan)
                obj.put("studyPlanId", s.studyPlanId)
                obj.put("creationDate", s.creationDate)
                schedulesArray.put(obj)
            }
            rootObj.put("schedules", schedulesArray)

            val historyArray = JSONArray()
            history.forEach { h ->
                val obj = JSONObject()
                obj.put("id", h.id)
                obj.put("scheduleId", h.scheduleId)
                obj.put("subject", h.subject)
                obj.put("mode", h.mode)
                obj.put("date", h.date)
                obj.put("timeStudiedSeconds", h.timeStudiedSeconds)
                obj.put("completionPercentage", h.completionPercentage)
                obj.put("status", h.status)
                historyArray.put(obj)
            }
            rootObj.put("history", historyArray)
            val overtime = dao.getAllOvertimeEntries().first()
            val overtimeArray = JSONArray()
            overtime.forEach { o ->
                val obj = JSONObject()
                obj.put("id", o.id)
                obj.put("scheduleId", o.scheduleId)
                obj.put("subject", o.subject)
                obj.put("overtimeSeconds", o.overtimeSeconds)
                obj.put("date", o.date)
                overtimeArray.put(obj)
            }
            rootObj.put("overtime_entries", overtimeArray)


            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                OutputStreamWriter(outputStream).use { writer ->
                    writer.write(rootObj.toString(2))
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun restoreBackup(context: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val jsonString = context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream)).use { reader ->
                    reader.readText()
                }
            } ?: return@withContext false

            val rootObj = JSONObject(jsonString)
            val db = XFlowDatabase.getDatabase(context)
            val dao = db.dao()

            if (rootObj.has("schedules")) {
                val schedulesArray = rootObj.getJSONArray("schedules")
                for (i in 0 until schedulesArray.length()) {
                    val obj = schedulesArray.getJSONObject(i)
                    dao.insertSchedule(
                        Schedule(
                            id = obj.getInt("id"),
                            subject = obj.getString("subject"),
                            description = obj.getString("description"),
                            isDurationMode = obj.getBoolean("isDurationMode"),
                            durationMinutes = obj.getInt("durationMinutes"),
                            startTimeStr = obj.getString("startTimeStr"),
                            endTimeStr = obj.getString("endTimeStr"),
                            isOnlineMode = obj.getBoolean("isOnlineMode"),
                            selectedAppPackage = obj.getString("selectedAppPackage").takeIf { it.isNotEmpty() },
                            isActive = obj.getBoolean("isActive"),
                            elapsedSeconds = obj.getInt("elapsedSeconds"),
                            overtimeSeconds = obj.optInt("overtimeSeconds", 0),
                            isRunning = obj.getBoolean("isRunning"),
                            isFromStudyPlan = obj.getBoolean("isFromStudyPlan"),
                            studyPlanId = obj.getInt("studyPlanId"),
                            creationDate = obj.getLong("creationDate")
                        )
                    )
                }
            }

            
            if (rootObj.has("overtime_entries")) {
                val overtimeArray = rootObj.getJSONArray("overtime_entries")
                for (i in 0 until overtimeArray.length()) {
                    val obj = overtimeArray.getJSONObject(i)
                    dao.insertOvertimeEntry(
                        com.example.data.OvertimeEntry(
                            id = obj.getInt("id"),
                            scheduleId = obj.getInt("scheduleId"),
                            subject = obj.getString("subject"),
                            overtimeSeconds = obj.getInt("overtimeSeconds"),
                            date = obj.getLong("date")
                        )
                    )
                }
            }

            if (rootObj.has("history")) {
                val historyArray = rootObj.getJSONArray("history")
                for (i in 0 until historyArray.length()) {
                    val obj = historyArray.getJSONObject(i)
                    dao.insertHistory(
                        HistorySession(
                            id = obj.getInt("id"),
                            scheduleId = obj.getInt("scheduleId"),
                            subject = obj.getString("subject"),
                            mode = obj.getString("mode"),
                            date = obj.getLong("date"),
                            timeStudiedSeconds = obj.getInt("timeStudiedSeconds"),
                            completionPercentage = obj.getInt("completionPercentage"),
                            status = obj.getString("status")
                        )
                    )
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
