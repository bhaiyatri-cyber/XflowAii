package com.example.utils

import com.example.data.Schedule

object TimeUtils {
    fun timeToMinutes(timeStr: String): Int {
        val parts = timeStr.split(":")
        if (parts.size != 2) return 0
        return (parts[0].toIntOrNull() ?: 0) * 60 + (parts[1].toIntOrNull() ?: 0)
    }
    
    fun formatHours(hours: Float): String {
        val totalMinutes = (hours * 60).toInt()
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }

    fun hasTimeOverlap(
        startTime: String, 
        endTime: String, 
        excludeId: Int = -1, 
        activeSchedules: List<Schedule>
    ): Boolean {
        val newStart = timeToMinutes(startTime)
        val newEnd = timeToMinutes(endTime)
        return activeSchedules.any {
            if (!it.isDurationMode && it.id != excludeId) {
                val existingStart = timeToMinutes(it.startTimeStr)
                val existingEnd = timeToMinutes(it.endTimeStr)
                newStart < existingEnd && newEnd > existingStart
            } else {
                false
            }
        }
    }
}
