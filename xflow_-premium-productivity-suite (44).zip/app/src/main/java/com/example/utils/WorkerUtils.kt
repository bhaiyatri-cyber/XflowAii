package com.example.utils

import android.content.Context
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.ExistingPeriodicWorkPolicy
import com.example.service.SchedulingWorker
import com.example.service.DailySummaryWorker
import com.example.service.MidnightRolloverWorker
import java.util.concurrent.TimeUnit

object WorkerUtils {
    fun setupSchedulingWorker(context: Context) {
        val workRequest = PeriodicWorkRequestBuilder<SchedulingWorker>(15, TimeUnit.MINUTES)
            .build()
            
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "SchedulingWorker",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        )
        
        // Setup Daily Summary Worker
        DailySummaryWorker.scheduleNext(context)
        
        // Setup Midnight Auto Rollover Worker (PRO)
        MidnightRolloverWorker.scheduleNext(context)
    }
}
