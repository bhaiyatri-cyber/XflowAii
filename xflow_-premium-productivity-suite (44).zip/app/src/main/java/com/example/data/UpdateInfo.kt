package com.example.data

data class UpdateInfo(
    val isAvailable: Boolean = false,
    val versionCode: Int = 0,
    val versionName: String = "",
    val releaseNotes: String = "",
    val downloadUrl: String = ""
)
