package com.example.ui

import android.text.format.DateFormat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.graphicsLayer

import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.example.utils.TimeUtils
import androidx.compose.animation.scaleIn
import androidx.compose.animation.fadeIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Schedule
import com.example.data.UpdateInfo
import com.example.ui.theme.*
import com.example.utils.PermissionUtils
import androidx.compose.animation.core.animateFloat
import android.widget.Toast

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: XFlowViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToCreate: () -> Unit,
    onNavigateToTask: (Int) -> Unit,
    onNavigateToTodayHistory: () -> Unit,
    onNavigateToAllTimeHistory: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToStudyPlan: () -> Unit
) {

    val context = LocalContext.current
    val prefs = context.getSharedPreferences("xflow_prefs", android.content.Context.MODE_PRIVATE)
    val lastOpenedVersion = prefs.getInt("last_opened_version", 0)
    val currentVersion = com.example.BuildConfig.VERSION_CODE
    var showWhatsNew by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (lastOpenedVersion < currentVersion) {
            showWhatsNew = true
            val updateTimeKey = "update_time_$currentVersion"
            if (prefs.getLong(updateTimeKey, 0L) == 0L) {
                prefs.edit().putLong(updateTimeKey, System.currentTimeMillis()).apply()
            }
        }
    }

    if (showWhatsNew) {
        WhatsNewScreen(
            isFirstInstall = lastOpenedVersion == 0,
            onDismiss = {
                showWhatsNew = false
                prefs.edit().putInt("last_opened_version", currentVersion).apply()
            }
        )
        return
    }
    val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val todayHours by viewModel.todayHours.collectAsStateWithLifecycle()
    val todayOvertimeHours by viewModel.todayOvertimeHours.collectAsStateWithLifecycle()
    val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle()
    val lifetimeOvertimeHours by viewModel.lifetimeOvertimeHours.collectAsStateWithLifecycle()
    val currentStreak by viewModel.currentStreak.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()
    
    val updateInfo by viewModel.updateInfo.collectAsStateWithLifecycle()
    val updateDismissed by viewModel.updateDismissedForSession.collectAsStateWithLifecycle()
    
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                viewModel.checkAndRolloverStudyPlans()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val hasActiveSchedules = activeSchedules.isNotEmpty()
    LaunchedEffect(hasActiveSchedules) {
        if (activeSchedules.isNotEmpty()) {
            val intent = android.content.Intent(context, com.example.service.TrackingService::class.java)
            try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    var showPermissionDialog by remember { mutableStateOf(false) }
    var showPremiumDialog by remember { mutableStateOf(false) }
    var premiumCode by remember { mutableStateOf("") }

    val handleCreateClick = {
        if (PermissionUtils.hasAllPermissions(context)) {
            onNavigateToCreate()
        } else {
            showPermissionDialog = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { DynamicHeader() },
                actions = {
                    PremiumStudyPlanButton(isPremium = isPremium) {
                        if (isPremium) {
                            if (PermissionUtils.hasAllPermissions(context)) {
                                onNavigateToStudyPlan()
                            } else {
                                showPermissionDialog = true
                            }
                        } else {
                            showPremiumDialog = true
                        }
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = handleCreateClick,
                containerColor = XFlowAccent,
                contentColor = XFlowBackground
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Schedule")
            }
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Today",
                    value = TimeUtils.formatHours(todayHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToTodayHistory() }
                )
                StatCard(
                    title = "All Time",
                    value = TimeUtils.formatHours(lifetimeHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToAllTimeHistory() }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("Active Schedules", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            if (activeSchedules.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (history.isNotEmpty()) {
                            Text("All caught up for today! 🎉", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Great job crushing your tasks.", color = XFlowTextSecondary)
                            Spacer(modifier = Modifier.height(24.dp))
                            Button(
                                onClick = handleCreateClick,
                                colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowAccent)
                            ) {
                                Text("Add another task")
                            }
                        } else {
                            Text("No active schedules", color = XFlowTextSecondary)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = handleCreateClick,
                                colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowAccent)
                            ) {
                                Text("Create one now")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(activeSchedules) { schedule ->
                        ScheduleCard(schedule, cardStyle = cardStyle, onClick = { onNavigateToTask(schedule.id) })
                    }
                    item { Spacer(modifier = Modifier.height(80.dp)) }
                }
            }
        }
    }

    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = { Text("Permissions Required") },
            text = { Text("You must grant all required permissions before creating a schedule.") },
            confirmButton = {
                TextButton(onClick = {
                    showPermissionDialog = false
                    onNavigateToPermissions()
                }) {
                    Text("Go to Settings", color = XFlowAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionDialog = false }) {
                    Text("Cancel", color = XFlowTextSecondary)
                }
            },
            containerColor = XFlowSurface,
            titleContentColor = XFlowTextPrimary,
            textContentColor = XFlowTextSecondary
        )
    }
    PremiumDialog(showPremiumDialog, { showPremiumDialog = false }, viewModel)
}

@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    title: String = "",
    value: String,
    overtimeText: String = "",
    isAccent: Boolean = false,
    text: String = "",
    icon: androidx.compose.ui.graphics.vector.ImageVector = androidx.compose.material.icons.Icons.Default.Add
) {
    androidx.compose.material3.Card(
        modifier = modifier,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = if (isAccent) com.example.ui.theme.XFlowAccent.copy(alpha = 0.1f) else com.example.ui.theme.XFlowSurface)
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = Modifier.padding(16.dp)
        ) {
            androidx.compose.material3.Text(
                text = title.ifEmpty { text },
                style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                color = com.example.ui.theme.XFlowTextSecondary
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
            androidx.compose.material3.Text(
                text = value,
                style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = if (isAccent) com.example.ui.theme.XFlowAccent else com.example.ui.theme.XFlowTextPrimary
            )
            if (overtimeText.isNotEmpty()) {
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(4.dp))
                androidx.compose.material3.Text(
                    text = overtimeText,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = com.example.ui.theme.XFlowAccent,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ScheduleCard(schedule: Schedule, cardStyle: String = "Solid", onClick: () -> Unit) {
    val targetTime = if (schedule.isDurationMode) {
        schedule.durationMinutes * 60
    } else {
        try {
            val startParts = schedule.startTimeStr.split(":")
            val endParts = schedule.endTimeStr.split(":")
            val startMins = startParts[0].toInt() * 60 + startParts[1].toInt()
            val endMins = endParts[0].toInt() * 60 + endParts[1].toInt()
            val diff = if (endMins >= startMins) endMins - startMins else (24 * 60 - startMins) + endMins
            diff * 60
        } catch(e:Exception) { 3600 }
    }

    val progress = if (targetTime > 0) (schedule.elapsedSeconds.toFloat() / targetTime).coerceIn(0f, 1f) else 0f
    
    val status = when {
        schedule.elapsedSeconds >= targetTime -> StudyStatus.COMPLETED
        schedule.isRunning -> StudyStatus.RUNNING
        schedule.elapsedSeconds > 0 -> StudyStatus.PAUSED
        else -> StudyStatus.UPCOMING
    }

    val elapsedTimeStr = String.format("%02d:%02d", schedule.elapsedSeconds / 60, schedule.elapsedSeconds % 60)
    val totalTimeStr = String.format("%02d:%02d", targetTime / 60, targetTime % 60)

    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(400),
        label = "progress"
    )

    val scale = remember { Animatable(1f) }

    LaunchedEffect(status) {
        if (status == StudyStatus.COMPLETED) {
            scale.animateTo(1.02f, animationSpec = tween(150))
            scale.animateTo(1f, animationSpec = tween(150))
        }
    }

    val isPremium = schedule.isFromStudyPlan
    val borderColor = if (isPremium) androidx.compose.ui.graphics.Color(0xFFFFD700) else XFlowSurfaceVariant
    val containerColor = if (isPremium) XFlowSurface.copy(alpha = 0.9f) else XFlowSurface

    val isImageStyle = cardStyle == "Image" && schedule.isFromStudyPlan

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isImageStyle) Color.Transparent else containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isPremium) 4.dp else 2.dp),
        border = androidx.compose.foundation.BorderStroke(if (isPremium) 2.dp else 1.dp, borderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.3f),
                                    Color(0xFF8B5CF6).copy(alpha = 0.3f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Box(modifier = Modifier.padding(16.dp)) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(schedule.subject, color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            if (isPremium) {
                                Spacer(Modifier.width(8.dp))
                                Icon(Icons.Default.WorkspacePremium, contentDescription = "Premium", tint = androidx.compose.ui.graphics.Color(0xFFFFD700), modifier = Modifier.size(20.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(schedule.description, color = XFlowTextSecondary, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Badge(text = if (schedule.isOnlineMode) "Online" else "Offline", isAccent = true)
                            
                            when (status) {
                                StudyStatus.UPCOMING -> Badge(text = "Upcoming")
                                StudyStatus.RUNNING -> Badge(text = "Live 🔴", isAccent = true)
                                StudyStatus.PAUSED -> Badge(text = "Paused")
                                StudyStatus.COMPLETED -> Badge(text = "Completed", isAccent = true)
                                else -> {}
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    if (schedule.isOnlineMode) {
                        OnlineAnimation()
                    } else {
                        OfflineIllustration()
                    }
                }

                Spacer(Modifier.height(16.dp))

                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = XFlowAccent,
                    trackColor = XFlowSurfaceVariant
                )

                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val percentage = (animatedProgress * 100).toInt()
                    Text(
                        text = "$percentage%",
                        color = XFlowAccent,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    if (schedule.overtimeSeconds > 0) {
                        val overtimeStr = String.format("%02d:%02d", schedule.overtimeSeconds / 60, schedule.overtimeSeconds % 60)
                        Text(
                            text = "🔥 Overtime: $overtimeStr",
                            color = XFlowAccent,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    } else if (status == StudyStatus.RUNNING || status == StudyStatus.PAUSED) {
                        Text(
                            text = "⏱ $elapsedTimeStr / $totalTimeStr",
                            color = XFlowTextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else if (status == StudyStatus.COMPLETED) {
                        Text(
                            text = getResultStatus(percentage),
                            color = XFlowTextPrimary,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Text(
                            text = "⏱ $totalTimeStr",
                            color = XFlowTextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                
                AnimatedVisibility(
                    visible = status == StudyStatus.COMPLETED,
                    enter = fadeIn(tween(300)) + scaleIn(tween(350))
                ) {
                    Column(modifier = Modifier.padding(top = 12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("✓ Session Completed", color = XFlowSupport, fontWeight = FontWeight.Bold)
                        Text(getResultStatus((progress * 100).toInt()), color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}
    }
@Composable
fun OnlineAnimation() {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(4000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        )
    )
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(XFlowSurfaceVariant.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        val accent = XFlowAccent
        
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(accent)
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .graphicsLayer { rotationZ = rotation }
            ) {
                val appColors = listOf(
                    androidx.compose.ui.graphics.Color(0xFF4285F4),
                    androidx.compose.ui.graphics.Color(0xFF34A853),
                    androidx.compose.ui.graphics.Color(0xFFFBBC05),
                    androidx.compose.ui.graphics.Color(0xFFEA4335)
                )
                
                Box(modifier = Modifier.size(12.dp).align(Alignment.TopCenter).clip(RoundedCornerShape(3.dp)).background(appColors[0]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.CenterEnd).clip(RoundedCornerShape(3.dp)).background(appColors[1]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.BottomCenter).clip(RoundedCornerShape(3.dp)).background(appColors[2]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.CenterStart).clip(RoundedCornerShape(3.dp)).background(appColors[3]))
            }
        }
    }
}


@Composable
fun OfflineIllustration() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = Icons.Default.Add, // Using placeholder since I don't know what it was
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = XFlowTextSecondary.copy(alpha = 0.5f)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Offline Mode",
            color = XFlowTextSecondary,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun PremiumStudyPlanButton(isPremium: Boolean, onClick: () -> Unit) {
    val brush = androidx.compose.ui.graphics.Brush.linearGradient(
        colors = listOf(
            androidx.compose.ui.graphics.Color(0xFFFFD700),
            androidx.compose.ui.graphics.Color(0xFFFFA500)
        )
    )
    Box(
        modifier = Modifier
            .padding(end = 8.dp)
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(XFlowSurface)
            .border(
                width = 2.dp,
                brush = brush,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Add, contentDescription = "Study Plan", tint = androidx.compose.ui.graphics.Color(0xFFFFD700), modifier = Modifier.size(16.dp))
            Text("Study Plan", color = XFlowTextPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            if (!isPremium) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text("PRO", color = androidx.compose.ui.graphics.Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}





@Composable
fun Badge(text: String, isAccent: Boolean = false) {
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
            .background(if (isAccent) com.example.ui.theme.XFlowAccent.copy(alpha = 0.2f) else com.example.ui.theme.XFlowSurfaceVariant)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        androidx.compose.material3.Text(
            text = text,
            color = if (isAccent) com.example.ui.theme.XFlowAccent else com.example.ui.theme.XFlowTextSecondary,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
        )
    }
}


enum class StudyStatus {
    UPCOMING,
    RUNNING,
    PAUSED,
    COMPLETED,
    MISSED
}

fun getResultStatus(percent: Int): String {
    return when (percent) {
        100 -> "Perfect 🏆"
        in 90..99 -> "Outstanding"
        in 80..89 -> "Excellent"
        in 70..79 -> "Very Good"
        in 60..69 -> "Good"
        in 50..59 -> "Average"
        in 40..49 -> "Below Average"
        in 20..39 -> "Poor"
        else -> "Very Poor"
    }
}


@Composable
fun DynamicHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.app_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "XFlow",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = XFlowAccent
        )
    }
}
