package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.HistorySession
import com.example.data.UpdateInfo
import com.example.utils.UpdateManager
import com.example.data.Schedule
import com.example.data.StudyPlan
import com.example.data.StudyPlanItem
import com.example.data.XFlowDatabase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class XFlowViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("xflow_prefs", android.content.Context.MODE_PRIVATE)
    
    private val _isPremium = kotlinx.coroutines.flow.MutableStateFlow(prefs.getBoolean("is_premium", false))
    val isPremium: StateFlow<Boolean> = _isPremium

    private val _themeColor = kotlinx.coroutines.flow.MutableStateFlow(prefs.getLong("theme_color", 0xFF00E5FF))
    val themeColor: StateFlow<Long> = _themeColor

    private val _themeStyle = kotlinx.coroutines.flow.MutableStateFlow(prefs.getString("theme_style", "Dark") ?: "Dark")
    val themeStyle: StateFlow<String> = _themeStyle

    private val _cardStyle = kotlinx.coroutines.flow.MutableStateFlow(prefs.getString("card_style", "Solid") ?: "Solid")
    val cardStyle: StateFlow<String> = _cardStyle

    private val updateManager = UpdateManager(application)
    private val _updateInfo = kotlinx.coroutines.flow.MutableStateFlow<UpdateInfo?>(null)
    val updateInfo: StateFlow<UpdateInfo?> = _updateInfo
    private val _updateDismissedForSession = kotlinx.coroutines.flow.MutableStateFlow(false)
    val updateDismissedForSession: StateFlow<Boolean> = _updateDismissedForSession

    init {
        viewModelScope.launch {
            _updateInfo.value = updateManager.checkUpdateAvailable()
        }
    }

    fun dismissUpdatePrompt() {
        _updateDismissedForSession.value = true
    }

    fun startUpdateDownload() {
        _updateInfo.value?.let { info ->
            updateManager.startDownload(info.downloadUrl, info.versionCode)
            dismissUpdatePrompt()
        }
    }
    
    fun checkForUpdatesManual() {
        viewModelScope.launch {
            _updateInfo.value = updateManager.checkUpdateAvailable()
        }
    }

    fun updateThemeStyle(style: String) {
        prefs.edit().putString("theme_style", style).apply()
        _themeStyle.value = style
    }

    fun updateCardStyle(style: String) {
        prefs.edit().putString("card_style", style).apply()
        _cardStyle.value = style
    }



    fun updateThemeColor(color: Long) {
        prefs.edit().putLong("theme_color", color).apply()
        _themeColor.value = color
    }
    
    fun activatePremium(code: String): Boolean {
        if (code.equals("Nitesh", ignoreCase = true)) {
            prefs.edit().putBoolean("is_premium", true).apply()
            _isPremium.value = true
            return true
        }
        return false
    }

    private val db = XFlowDatabase.getDatabase(application)
    
    val activeSchedules: StateFlow<List<Schedule>> = db.dao().getActiveSchedules()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        
    val history: StateFlow<List<HistorySession>> = db.dao().getAllHistory()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val currentStreak: StateFlow<Int> = history.map { list ->
        if (list.isEmpty()) return@map 0
        
        val dates = list.map { 
            val cal = Calendar.getInstance()
            cal.timeInMillis = it.date
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            cal.timeInMillis
        }.distinct().sortedDescending()
        
        if (dates.isEmpty()) return@map 0
        
        var streak = 0
        val todayCal = Calendar.getInstance()
        todayCal.set(Calendar.HOUR_OF_DAY, 0)
        todayCal.set(Calendar.MINUTE, 0)
        todayCal.set(Calendar.SECOND, 0)
        todayCal.set(Calendar.MILLISECOND, 0)
        val today = todayCal.timeInMillis
        val yesterday = today - (24 * 60 * 60 * 1000)
        
        var expectedDate = today
        if (dates[0] == today) {
            streak = 1
            expectedDate = yesterday
            for (i in 1 until dates.size) {
                if (dates[i] == expectedDate) {
                    streak++
                    expectedDate -= (24 * 60 * 60 * 1000)
                } else {
                    break
                }
            }
        } else if (dates[0] == yesterday) {
            streak = 1
            expectedDate = yesterday - (24 * 60 * 60 * 1000)
            for (i in 1 until dates.size) {
                if (dates[i] == expectedDate) {
                    streak++
                    expectedDate -= (24 * 60 * 60 * 1000)
                } else {
                    break
                }
            }
        }
        streak
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0)


        val offlineChats: kotlinx.coroutines.flow.StateFlow<List<com.example.data.OfflineChat>> = db.dao().getAllOfflineChats()
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.Lazily, emptyList())

    fun insertOfflineChat(role: String, message: String) {
        viewModelScope.launch {
            db.dao().insertOfflineChat(com.example.data.OfflineChat(role = role, message = message, timestamp = System.currentTimeMillis()))
        }
    }
    
    fun clearOfflineChats() {
        viewModelScope.launch {
            db.dao().clearOfflineChats()
        }
    }
    
    fun createScheduleFromChatbot(name: String, description: String, time: String) {
        viewModelScope.launch {
            db.dao().insertSchedule(
                com.example.data.Schedule(
                    subject = name,
                    description = "$description\nTime: $time",
                    isDurationMode = true,
                    durationMinutes = 25,
                    startTimeStr = "",
                    endTimeStr = "",
                    isOnlineMode = false,
                    selectedAppPackage = null,
                    isActive = true
                )
            )
        }
    }

    val overtimeEntries: StateFlow<List<com.example.data.OvertimeEntry>> = db.dao().getAllOvertimeEntries()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val todayHours: StateFlow<Float> = kotlinx.coroutines.flow.combine(history, activeSchedules) { list, actives ->
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val todayStart = cal.timeInMillis
        val historySum = list.filter { it.date > todayStart }.sumOf { it.timeStudiedSeconds }
        val activeSum = actives.sumOf { it.elapsedSeconds }
        (historySum + activeSum) / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val lifetimeHours: StateFlow<Float> = kotlinx.coroutines.flow.combine(history, activeSchedules) { list, actives ->
        val historySum = list.sumOf { it.timeStudiedSeconds }
        val activeSum = actives.sumOf { it.elapsedSeconds }
        (historySum + activeSum) / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val todayOvertimeHours: StateFlow<Float> = kotlinx.coroutines.flow.combine(overtimeEntries, activeSchedules) { list, actives ->
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val todayStart = cal.timeInMillis
        val historySum = list.filter { it.date > todayStart }.sumOf { it.overtimeSeconds }
        val activeSum = actives.sumOf { it.overtimeSeconds }
        (historySum + activeSum) / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val lifetimeOvertimeHours: StateFlow<Float> = kotlinx.coroutines.flow.combine(overtimeEntries, activeSchedules) { list, actives ->
        val historySum = list.sumOf { it.overtimeSeconds }
        val activeSum = actives.sumOf { it.overtimeSeconds }
        (historySum + activeSum) / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    init {
        checkAndRolloverStudyPlans()
    }

    private fun getCurrentDay(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun checkAndRolloverStudyPlans() {
        viewModelScope.launch {
            val plans = db.dao().getAllStudyPlans()
            val currentDayMillis = getCurrentDay()
            
            var generatedAny = false
            for (plan in plans) {
                if (plan.lastGeneratedDay < currentDayMillis) {
                    val creationDay = Calendar.getInstance().apply { timeInMillis = plan.createdAt; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                    val daysSinceCreation = (currentDayMillis - creationDay) / 86400000
                    if (plan.recurrenceDays == -1 || daysSinceCreation <= plan.recurrenceDays) {
                        val items = db.dao().getStudyPlanItems(plan.id)
                        for (item in items) {
                            val schedule = Schedule(
                                subject = item.subject,
                                description = item.description,
                                isDurationMode = false,
                                durationMinutes = 0,
                                startTimeStr = item.startTimeStr,
                                endTimeStr = item.endTimeStr,
                                isOnlineMode = item.isOnlineMode,
                                selectedAppPackage = item.selectedAppPackage,
                                isActive = true,
                                isFromStudyPlan = true,
                                studyPlanId = plan.id,
                                creationDate = System.currentTimeMillis()
                            )
                            db.dao().insertSchedule(schedule)
                        }
                        db.dao().updateStudyPlanGeneratedDay(plan.id, currentDayMillis)
                        generatedAny = true
                    }
                }
            }
            
            if (generatedAny) {
                val activeSchedules = db.dao().getActiveSchedulesSync()
                for (schedule in activeSchedules) {
                    if (schedule.creationDate < currentDayMillis && schedule.isFromStudyPlan) {
                        db.dao().insertHistory(
                            HistorySession(
                                scheduleId = schedule.id,
                                subject = schedule.subject,
                                mode = "Exact Time",
                                date = schedule.creationDate,
                                timeStudiedSeconds = schedule.elapsedSeconds,
                                completionPercentage = if (schedule.elapsedSeconds > 0) 50 else 0,
                                status = if (schedule.elapsedSeconds > 0) "Partial" else "Missed"
                            )
                        )
                        db.dao().deactivateSchedule(schedule.id)
                    }
                }
            }
        }
    }

    fun saveStudyPlan(recurrenceDays: Int, items: List<StudyPlanItem>) {
        viewModelScope.launch {
            val currentDayMillis = getCurrentDay()
            val plan = StudyPlan(
                recurrenceDays = recurrenceDays,
                createdAt = System.currentTimeMillis(),
                lastGeneratedDay = currentDayMillis
            )
            val planId = db.dao().insertStudyPlan(plan).toInt()
            
            val updatedItems = items.map { it.copy(planId = planId) }
            db.dao().insertStudyPlanItems(updatedItems)
            
            for (item in updatedItems) {
                val schedule = Schedule(
                    subject = item.subject,
                    description = item.description,
                    isDurationMode = false,
                    durationMinutes = 0,
                    startTimeStr = item.startTimeStr,
                    endTimeStr = item.endTimeStr,
                    isOnlineMode = item.isOnlineMode,
                    selectedAppPackage = item.selectedAppPackage,
                    isActive = true,
                    isFromStudyPlan = true,
                    studyPlanId = planId,
                    creationDate = System.currentTimeMillis()
                )
                db.dao().insertSchedule(schedule)
            }
            
            checkAndRolloverStudyPlans()
        }
    }

    fun addSchedule(schedule: Schedule, context: android.content.Context) {
        viewModelScope.launch {
            val id = db.dao().insertSchedule(schedule)
            val intent = android.content.Intent(context, com.example.service.TrackingService::class.java)
            intent.putExtra("schedule_id", id.toInt())
            try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updateSchedule(schedule: Schedule) {
        viewModelScope.launch {
            db.dao().updateSchedule(schedule)
        }
    }

    fun completeSession(schedule: Schedule, secondsStudied: Int, percent: Int, status: String) {
        viewModelScope.launch {
            db.dao().insertHistory(
                HistorySession(
                    scheduleId = schedule.id,
                    subject = schedule.subject,
                    mode = if (schedule.isDurationMode) "Duration" else "Exact Time",
                    date = System.currentTimeMillis(),
                    timeStudiedSeconds = secondsStudied,
                    completionPercentage = percent,
                    status = status
                )
            )
            db.dao().deactivateSchedule(schedule.id)
        }
    }
}
