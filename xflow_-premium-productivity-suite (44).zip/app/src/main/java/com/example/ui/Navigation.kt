package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navDeepLink

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val CREATE_SCHEDULE = "create_schedule"
    const val TASK_DETAILS = "task_details/{id}"
    const val HISTORY = "history"
    const val PROGRESS = "progress"
    const val TODAY_HISTORY = "today_history"
    const val ALL_TIME_HISTORY = "all_time_history"
    const val SETTINGS = "settings"
    const val IMAGE_TO_PDF = "image_to_pdf"
    const val PERMISSIONS = "permissions"
    const val STUDY_PLAN = "study_plan"
    const val ABOUT = "about"
    const val THEME_SETTINGS = "theme_settings"
    const val BACKUP = "backup"
    const val OVERTIME = "overtime"
    const val DAILY_REPORT = "daily_report"
    
    const val CHATBOT = "chatbot"
    const val MOCK_TEST = "mock_test/{id}"
    const val DATA_DRIVE = "data_drive"
    const val YOUTUBE = "youtube"
    const val CHATGPT = "chatgpt"
    
    
    fun taskDetails(id: Int) = "task_details/$id"
}

@Composable
fun XFlowApp(
    viewModel: XFlowViewModel,
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onNavigateToHome = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }
        composable(
            Routes.HOME,
            deepLinks = listOf(navDeepLink { uriPattern = "xflow://home" })
        ) {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) },
                onNavigateToCreate = { navController.navigate(Routes.CREATE_SCHEDULE) },
                onNavigateToTask = { id -> navController.navigate(Routes.taskDetails(id)) },
                onNavigateToTodayHistory = { navController.navigate(Routes.TODAY_HISTORY) },
                onNavigateToAllTimeHistory = { navController.navigate(Routes.ALL_TIME_HISTORY) },
                onNavigateToPermissions = { navController.navigate(Routes.PERMISSIONS) },
                onNavigateToStudyPlan = { navController.navigate(Routes.STUDY_PLAN) }
            )
        }
        composable(Routes.STUDY_PLAN) {
            StudyPlanScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.CREATE_SCHEDULE) {
            CreateScheduleScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.TASK_DETAILS) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")?.toIntOrNull() ?: 0
            TaskDetailsScreen(
                id = id,
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.HISTORY) {
            HistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToTask = { id -> navController.navigate(Routes.taskDetails(id)) }
            )
        }
        composable(Routes.TODAY_HISTORY) {
            TodayHistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.ALL_TIME_HISTORY) {
            AllTimeHistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToPdf = { navController.navigate(Routes.IMAGE_TO_PDF) },
                onNavigateToPermissions = { navController.navigate(Routes.PERMISSIONS) },
                onNavigateToAbout = { navController.navigate(Routes.ABOUT) },
                onNavigateToThemeSettings = { navController.navigate(Routes.THEME_SETTINGS) },
                onNavigateToBackup = { navController.navigate(Routes.BACKUP) },
                onNavigateToOvertime = { navController.navigate(Routes.OVERTIME) },
                
                onNavigateToChatbot = { navController.navigate(Routes.CHATBOT) },
                onNavigateToDataDrive = { navController.navigate(Routes.DATA_DRIVE) },
                onNavigateToYouTube = { navController.navigate(Routes.YOUTUBE) },
                onNavigateToChatGPT = { navController.navigate(Routes.CHATGPT) },
                onNavigateToDailyReport = { navController.navigate(Routes.DAILY_REPORT) }
            )
        }
        composable(Routes.PERMISSIONS) {
            PermissionsScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.IMAGE_TO_PDF) {
            ImageToPdfScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.OVERTIME) {
            OvertimeScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
        composable(Routes.DAILY_REPORT) {
            DailyReportScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
        composable(Routes.BACKUP) {
            BackupRestoreScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.THEME_SETTINGS) {
            ThemeSettingsScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
        composable(Routes.DATA_DRIVE) {
            DataDriveScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.YOUTUBE) {
            YouTubeScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.CHATGPT) {
            ChatGPTScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.ABOUT) {
            AboutScreen(
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.CHATBOT) {
            ChatbotScreen(navController = navController, onBack = { navController.popBackStack() }, viewModel = viewModel)
        }
        composable(
            Routes.MOCK_TEST,
            deepLinks = listOf(androidx.navigation.navDeepLink { uriPattern = "xflow://mock_test/{id}" })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")?.toIntOrNull() ?: 0
            MockTestAttemptScreen(navController = navController, testId = id)
        }


    }
}
