package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.XFlowBackground
import com.example.ui.theme.XFlowTextPrimary
import com.example.ui.theme.XFlowTextSecondary
import com.example.ui.theme.XFlowSurface
import com.example.ui.theme.XFlowAccent
import com.example.ui.theme.XFlowSurfaceVariant

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeSettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit) {
    val currentThemeColorLong by viewModel.themeColor.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val currentThemeColor = Color(currentThemeColorLong)
    var showPremiumDialog by remember { mutableStateOf(false) }

    val freeOptions = listOf(
        ThemeColorOption("Cyan", 0xFF00E5FF),
        ThemeColorOption("Green", 0xFF10B981),
        ThemeColorOption("Red", 0xFFF43F5E)
    )

    // For custom color picker
    var customHue by remember { mutableStateOf(0f) }
    val customColor = remember(customHue) { Color.hsv(customHue, 1f, 1f) }
    
    val currentCardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()
    val cardStyles = listOf("Solid", "Image", "Gradient", "Outlined", "Soft")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Theme & Appearance", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            ThemeSettingsSection("Basic Colors") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    freeOptions.forEach { option ->
                        FilterChip(
                            selected = currentThemeColorLong == option.colorValue,
                            onClick = { viewModel.updateThemeColor(option.colorValue) },
                            label = { Text(option.name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = XFlowAccent,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            ThemeSettingsSection("Card Background (PRO)") {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                    Text("Select Style", color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                    if (!isPremium) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.Lock, contentDescription = "Locked", tint = XFlowTextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    cardStyles.forEach { style ->
                        FilterChip(
                            selected = currentCardStyle == style,
                            onClick = {
                                if (isPremium) {
                                    viewModel.updateCardStyle(style)
                                } else {
                                    showPremiumDialog = true
                                }
                            },
                            label = { Text(style) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = XFlowAccent,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            ThemeSettingsSection("Custom Colors (PRO)") {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                    Text("Pick Any Color", color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                    if (!isPremium) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.Lock, contentDescription = "Locked", tint = XFlowTextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
                Text("Select a custom color for accents and buttons.", style = MaterialTheme.typography.bodySmall, color = XFlowTextSecondary)
                Spacer(modifier = Modifier.height(16.dp))
                
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    val maxWidth = constraints.maxWidth.toFloat()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        Color.hsv(0f, 1f, 1f),
                                        Color.hsv(60f, 1f, 1f),
                                        Color.hsv(120f, 1f, 1f),
                                        Color.hsv(180f, 1f, 1f),
                                        Color.hsv(240f, 1f, 1f),
                                        Color.hsv(300f, 1f, 1f),
                                        Color.hsv(360f, 1f, 1f)
                                    )
                                )
                            )
                            .pointerInput(Unit) {
                                detectDragGestures { change, _ ->
                                    if (!isPremium) {
                                        showPremiumDialog = true
                                        return@detectDragGestures
                                    }
                                    val position = change.position.x.coerceIn(0f, maxWidth)
                                    customHue = (position / maxWidth) * 360f
                                }
                            }
                            .clickable {
                                if (!isPremium) {
                                    showPremiumDialog = true
                                }
                            }
                    ) {
                        if (isPremium) {
                            Box(
                                modifier = Modifier
                                    .offset(
                                        x = ((customHue / 360f) * (this@BoxWithConstraints.maxWidth.value - 24)).dp,
                                        y = 8.dp
                                    )
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(customColor)
                                    .border(2.dp, Color.White, CircleShape)
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                if (isPremium) {
                    Button(
                        onClick = {
                            val hsvColor = Color.hsv(customHue, 1f, 1f)
                            val r = (hsvColor.red * 255).toLong()
                            val g = (hsvColor.green * 255).toLong()
                            val b = (hsvColor.blue * 255).toLong()
                            val colorLong = 0xFF000000L or (r shl 16) or (g shl 8) or b
                            viewModel.updateThemeColor(colorLong)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = customColor)
                    ) {
                        Text("Apply Custom Color", color = if (customColor.luminance() > 0.5f) Color.Black else Color.White, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = { showPremiumDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowTextPrimary)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "Locked")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Unlock Custom Colors (PRO)")
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showPremiumDialog) {
        AlertDialog(
            onDismissRequest = { showPremiumDialog = false },
            title = { Text("Premium Feature", color = XFlowTextPrimary) },
            text = { Text("This is a Premium feature. Please upgrade from the Home screen.", color = XFlowTextSecondary) },
            confirmButton = {
                TextButton(onClick = { showPremiumDialog = false }) {
                    Text("OK", color = XFlowAccent)
                }
            },
            containerColor = XFlowSurface
        )
    }
}

@Composable
fun ThemeSettingsSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.padding(vertical = 8.dp).fillMaxWidth()) {
        Text(
            text = title,
            color = XFlowTextSecondary,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp, start = 8.dp)
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = XFlowSurface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                content()
            }
        }
    }
}

data class ThemeColorOption(val name: String, val colorValue: Long)

fun Color.luminance(): Float {
    val r = this.red.toDouble()
    val g = this.green.toDouble()
    val b = this.blue.toDouble()
    return (0.299 * r + 0.587 * g + 0.114 * b).toFloat()
}
