package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

@Composable
fun XFlowTheme(
    themeColor: Long = 0xFF00E5FF,
    themeStyle: String = "Dark",
    content: @Composable () -> Unit,
) {
    val accentColor = Color(themeColor)
    
    val xflowColors = when (themeStyle) {
        "Light" -> lightColors()
        "Neon" -> neonColors()
        else -> darkColors()
    }

    val colorScheme = darkColorScheme(
        primary = accentColor,
        secondary = accentColor.copy(alpha = 0.8f),
        tertiary = accentColor,
        background = xflowColors.background,
        surface = xflowColors.surface,
        surfaceVariant = xflowColors.surfaceVariant,
        onPrimary = xflowColors.background,
        onSecondary = xflowColors.background,
        onTertiary = xflowColors.background,
        onBackground = xflowColors.textPrimary,
        onSurface = xflowColors.textPrimary,
        onSurfaceVariant = xflowColors.textSecondary,
        error = xflowColors.error
    )

    CompositionLocalProvider(LocalXFlowColors provides xflowColors) {
        MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
    }
}
