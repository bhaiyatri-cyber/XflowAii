package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.serialization.json.*

class AiViewModel(application: Application) : AndroidViewModel(application) {
    private val db = XFlowDatabase.getDatabase(application)
    val currentSessionId = MutableStateFlow("default")
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val aiChats = currentSessionId.flatMapLatest { sessionId ->
        db.dao().getAllAiChats(sessionId)
    }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isGenerating = MutableStateFlow(false)

    
    val allSessions = db.dao().getAiChatSessions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allMockTests = db.dao().getAllMockTests().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun loadSession(sessionId: String) {
        currentSessionId.value = sessionId
    }
    
    fun createNewSession() {
        currentSessionId.value = "session_" + System.currentTimeMillis()
    }
    
    fun clearChat() {
        viewModelScope.launch {
            db.dao().deleteAllAiChats(currentSessionId.value)
        }
    }

    fun sendMessage(message: String) {
        viewModelScope.launch {
            db.dao().insertAiChat(AiChat(role = "user", message = message, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
            isGenerating.value = true
            
            try {
                // Construct history carefully to ensure strictly alternating roles for Gemini
                val currentChats = aiChats.value.toList()
                val filteredChats = if (currentChats.isNotEmpty() && currentChats.last().role == "user" && currentChats.last().message == message) {
                    currentChats.dropLast(1)
                } else {
                    currentChats
                }

                val recentChats = filteredChats.takeLast(10).toMutableList()
                while (recentChats.isNotEmpty() && recentChats.first().role != "user") {
                    recentChats.removeAt(0)
                }
                
                var lastRole = ""
                val validHistory = mutableListOf<AiChat>()
                for (chat in recentChats) {
                    val role = if (chat.role == "model") "model" else "user"
                    if (role != lastRole) {
                        validHistory.add(chat)
                        lastRole = role
                    }
                }
                
                if (validHistory.isNotEmpty() && validHistory.last().role != "model") {
                    validHistory.removeAt(validHistory.lastIndex)
                }

                val history = validHistory.map { chat ->
                    Content(role = if (chat.role == "model") "model" else "user", parts = listOf(Part(text = chat.message)))
                }.toMutableList()

                history.add(Content(role = "user", parts = listOf(Part(text = message))))
                
                val request = GenerateContentRequest(
                    contents = history,
                    systemInstruction = Content(parts = listOf(Part(text = "You are XFlow AI, a helpful assistant. You help users with study tips, productivity, and focus techniques. IF the user asks to create or generate a mock test (e.g., 'mujhe 10 number ka science test bana do' or 'create a 5 question math test'), you MUST respond EXACTLY with the following format: [GENERATE_MOCK_TEST:number:topic] and nothing else. For example: [GENERATE_MOCK_TEST:10:science]. Do not add any conversational text.")))
                )
                
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isBlank() || apiKey == "null") {
                    throw Exception("API Key not found or empty.")
                }

                val response = RetrofitClient.service.generateContent(apiKey, request)
                var responseText = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "I'm sorry, I couldn't generate a response."
                
                if (responseText.contains("[GENERATE_MOCK_TEST:")) {
                    try {
                        val parts = responseText.substringAfter("[GENERATE_MOCK_TEST:").substringBefore("]").split(":")
                        val number = parts.getOrNull(0)?.toIntOrNull() ?: 5
                        val topic = parts.getOrNull(1) ?: "General Knowledge"
                        
                        val prompt = "Generate $number multiple choice questions about $topic. Respond ONLY with valid JSON in this exact format: {\"questions\": [{\"q\": \"Question text?\", \"options\": [\"A\", \"B\", \"C\", \"D\"], \"answerIndex\": 0}]} where answerIndex is the index (0-3) of the correct option. No markdown, no code blocks, just raw JSON."
                        val jsonRequest = GenerateContentRequest(
                            contents = listOf(Content(role = "user", parts = listOf(Part(text = prompt))))
                        )
                        val jsonResponse = RetrofitClient.service.generateContent(apiKey, jsonRequest)
                        var jsonText = jsonResponse.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "[]"
                        jsonText = jsonText.replace("```json", "").replace("```", "").trim()
                        
                        val newTest = MockTest(
                            title = "$topic Test",
                            testDataJson = jsonText,
                            date = System.currentTimeMillis(),
                            totalQuestions = number
                        )
                        val testId = db.dao().insertMockTest(newTest).toInt()
                        responseText = "[MOCK_TEST_CARD:$testId:$topic Test]"
                    } catch (e: Exception) {
                        responseText = "Sorry, I encountered an error generating the mock test."
                    }
                }
                
                db.dao().insertAiChat(AiChat(role = "model", message = responseText, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))

            } catch (e: Exception) {
                val errorMessage = e.message ?: ""
                val msg = if (errorMessage.contains("429") || errorMessage.contains("quota", ignoreCase = true) || errorMessage.contains("exhausted", ignoreCase = true)) {
                    "Daily limit reached for AI chatting. The API quota has been exhausted and will reset tomorrow."
                } else {
                    "Error: ${e.message}. (Make sure you have configured a valid GEMINI_API_KEY)."
                }
                db.dao().insertAiChat(AiChat(role = "model", message = msg, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
            } finally {
                isGenerating.value = false
            }
        }
    }
}