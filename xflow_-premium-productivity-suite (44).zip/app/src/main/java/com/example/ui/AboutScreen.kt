package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.Alignment
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("About XFlow", "Terms of Use", "Licenses")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = XFlowBackground,
                contentColor = XFlowAccent,
                indicator = { tabPositions ->
                    if (selectedTabIndex < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = XFlowAccent
                        )
                    }
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                color = if (selectedTabIndex == index) XFlowAccent else XFlowTextSecondary,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(XFlowSurface)
                        .padding(16.dp)
                ) {
                    when (selectedTabIndex) {
                        0 -> AboutTab()
                        1 -> TermsTab()
                        2 -> LicensesTab()
                    }
                }
            }
        }
    }
}

@Composable
fun AboutTab() {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.app_logo),
                contentDescription = "Logo",
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text("ABOUT XFLOW AI", style = MaterialTheme.typography.titleMedium, color = XFlowAccent, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "XFlow is a smart study and productivity tracking app designed to help users plan study sessions, track focused time, monitor progress, and build better study habits.\n\n" +
            "Key Features:\n" +
            "• Smart Schedule Management\n" +
            "• Live Study Timer\n" +
            "• Online App Tracking\n" +
            "• Offline Tracking\n" +
            "• Study History\n" +
            "• Progress Analytics\n" +
            "• Smart Notifications\n" +
            "• Backup & Restore\n" +
            "• Image to PDF Converter\n\n" +
            "XFlow is designed to be clean, simple, premium, and fast, with an offline-first approach for reliable daily use.",
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.bodyMedium
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text("Copyright:", style = MaterialTheme.typography.titleMedium, color = XFlowAccent, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "XFlow © 2026\n" +
            "All rights reserved.\n" +
            "The XFlow name, logo, design, and original content are protected by copyright laws.\n" +
            "Unauthorized copying, distribution, or modification is not allowed.",
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun TermsTab() {
    Column {
        Text("Terms of Use:", style = MaterialTheme.typography.titleMedium, color = XFlowAccent, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "XFlow is provided for personal productivity and study tracking purposes only.\n" +
            "Users are responsible for how they use the app and the data they create.\n" +
            "The app may be updated, improved, or changed over time.\n" +
            "XFlow is provided \"as is\" without any guarantee of uninterrupted service.\n" +
            "By using XFlow, you agree to follow the app's rules and intended use.",
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun LicensesTab() {
    Column {
        Text("Open Source Licenses:", style = MaterialTheme.typography.titleMedium, color = XFlowAccent, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "XFlow may use third-party libraries and open-source components.\n" +
            "These libraries are used under their respective licenses such as MIT, Apache 2.0, or other applicable open-source licenses.\n\n" +
            "Libraries used include:\n" +
            "• Jetpack Compose (Apache 2.0)\n" +
            "• Kotlin Coroutines (Apache 2.0)\n" +
            "• Room Database (Apache 2.0)\n" +
            "• Material Design 3 (Apache 2.0)",
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
