package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.XFlowAccent
import com.example.ui.theme.XFlowBackground
import com.example.ui.theme.XFlowSurface
import com.example.ui.theme.XFlowTextPrimary
import com.example.ui.theme.XFlowTextSecondary

@Composable
fun PremiumDialog(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    viewModel: XFlowViewModel
) {
    if (!showDialog) return
    
    var premiumCode by remember { mutableStateOf("") }
    val context = LocalContext.current
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = XFlowSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(id = R.drawable.app_logo),
                    contentDescription = "Premium",
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "XFlow Pro",
                    style = MaterialTheme.typography.headlineMedium,
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Unlock exclusive features and elevate your productivity.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = XFlowTextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                
                PremiumFeatureRowDialog(Icons.Default.Palette, "Custom Themes & Colors")
                Spacer(modifier = Modifier.height(12.dp))
                PremiumFeatureRowDialog(Icons.Default.PictureAsPdf, "Image to PDF Converter")
                Spacer(modifier = Modifier.height(12.dp))
                PremiumFeatureRowDialog(Icons.Default.AutoGraph, "Advanced Study Plans")
                
                Spacer(modifier = Modifier.height(32.dp))
                
                OutlinedTextField(
                    value = premiumCode,
                    onValueChange = { premiumCode = it },
                    label = { Text("Activation Code") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = XFlowAccent,
                        focusedLabelColor = XFlowAccent,
                        cursorColor = XFlowAccent
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Button(
                    onClick = {
                        if (viewModel.activatePremium(premiumCode)) {
                            onDismiss()
                            Toast.makeText(context, "Premium Activated!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Invalid Code", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = XFlowBackground),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Upgrade to PRO", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                TextButton(onClick = onDismiss) {
                    Text("Maybe Later", color = XFlowTextSecondary)
                }
            }
        }
    }
}

@Composable
fun PremiumFeatureRowDialog(icon: ImageVector, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(XFlowAccent.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = XFlowAccent,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = text,
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium
        )
    }
}
