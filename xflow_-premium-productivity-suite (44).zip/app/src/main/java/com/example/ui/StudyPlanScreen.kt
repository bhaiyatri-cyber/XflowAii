package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.StudyPlan
import com.example.data.StudyPlanItem
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyPlanScreen(
    viewModel: XFlowViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var itemsList by remember { mutableStateOf(listOf<StudyPlanItem>()) }
    
    // Add Item Form State
    var showAddItem by remember { mutableStateOf(false) }
    var subject by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var startTime by remember { mutableStateOf("08:00") }
    var endTime by remember { mutableStateOf("09:00") }
    var isOnlineMode by remember { mutableStateOf(false) }
    
    var selectedAppPackage by remember { mutableStateOf("") }
    var selectedAppName by remember { mutableStateOf("Select App") }
    var showAppSelector by remember { mutableStateOf(false) }
    var appsList by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    
    // Settings
    var recurrenceDays by remember { mutableStateOf("-1") } // -1 for Always

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val apps = getInstalledApps(context.packageManager)
            withContext(Dispatchers.Main) {
                appsList = apps
                if (apps.isNotEmpty()) {
                    selectedAppPackage = apps[0].packageName
                    selectedAppName = apps[0].name
                }
            }
        }
    }

    val showTimePicker = { isStart: Boolean ->
        val calendar = Calendar.getInstance()
        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMinute = calendar.get(Calendar.MINUTE)
        
        android.app.TimePickerDialog(
            context,
            { _, hourOfDay, minute ->
                val timeStr = String.format("%02d:%02d", hourOfDay, minute)
                if (isStart) startTime = timeStr else endTime = timeStr
            },
            currentHour,
            currentMinute,
            true
        ).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Study Plan", color = XFlowTextPrimary, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            
            Text("Plan Settings", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = recurrenceDays,
                onValueChange = { recurrenceDays = it },
                label = { Text("Recurrence Days (-1 for always)") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XFlowAccent,
                    focusedLabelColor = XFlowAccent
                )
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            Text("Schedules", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            
            if (showAddItem) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(XFlowSurface)
                        .padding(16.dp)
                ) {
                    Column {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("New Schedule", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { showAddItem = false }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, "Close")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("Subject") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Description") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = startTime,
                                onValueChange = { },
                                readOnly = true,
                                label = { Text("Start Time") },
                                modifier = Modifier.weight(1f).clickable { showTimePicker(true) },
                                enabled = false,
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = XFlowTextPrimary,
                                    disabledBorderColor = XFlowSurfaceVariant,
                                    disabledLabelColor = XFlowTextSecondary
                                )
                            )
                            OutlinedTextField(
                                value = endTime,
                                onValueChange = { },
                                readOnly = true,
                                label = { Text("End Time") },
                                modifier = Modifier.weight(1f).clickable { showTimePicker(false) },
                                enabled = false,
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = XFlowTextPrimary,
                                    disabledBorderColor = XFlowSurfaceVariant,
                                    disabledLabelColor = XFlowTextSecondary
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = isOnlineMode,
                                onCheckedChange = { isOnlineMode = it },
                                colors = CheckboxDefaults.colors(checkedColor = XFlowAccent)
                            )
                            Text("Online Mode (Requires App)", color = XFlowTextPrimary)
                        }
                        if (isOnlineMode) {
                            Spacer(modifier = Modifier.height(16.dp))
                            OutlinedCard(
                                modifier = Modifier.fillMaxWidth().clickable { showAppSelector = true },
                                colors = CardDefaults.outlinedCardColors(containerColor = XFlowBackground),
                                border = androidx.compose.foundation.BorderStroke(1.dp, XFlowSurfaceVariant)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Target App", color = XFlowTextSecondary, style = MaterialTheme.typography.labelMedium)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(selectedAppName, color = XFlowTextPrimary, style = MaterialTheme.typography.bodyLarge)
                                    }
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Select App", tint = XFlowTextSecondary)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))

                        val isPlanFormValid = subject.isNotBlank() && startTime.isNotBlank() && endTime.isNotBlank() && (!isOnlineMode || selectedAppPackage.isNotBlank())

                        Button(
                            onClick = {
                                if (isPlanFormValid) {
                                    val newItem = StudyPlanItem(
                                        planId = 0, // Will be set when saving plan
                                        subject = subject,
                                        description = description,
                                        startTimeStr = startTime,
                                        endTimeStr = endTime,
                                        isOnlineMode = isOnlineMode,
                                        selectedAppPackage = if (isOnlineMode) selectedAppPackage else null
                                    )
                                    itemsList = itemsList + newItem
                                    
                                    // Reset form
                                    subject = ""
                                    description = ""
                                    val cal = Calendar.getInstance()
                                    val ch = cal.get(Calendar.HOUR_OF_DAY)
                                    val cm = cal.get(Calendar.MINUTE)
                                    startTime = String.format("%02d:%02d", ch, cm)
                                    endTime = String.format("%02d:%02d", (ch + 1) % 24, cm)
                                    isOnlineMode = false
                                    showAddItem = false
                                }
                            },
                            enabled = isPlanFormValid,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent)
                        ) {
                            Text("Add Schedule", color = XFlowBackground, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            } else {
                Button(
                    onClick = { showAddItem = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowAccent)
                ) {
                    Icon(Icons.Default.Add, "Add")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Add Schedule")
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                itemsList.forEach { item ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(XFlowSurface)
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(item.subject, fontWeight = FontWeight.Bold, color = XFlowTextPrimary)
                            Text("${item.startTimeStr} - ${item.endTimeStr}", color = XFlowTextSecondary, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            
            Button(
                onClick = {
                    if (itemsList.isNotEmpty()) {
                        val days = recurrenceDays.toIntOrNull() ?: -1
                        viewModel.saveStudyPlan(days, itemsList)
                        onBack()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                enabled = itemsList.isNotEmpty()
            ) {
                Text("Save Study Plan", color = XFlowBackground, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showAppSelector) {
        ModalBottomSheet(
            onDismissRequest = { showAppSelector = false },
            containerColor = XFlowSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("Select Target App", style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                
                if (appsList.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = XFlowAccent)
                    }
                } else {
                    LazyColumn {
                        items(appsList) { app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedAppPackage = app.packageName
                                        selectedAppName = app.name
                                        showAppSelector = false
                                    }
                                    .padding(vertical = 12.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(app.name, color = XFlowTextPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}
