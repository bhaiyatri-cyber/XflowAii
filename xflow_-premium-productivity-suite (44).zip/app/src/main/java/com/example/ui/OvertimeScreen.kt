package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.OvertimeEntry
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OvertimeScreen(viewModel: XFlowViewModel, onBack: () -> Unit) {
    val entries by viewModel.overtimeEntries.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    val now = System.currentTimeMillis()

    val filtered = when (tab) {
        0 -> entries.filter { isSameDay(it.date, now) }
        1 -> entries.filter { isSameWeek(it.date, now) }
        2 -> entries.filter { isSameMonth(it.date, now) }
        else -> entries
    }
    
    val totalSeconds = filtered.sumOf { it.overtimeSeconds }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🔥 Overtime", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Extra time after planned study was completed on online tasks only.", color = XFlowTextSecondary)
            
            Spacer(Modifier.height(16.dp))

            TabRow(
                selectedTabIndex = tab,
                containerColor = XFlowBackground,
                contentColor = XFlowAccent
            ) {
                listOf("Today", "Week", "Month", "All Time").forEachIndexed { index, title ->
                    Tab(
                        selected = tab == index,
                        onClick = { tab = index },
                        text = { Text(title, color = if (tab == index) XFlowAccent else XFlowTextSecondary) }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Total: ${formatDuration(totalSeconds)}", style = MaterialTheme.typography.titleLarge, color = XFlowTextPrimary)

            Spacer(Modifier.height(16.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered.size) { i ->
                    val item = filtered[i]
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = XFlowSurface)) {
                        Column(Modifier.padding(14.dp)) {
                            Text(item.subject, style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary)
                            Text("Overtime: ${formatDuration(item.overtimeSeconds)}", color = XFlowAccent)
                        }
                    }
                }
            }
        }
    }
}

fun formatDuration(totalSec: Int): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%02dh %02dm %02ds".format(h, m, s) else "%02dm %02ds".format(m, s)
}

fun isSameDay(a: Long, b: Long): Boolean {
    val ca = java.util.Calendar.getInstance().apply { timeInMillis = a }
    val cb = java.util.Calendar.getInstance().apply { timeInMillis = b }
    return ca.get(java.util.Calendar.YEAR) == cb.get(java.util.Calendar.YEAR) &&
            ca.get(java.util.Calendar.DAY_OF_YEAR) == cb.get(java.util.Calendar.DAY_OF_YEAR)
}

fun isSameWeek(a: Long, b: Long): Boolean {
    val ca = java.util.Calendar.getInstance().apply { timeInMillis = a }
    val cb = java.util.Calendar.getInstance().apply { timeInMillis = b }
    return ca.get(java.util.Calendar.YEAR) == cb.get(java.util.Calendar.YEAR) &&
            ca.get(java.util.Calendar.WEEK_OF_YEAR) == cb.get(java.util.Calendar.WEEK_OF_YEAR)
}

fun isSameMonth(a: Long, b: Long): Boolean {
    val ca = java.util.Calendar.getInstance().apply { timeInMillis = a }
    val cb = java.util.Calendar.getInstance().apply { timeInMillis = b }
    return ca.get(java.util.Calendar.YEAR) == cb.get(java.util.Calendar.YEAR) &&
            ca.get(java.util.Calendar.MONTH) == cb.get(java.util.Calendar.MONTH)
}
