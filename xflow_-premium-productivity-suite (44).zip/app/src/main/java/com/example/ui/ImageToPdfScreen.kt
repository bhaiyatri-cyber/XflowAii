package com.example.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Article
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.ui.theme.*
import com.example.utils.PdfGenerator
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageToPdfScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var selectedTabIndex by remember { mutableStateOf(0) }
    var selectedPdfFile by remember { mutableStateOf<File?>(null) }
    
    if (selectedPdfFile != null) {
        PdfViewerScreen(pdfFile = selectedPdfFile!!, onBack = { selectedPdfFile = null })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Image to PDF", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = XFlowBackground,
                contentColor = XFlowAccent
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("Create", color = if (selectedTabIndex == 0) XFlowAccent else XFlowTextSecondary) }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("History", color = if (selectedTabIndex == 1) XFlowAccent else XFlowTextSecondary) }
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    text = { Text("Compress", color = if (selectedTabIndex == 2) XFlowAccent else XFlowTextSecondary) }
                )
            }
            
            when (selectedTabIndex) {
                0 -> CreatePdfTab(onPdfCreated = { selectedTabIndex = 1 })
                1 -> PdfHistoryTab(onPdfSelected = { selectedPdfFile = it })
                2 -> CompressPdfTab(onPdfCompressed = { selectedTabIndex = 1 })
            }
        }
    }
}

@Composable
fun CreatePdfTab(onPdfCreated: () -> Unit = {}) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    var imageUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var isGenerating by remember { mutableStateOf(false) }
    var generatedPdfUri by remember { mutableStateOf<Uri?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            imageUris = uris
            generatedPdfUri = null
            errorMessage = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (imageUris.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("No images selected", color = XFlowTextSecondary)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(imageUris) { uri ->
                    AsyncImage(
                        model = uri,
                        contentDescription = "Selected Image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(XFlowSurfaceVariant)
                    )
                }
            }
        }
        
        if (errorMessage != null) {
            Text(
                text = errorMessage!!,
                color = XFlowError,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }
        
        if (generatedPdfUri != null) {
            Text(
                text = "PDF generated successfully! Check History tab.",
                color = XFlowSupport,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(
            onClick = { launcher.launch("image/*") },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowTextPrimary)
        ) {
            Text("Choose Images")
        }
        
        Spacer(modifier = Modifier.height(12.dp))
        
        Button(
            onClick = {
                if (imageUris.isEmpty()) {
                    errorMessage = "Please choose at least one image."
                    return@Button
                }
                isGenerating = true
                errorMessage = null
                coroutineScope.launch {
                    val pdfFile = PdfGenerator.createPdfFromImages(context, imageUris)
                    isGenerating = false
                    if (pdfFile != null) {
                        generatedPdfUri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            pdfFile
                        )
                        imageUris = emptyList() // Clear selection on success
                        onPdfCreated()
                        Toast.makeText(context, "PDF generated successfully!", Toast.LENGTH_LONG).show()
                    } else {
                        errorMessage = "Failed to generate PDF."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            enabled = !isGenerating && imageUris.isNotEmpty(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = XFlowBackground)
        ) {
            if (isGenerating) {
                CircularProgressIndicator(color = XFlowBackground, modifier = Modifier.size(24.dp))
            } else {
                Text("Create PDF", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfHistoryTab(onPdfSelected: (File) -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var savedPdfs by remember { mutableStateOf(PdfGenerator.getSavedPdfs(context)) }
    
    var showRenameDialog by remember { mutableStateOf<File?>(null) }
    var renameText by remember { mutableStateOf("") }
    
    var fileToAppend by remember { mutableStateOf<File?>(null) }
    var isAppending by remember { mutableStateOf(false) }

    val appendLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty() && fileToAppend != null) {
            isAppending = true
            coroutineScope.launch {
                val success = PdfGenerator.appendImagesToPdf(context, fileToAppend!!, uris)
                isAppending = false
                if (success) {
                    savedPdfs = PdfGenerator.getSavedPdfs(context)
                    Toast.makeText(context, "Pages added successfully", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Failed to add pages", Toast.LENGTH_SHORT).show()
                }
                fileToAppend = null
            }
        }
    }
    
    if (showRenameDialog != null) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = null },
            title = { Text("Rename PDF") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    label = { Text("Name") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val newFile = PdfGenerator.renamePdf(showRenameDialog!!, renameText)
                    if (newFile != null) {
                        savedPdfs = PdfGenerator.getSavedPdfs(context)
                    } else {
                        Toast.makeText(context, "Rename failed", Toast.LENGTH_SHORT).show()
                    }
                    showRenameDialog = null
                }) {
                    Text("Rename")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (isAppending) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = XFlowAccent)
        }
    } else if (savedPdfs.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No PDFs created yet", color = XFlowTextSecondary)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(savedPdfs) { file ->
                var menuExpanded by remember { mutableStateOf(false) }
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = XFlowSurface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPdfSelected(file) }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_agenda), // Fallback icon
                            contentDescription = "PDF",
                            tint = XFlowAccent,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = file.name,
                                color = XFlowTextPrimary,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${file.length() / 1024} KB",
                                color = XFlowTextSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        
                        Box {
                            IconButton(onClick = { menuExpanded = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More options", tint = XFlowTextPrimary)
                            }
                            
                            DropdownMenu(
                                expanded = menuExpanded,
                                onDismissRequest = { menuExpanded = false },
                                modifier = Modifier.background(XFlowSurfaceVariant)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Add Page", color = XFlowTextPrimary) },
                                    onClick = {
                                        menuExpanded = false
                                        fileToAppend = file
                                        appendLauncher.launch("image/*")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Rename", color = XFlowTextPrimary) },
                                    onClick = {
                                        renameText = file.nameWithoutExtension
                                        showRenameDialog = file
                                        menuExpanded = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Download to Phone", color = XFlowTextPrimary) },
                                    onClick = {
                                        menuExpanded = false
                                        coroutineScope.launch {
                                            val success = PdfGenerator.savePdfToDownloads(context, file)
                                            if (success) {
                                                Toast.makeText(context, "Saved to Downloads", Toast.LENGTH_SHORT).show()
                                            } else {
                                                Toast.makeText(context, "Failed to save", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Share", color = XFlowTextPrimary) },
                                    onClick = {
                                        menuExpanded = false
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                        val shareIntent = android.content.Intent().apply {
                                            action = android.content.Intent.ACTION_SEND
                                            putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                            type = "application/pdf"
                                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(android.content.Intent.createChooser(shareIntent, "Share PDF"))
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Delete", color = XFlowError) },
                                    onClick = {
                                        menuExpanded = false
                                        if (file.delete()) {
                                            savedPdfs = PdfGenerator.getSavedPdfs(context)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompressPdfTab(onPdfCompressed: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    var selectedPdfFile by remember { mutableStateOf<File?>(null) }
    var targetSizeKb by remember { mutableStateOf("1024") }
    var isCompressing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    
    val savedPdfs = remember { PdfGenerator.getSavedPdfs(context) }
    var showPdfSelector by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (selectedPdfFile == null) {
            Button(
                onClick = { showPdfSelector = true },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowTextPrimary)
            ) {
                Text("Select PDF to Compress")
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Article, contentDescription = "PDF", tint = XFlowAccent)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(selectedPdfFile!!.name, style = MaterialTheme.typography.bodyLarge, color = XFlowTextPrimary)
                        Text("${selectedPdfFile!!.length() / 1024} KB", style = MaterialTheme.typography.bodyMedium, color = XFlowTextSecondary)
                    }
                    IconButton(onClick = { selectedPdfFile = null }) {
                        Icon(Icons.Filled.Close, contentDescription = "Remove", tint = XFlowTextPrimary)
                    }
                }
            }
            
            OutlinedTextField(
                value = targetSizeKb,
                onValueChange = { targetSizeKb = it },
                label = { Text("Target Size (KB)", color = XFlowTextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XFlowAccent,
                    unfocusedBorderColor = XFlowSurfaceVariant,
                    focusedTextColor = XFlowTextPrimary,
                    unfocusedTextColor = XFlowTextPrimary
                )
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Button(
                onClick = {
                    val target = targetSizeKb.toLongOrNull()
                    if (target == null || target <= 0) {
                        message = "Please enter a valid target size."
                        return@Button
                    }
                    isCompressing = true
                    message = "Compressing... This may take a while."
                    coroutineScope.launch {
                        val result = PdfGenerator.compressPdf(context, selectedPdfFile!!, target)
                        isCompressing = false
                        if (result != null) {
                            Toast.makeText(context, "Compressed successfully to ${result.length() / 1024} KB", Toast.LENGTH_LONG).show()
                            selectedPdfFile = null
                            onPdfCompressed()
                        } else {
                            message = "Failed to compress PDF."
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = !isCompressing,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = XFlowBackground)
            ) {
                if (isCompressing) {
                    CircularProgressIndicator(color = XFlowBackground, modifier = Modifier.size(24.dp))
                } else {
                    Text("Compress PDF", fontWeight = FontWeight.Bold)
                }
            }
        }
        
        if (message != null) {
            Text(
                text = message!!,
                color = if (isCompressing) XFlowSupport else XFlowError,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
    
    if (showPdfSelector) {
        AlertDialog(
            onDismissRequest = { showPdfSelector = false },
            title = { Text("Select PDF") },
            text = {
                if (savedPdfs.isEmpty()) {
                    Text("No saved PDFs found.")
                } else {
                    LazyColumn {
                        items(savedPdfs) { file ->
                            Text(
                                text = file.name,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedPdfFile = file
                                        showPdfSelector = false
                                    }
                                    .padding(16.dp)
                            )
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPdfSelector = false }) {
                    Text("Close")
                }
            }
        )
    }
}
