package com.example

import android.os.Bundle
import com.example.utils.UpdateManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.XFlowApp
import com.example.ui.XFlowViewModel
import com.example.ui.theme.XFlowTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        UpdateManager(this).checkForUpdate()
        setContent {
            val viewModel: XFlowViewModel = viewModel()
            val themeColor by viewModel.themeColor.collectAsState()
            val themeStyle by viewModel.themeStyle.collectAsState()
            XFlowTheme(themeColor = themeColor, themeStyle = themeStyle) {
                XFlowApp(viewModel = viewModel)
            }
        }
    }
}
