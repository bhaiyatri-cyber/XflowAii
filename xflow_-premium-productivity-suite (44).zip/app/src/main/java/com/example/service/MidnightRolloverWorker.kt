package com.example.service

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.ExistingWorkPolicy
import com.example.data.XFlowDatabase
import com.example.data.HistorySession
import com.example.data.Schedule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

class MidnightRolloverWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val prefs = context.getSharedPreferences("xflow_prefs", Context.MODE_PRIVATE)
            val isPremium = prefs.getBoolean("is_premium", false)
            
            if (!isPremium) {
                return@withContext Result.success()
            }

            val db = XFlowDatabase.getDatabase(context)
            val dao = db.dao()
            
            val currentDayMillis = getCurrentDay()
            
            // 1. Move old active study plan cards to history
            val activeSchedules = dao.getActiveSchedulesSync()
            for (schedule in activeSchedules) {
                // If it's a PRO study plan card and it's from a previous day
                if (schedule.isFromStudyPlan && schedule.creationDate < currentDayMillis) {
                    val status = if (schedule.elapsedSeconds > 0) "Partial" else "Missed"
                    val percentage = if (schedule.elapsedSeconds > 0) 50 else 0
                    
                    dao.insertHistory(
                        HistorySession(
                            scheduleId = schedule.id,
                            subject = schedule.subject,
                            mode = "Exact Time",
                            date = schedule.creationDate,
                            timeStudiedSeconds = schedule.elapsedSeconds,
                            completionPercentage = percentage,
                            status = status
                        )
                    )
                    dao.deactivateSchedule(schedule.id)
                }
            }

            // 2. Generate new cards for today
            val plans = dao.getAllStudyPlans()
            for (plan in plans) {
                if (plan.lastGeneratedDay < currentDayMillis) {
                    val creationDay = Calendar.getInstance().apply { 
                        timeInMillis = plan.createdAt
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    
                    val daysSinceCreation = (currentDayMillis - creationDay) / 86400000
                    
                    if (plan.recurrenceDays == -1 || daysSinceCreation <= plan.recurrenceDays) {
                        val items = dao.getStudyPlanItems(plan.id)
                        for (item in items) {
                            val schedule = Schedule(
                                subject = item.subject,
                                description = item.description,
                                isDurationMode = false,
                                durationMinutes = 0,
                                startTimeStr = item.startTimeStr,
                                endTimeStr = item.endTimeStr,
                                isOnlineMode = item.isOnlineMode,
                                selectedAppPackage = item.selectedAppPackage,
                                isActive = true,
                                isFromStudyPlan = true,
                                studyPlanId = plan.id,
                                creationDate = System.currentTimeMillis()
                            )
                            dao.insertSchedule(schedule)
                        }
                        dao.updateStudyPlanGeneratedDay(plan.id, currentDayMillis)
                    }
                }
            }
            
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        } finally {
            scheduleNext(context)
        }
    }
    
    private fun getCurrentDay(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
    
    companion object {
        fun scheduleNext(context: Context) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, 1)
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            
            var delay = cal.timeInMillis - System.currentTimeMillis()
            if (delay <= 0) {
                delay += 86400000 // Add a day if it somehow calculated a past time
            }
            
            val req = OneTimeWorkRequestBuilder<MidnightRolloverWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .build()
                
            WorkManager.getInstance(context).enqueueUniqueWork(
                "MidnightRolloverWorker",
                ExistingWorkPolicy.REPLACE,
                req
            )
        }
    }
}
