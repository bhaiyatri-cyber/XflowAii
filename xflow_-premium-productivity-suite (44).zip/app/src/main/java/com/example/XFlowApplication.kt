package com.example

import android.app.Application
import android.util.Log
import androidx.work.Configuration
import com.example.utils.WorkerUtils

class XFlowApplication : Application(), Configuration.Provider {
    
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(Log.INFO)
            .build()
            
    override fun onCreate() {
        super.onCreate()
        try {
            WorkerUtils.setupSchedulingWorker(this)
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("XFlowApplication", "Failed to setup scheduling worker", e)
        }
    }
}
