import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("        if (lastOpenedVersion > 0 && lastOpenedVersion < currentVersion) {", "        if (lastOpenedVersion < currentVersion) {")
content = content.replace("""        } else if (lastOpenedVersion == 0) {
            // Fresh install, don't show what's new, just set it
            prefs.edit().putInt("last_opened_version", currentVersion).apply()
        }""", "")

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
