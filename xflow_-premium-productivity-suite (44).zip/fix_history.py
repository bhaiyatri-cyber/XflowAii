with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

import re

# find fun AllTimeHistoryScreen
start_idx = content.find("fun AllTimeHistoryScreen")
end_idx = content.find("fun HistoryCard")

part = content[start_idx:end_idx]
print(part)
