with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

old_migration = """                val MIGRATION_8_9 = object : androidx.room.migration.Migration(8, 9) {
                    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        db.execSQL("ALTER TABLE ai_chats ADD COLUMN sessionId TEXT NOT NULL DEFAULT 'default'")
                        db.execSQL("CREATE TABLE IF NOT EXISTS `offline_chats` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `role` TEXT NOT NULL, `message` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, `sessionId` TEXT NOT NULL DEFAULT 'default')")
                    }
                }"""

new_migration = """                val MIGRATION_8_9 = object : androidx.room.migration.Migration(8, 9) {
                    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        try {
                            db.execSQL("ALTER TABLE ai_chats ADD COLUMN sessionId TEXT NOT NULL DEFAULT 'default'")
                        } catch (e: Exception) {}
                        
                        db.execSQL("CREATE TABLE IF NOT EXISTS `offline_chats` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `role` TEXT NOT NULL, `message` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, `sessionId` TEXT NOT NULL DEFAULT 'default')")
                        
                        try {
                            db.execSQL("ALTER TABLE offline_chats ADD COLUMN sessionId TEXT NOT NULL DEFAULT 'default'")
                        } catch (e: Exception) {}
                    }
                }"""

content = content.replace(old_migration, new_migration)
with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)

