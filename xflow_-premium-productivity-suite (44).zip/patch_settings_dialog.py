import re

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

# 1. Lift `var showUpdateScreen by remember { mutableStateOf(false) }` to top of SettingsScreen
if "var showUpdateScreen by remember { mutableStateOf(false) }" not in content[:1000]:
    content = content.replace(
        "    var showToolOptions by remember { mutableStateOf(false) }",
        "    var showToolOptions by remember { mutableStateOf(false) }\n    var showUpdateScreen by remember { mutableStateOf(false) }"
    )

# 2. Remove the local declaration and Dialog inside ModalBottomSheet
old_sheet = """                    var showUpdateScreen by remember { mutableStateOf(false) }
                    
                    SettingsItem(icon = Icons.Default.Update, title = "App Update", subtitle = timeStr, onClick = { showUpdateScreen = true })
                    
                    if (showUpdateScreen) {
                        Dialog(
                            onDismissRequest = { showUpdateScreen = false },
                            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
                        ) {
                            WhatsNewScreen(onDismiss = { showUpdateScreen = false })
                        }
                    }"""

new_sheet = """                    SettingsItem(icon = Icons.Default.Update, title = "App Update", subtitle = timeStr, onClick = { showUpdateScreen = true })"""

content = content.replace(old_sheet, new_sheet)

# 3. Add WhatsNewScreen rendering at the end of SettingsScreen
if "WhatsNewScreen(onDismiss = { showUpdateScreen = false })" not in content[len(content)-500:]:
    content = content.replace(
        "    }\n    \n}",
        "    }\n    if (showUpdateScreen) {\n        WhatsNewScreen(onDismiss = { showUpdateScreen = false })\n    }\n}"
    )

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)

