import re

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'r') as f:
    content = f.read()

# Add SettingsSection composable at the bottom
if "fun ThemeSettingsSection" not in content:
    content += """
@Composable
fun ThemeSettingsSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.padding(vertical = 8.dp).fillMaxWidth()) {
        Text(
            text = title,
            color = XFlowTextSecondary,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp, start = 8.dp)
        )
        androidx.compose.material3.Card(
            modifier = Modifier.fillMaxWidth(),
            colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = XFlowSurface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                content()
            }
        }
    }
}
"""

# Let's completely rewrite the content of ThemeSettingsScreen to make it look clean
# Instead of complex regex, I'll just write a script that replaces everything inside the Scaffold body.

