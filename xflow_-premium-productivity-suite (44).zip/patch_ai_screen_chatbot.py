import re

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()

# Add Chatbot to drawer
drawer_mock = """                NavigationDrawerItem(
                    label = { Text("AI Mock Tests (Pro)", color = XFlowTextPrimary) },"""

drawer_chatbot = """                NavigationDrawerItem(
                    label = { Text("Chatbot", color = XFlowTextPrimary) },
                    selected = selectedItem == "Chatbot",
                    onClick = {
                        selectedItem = "Chatbot"
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = XFlowSurfaceVariant,
                        unselectedContainerColor = Color.Transparent
                    )
                )
                NavigationDrawerItem(
                    label = { Text("AI Mock Tests (Pro)", color = XFlowTextPrimary) },"""

content = content.replace(drawer_mock, drawer_chatbot)

# Add ChatbotContent to Scaffold
scaffold_body = """            Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
                if (selectedItem == "Chat") {
                    ChatContent(viewModel = viewModel)
                } else {
                    MockTestsContent(viewModel = viewModel, navController = navController)
                }
            }"""

scaffold_body_new = """            Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
                if (selectedItem == "Chat") {
                    ChatContent(viewModel = viewModel)
                } else if (selectedItem == "Chatbot") {
                    ChatbotContent()
                } else {
                    MockTestsContent(viewModel = viewModel, navController = navController)
                }
            }"""

content = content.replace(scaffold_body, scaffold_body_new)

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)
print("AiScreen patched")
