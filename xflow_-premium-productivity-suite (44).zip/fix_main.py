import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

new_main = """            val viewModel: XFlowViewModel = viewModel()
            val themeColor by viewModel.themeColor.collectAsState()
            val themeStyle by viewModel.themeStyle.collectAsState()
            XFlowTheme(themeColor = themeColor, themeStyle = themeStyle) {"""

content = content.replace('            val viewModel: XFlowViewModel = viewModel()\n            val themeColor by viewModel.themeColor.collectAsState()\n            XFlowTheme(themeColor = themeColor) {', new_main)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
