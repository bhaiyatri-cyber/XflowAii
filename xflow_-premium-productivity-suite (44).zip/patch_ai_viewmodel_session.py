import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

# Update AiViewModel to use a currentSessionId
content = content.replace("val aiChats = db.dao().getAllAiChats()", """val currentSessionId = MutableStateFlow("default")
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val aiChats = currentSessionId.flatMapLatest { sessionId ->
        db.dao().getAllAiChats(sessionId)
    }""")

content = content.replace("import kotlinx.coroutines.flow.stateIn", "import kotlinx.coroutines.flow.stateIn\nimport kotlinx.coroutines.flow.flatMapLatest")

content = content.replace("db.dao().deleteAllAiChats()", "db.dao().deleteAllAiChats(currentSessionId.value)")
content = content.replace("insertAiChat(AiChat(role = \"user\", message = message, timestamp = System.currentTimeMillis()))", "insertAiChat(AiChat(role = \"user\", message = message, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))")
content = content.replace("insertAiChat(AiChat(role = \"model\", message = \"[MOCK_TEST_CARD:$insertedId:$title]\", timestamp = System.currentTimeMillis()))", "insertAiChat(AiChat(role = \"model\", message = \"[MOCK_TEST_CARD:$insertedId:$title]\", timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))")
content = content.replace("insertAiChat(AiChat(role = \"model\", message = \"🎉 Schedule '$schedName' created successfully! You can view it on your Home screen.\", timestamp = System.currentTimeMillis()))", "insertAiChat(AiChat(role = \"model\", message = \"🎉 Schedule '$schedName' created successfully! You can view it on your Home screen.\", timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))")
content = content.replace("insertAiChat(AiChat(role = \"model\", message = responseText, timestamp = System.currentTimeMillis()))", "insertAiChat(AiChat(role = \"model\", message = responseText, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))")
content = content.replace("insertAiChat(AiChat(role = \"model\", message = msg, timestamp = System.currentTimeMillis()))", "insertAiChat(AiChat(role = \"model\", message = msg, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))")

# Add a function to change session
content = content.replace("fun clearChat() {", """
    val allSessions = db.dao().getAiChatSessions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allMockTests = db.dao().getAllMockTests().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun loadSession(sessionId: String) {
        currentSessionId.value = sessionId
    }
    
    fun createNewSession() {
        currentSessionId.value = "session_" + System.currentTimeMillis()
    }
    
    fun clearChat() {""")

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
