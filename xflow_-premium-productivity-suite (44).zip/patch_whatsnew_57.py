with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

# Replace the icon with the image
content = content.replace('import androidx.compose.material.icons.filled.WorkspacePremium\n', 'import androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.draw.clip\n')

content = content.replace("""            Icon(
                imageVector = Icons.Default.WorkspacePremium,
                contentDescription = null,
                tint = XFlowAccent,
                modifier = Modifier.size(120.dp)
            )""", """            Image(
                painter = painterResource(id = R.drawable.app_logo),
                contentDescription = "New Logo",
                modifier = Modifier.size(120.dp).clip(RoundedCornerShape(24.dp))
            )""")

old_changes = """                    val changes = listOf(
                        "Reverted Original Logo: Brought back the classic XFlow vector icon design based on user feedback.",
                        "Performance Improvements: Restored the original adaptive icon layout to fix random crashes and bugs.",
                        "Bug Fixes: Fixed screen-skipping and UI bugs caused by the previous update."
                    )"""

new_changes = """                    val changes = listOf(
                        "Premium New Logo: Rebranded the entire app with a fresh, futuristic abstract XFlow monogram.",
                        "Security Enhancements: Advanced security protocols added to protect your flow data.",
                        "Bug Fixes: General system stability improvements and UI refinements."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)
