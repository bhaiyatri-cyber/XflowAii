import re

with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

# Add imports
imports_to_add = """import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
"""
if "import androidx.compose.ui.window.Dialog" not in content:
    content = content.replace("import androidx.compose.ui.unit.dp", "import androidx.compose.ui.unit.dp\n" + imports_to_add)

# Add isPremium and context state
state_code = """    val schedules by viewModel.activeSchedules.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showEditDialog by remember { mutableStateOf(false) }
    var showPremiumDialog by remember { mutableStateOf(false) }
    
    val schedule = schedules.find { it.id == id }"""

content = content.replace("    val schedules by viewModel.activeSchedules.collectAsStateWithLifecycle()\n    val schedule = schedules.find { it.id == id }", state_code)

# Add Edit Button
edit_btn_code = """                    if (status == StudyStatus.COMPLETED) {
                        Spacer(modifier = Modifier.height(16.dp))
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn(tween(300)) + scaleIn(tween(350))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(XFlowSupport.copy(alpha = 0.1f))
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "🎉 Session Successfully Completed!",
                                    color = XFlowSupport,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    
                    if (status == StudyStatus.UPCOMING && !schedule.hasBeenEdited) {
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = { 
                                if (isPremium) {
                                    showEditDialog = true
                                } else {
                                    showPremiumDialog = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Edit Schedule (One-time, PRO)")
                        }
                    }
                }
            }
        }
        
        if (showEditDialog && schedule != null) {
            EditScheduleDialog(
                schedule = schedule,
                onDismiss = { showEditDialog = false },
                onSave = { updatedSchedule ->
                    viewModel.updateSchedule(updatedSchedule.copy(hasBeenEdited = true))
                    showEditDialog = false
                    Toast.makeText(context, "Schedule updated successfully!", Toast.LENGTH_SHORT).show()
                }
            )
        }
        
        if (showPremiumDialog) {
            PremiumDialog(
                onDismiss = { showPremiumDialog = false },
                onActivate = { code -> 
                    val success = viewModel.activatePremium(code)
                    if (success) {
                        showPremiumDialog = false
                        Toast.makeText(context, "PRO Activated!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Invalid PRO code.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }"""

content = content.replace("""                    if (status == StudyStatus.COMPLETED) {
                        Spacer(modifier = Modifier.height(16.dp))
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn(tween(300)) + scaleIn(tween(350))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(XFlowSupport.copy(alpha = 0.1f))
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "🎉 Session Successfully Completed!",
                                    color = XFlowSupport,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }""", edit_btn_code)


with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
