with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace(
"""                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    XFlowApp(viewModel = viewModel)
                }""",
"""                XFlowApp(viewModel = viewModel)"""
)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
