with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

old_card = """    val isImageStyle = cardStyle == "Image"
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showSheet = true },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isImageStyle) androidx.compose.ui.graphics.Color.Transparent else XFlowSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, XFlowSurfaceVariant)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.2f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {"""

new_card = """    val isImageStyle = cardStyle == "Image"
    val isGradientStyle = cardStyle == "Gradient"
    val isOutlinedStyle = cardStyle == "Outlined"
    val isSoftStyle = cardStyle == "Soft"
    
    val finalContainerColor = when {
        isImageStyle || isGradientStyle -> androidx.compose.ui.graphics.Color.Transparent
        isSoftStyle -> XFlowSurfaceVariant.copy(alpha = 0.3f)
        isOutlinedStyle -> androidx.compose.ui.graphics.Color.Transparent
        else -> XFlowSurface
    }

    val defaultElev = when {
        isOutlinedStyle || isSoftStyle -> 0.dp
        else -> 2.dp
    }
    
    val strokeWidth = when {
        isSoftStyle -> 0.dp
        else -> 1.dp
    }

    val finalBorderColor = if (isOutlinedStyle) XFlowTextSecondary.copy(alpha=0.3f) else XFlowSurfaceVariant

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showSheet = true },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = finalContainerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = defaultElev),
        border = androidx.compose.foundation.BorderStroke(strokeWidth, finalBorderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.2f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else if (isGradientStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.1f),
                                    XFlowSurface,
                                    XFlowAccent.copy(alpha = 0.05f)
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {"""

content = content.replace(old_card, new_card)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
