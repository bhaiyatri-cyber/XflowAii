with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace('versionCode = 65', 'versionCode = 66').replace('versionName = "65.0"', 'versionName = "66.0"')

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)

