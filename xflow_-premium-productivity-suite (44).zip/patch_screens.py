import re
import os

# 1. SplashScreen.kt
with open('app/src/main/java/com/example/ui/SplashScreen.kt', 'r') as f:
    content = f.read()
content = content.replace('import androidx.compose.material.icons.filled.AvTimer\n', 'import androidx.compose.ui.res.painterResource\nimport androidx.compose.foundation.Image\nimport com.example.R\nimport androidx.compose.foundation.shape.RoundedCornerShape\nimport androidx.compose.ui.draw.clip\n')
content = content.replace("""            Icon(
                imageVector = Icons.Default.AvTimer,
                contentDescription = "XFlow Logo",
                tint = XFlowAccent,
                modifier = Modifier.size(80.dp)
            )""", """            Image(
                painter = painterResource(id = R.drawable.app_logo),
                contentDescription = "XFlow Logo",
                modifier = Modifier.size(120.dp).clip(RoundedCornerShape(24.dp))
            )""")
with open('app/src/main/java/com/example/ui/SplashScreen.kt', 'w') as f:
    f.write(content)

# 2. AboutScreen.kt
with open('app/src/main/java/com/example/ui/AboutScreen.kt', 'r') as f:
    content = f.read()
content = content.replace('import androidx.compose.ui.unit.dp\n', 'import androidx.compose.ui.unit.dp\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.ui.Alignment\nimport androidx.compose.foundation.shape.RoundedCornerShape\nimport androidx.compose.ui.draw.clip\n')
content = content.replace("""        Text("ABOUT XFLOW", style = MaterialTheme.typography.titleMedium, color = XFlowAccent, fontWeight = FontWeight.Bold)""", """        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.app_logo),
                contentDescription = "Logo",
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text("ABOUT XFLOW", style = MaterialTheme.typography.titleMedium, color = XFlowAccent, fontWeight = FontWeight.Bold)
        }""")
with open('app/src/main/java/com/example/ui/AboutScreen.kt', 'w') as f:
    f.write(content)

# 3. SettingsScreen.kt
with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()
content = content.replace('import androidx.compose.foundation.shape.RoundedCornerShape\n', 'import androidx.compose.foundation.shape.RoundedCornerShape\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.ui.draw.clip\n')
content = content.replace("""                Icon(
                    imageVector = Icons.Default.AvTimer,
                    contentDescription = "XFlow Logo",
                    tint = XFlowAccent,
                    modifier = Modifier.size(64.dp)
                )""", """                Image(
                    painter = painterResource(id = R.drawable.app_logo),
                    contentDescription = "XFlow Logo",
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
                )""")
content = content.replace("""                    Icon(Icons.Default.AvTimer, contentDescription = "Logo", tint = XFlowAccent, modifier = Modifier.size(32.dp))""", """                    Image(painter = painterResource(id = R.drawable.app_logo), contentDescription = "Logo", modifier = Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)))""")
with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)

# 4. PremiumDialog.kt
with open('app/src/main/java/com/example/ui/PremiumDialog.kt', 'r') as f:
    content = f.read()
content = content.replace('import androidx.compose.ui.graphics.Color\n', 'import androidx.compose.ui.graphics.Color\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.foundation.shape.RoundedCornerShape\nimport androidx.compose.ui.draw.clip\n')
content = content.replace("""                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = "Premium",
                    tint = Color(0xFFFFD700),
                    modifier = Modifier.size(64.dp)
                )""", """                Image(
                    painter = painterResource(id = R.drawable.app_logo),
                    contentDescription = "Premium",
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
                )""")
with open('app/src/main/java/com/example/ui/PremiumDialog.kt', 'w') as f:
    f.write(content)

# 6. HomeScreen.kt
with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()
content = content.replace('import androidx.compose.ui.text.font.FontWeight\n', 'import androidx.compose.ui.text.font.FontWeight\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.ui.draw.clip\n')
content = content.replace("""    Text(
        text = "$icon ${SimpleDateFormat(format, Locale.getDefault()).format(now)}",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = XFlowAccent
    )""", """    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.app_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "$icon ${SimpleDateFormat(format, Locale.getDefault()).format(now)}",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = XFlowAccent
        )
    }""")
with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)

# 7. Notifications
files = [
    'app/src/main/java/com/example/service/TrackingService.kt',
    'app/src/main/java/com/example/service/SchedulingWorker.kt',
    'app/src/main/java/com/example/service/DailySummaryWorker.kt',
    'app/src/main/java/com/example/utils/UpdateManager.kt'
]
for file_path in files:
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            content = f.read()
        content = content.replace('import android.app.NotificationManager\n', 'import android.app.NotificationManager\nimport com.example.R\nimport android.graphics.BitmapFactory\n')
        content = content.replace('import android.content.Context\n', 'import android.content.Context\nimport com.example.R\nimport android.graphics.BitmapFactory\n')
        content = content.replace('.setSmallIcon(R.drawable.ic_notification)', '.setSmallIcon(R.drawable.ic_notification)\n            .setLargeIcon(BitmapFactory.decodeResource(resources, R.drawable.app_logo))')
        content = content.replace('.setSmallIcon(R.drawable.ic_notification)', '.setSmallIcon(R.drawable.ic_notification)\n            .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.app_logo))')
        with open(file_path, 'w') as f:
            f.write(content)

