import re

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

imports = """import com.example.data.HistorySession
import com.example.data.UpdateInfo
import com.example.utils.UpdateManager"""
content = content.replace("import com.example.data.HistorySession", imports)

new_state = """    private val _cardStyle = kotlinx.coroutines.flow.MutableStateFlow(prefs.getString("card_style", "Solid") ?: "Solid")
    val cardStyle: StateFlow<String> = _cardStyle

    private val updateManager = UpdateManager(application)
    private val _updateInfo = kotlinx.coroutines.flow.MutableStateFlow<UpdateInfo?>(null)
    val updateInfo: StateFlow<UpdateInfo?> = _updateInfo
    private val _updateDismissedForSession = kotlinx.coroutines.flow.MutableStateFlow(false)
    val updateDismissedForSession: StateFlow<Boolean> = _updateDismissedForSession

    init {
        viewModelScope.launch {
            _updateInfo.value = updateManager.checkUpdateAvailable()
        }
    }

    fun dismissUpdatePrompt() {
        _updateDismissedForSession.value = true
    }

    fun startUpdateDownload() {
        _updateInfo.value?.let { info ->
            updateManager.startDownload(info.downloadUrl, info.versionCode)
            dismissUpdatePrompt()
        }
    }
    
    fun checkForUpdatesManual() {
        viewModelScope.launch {
            _updateInfo.value = updateManager.checkUpdateAvailable()
        }
    }"""
    
content = content.replace("""    private val _cardStyle = kotlinx.coroutines.flow.MutableStateFlow(prefs.getString("card_style", "Solid") ?: "Solid")
    val cardStyle: StateFlow<String> = _cardStyle""", new_state)

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(content)
