with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

# Add notification imports
content = content.replace(
    'import com.example.BuildConfig',
    'import com.example.BuildConfig\nimport android.app.NotificationChannel\nimport android.app.NotificationManager\nimport android.content.Context\nimport android.os.Build\nimport androidx.core.app.NotificationCompat\nimport com.example.R'
)

# Add sendNotification function and call it
noti_function = """    private fun sendMockTestReadyNotification(title: String) {
        val context = getApplication<Application>()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "AiMockTestChannel"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "AI Mock Tests",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for AI generated mock tests"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // We'll use a default icon here
            .setContentTitle("Mock Test Ready!")
            .setContentText("Your test '$title' has been generated and is ready to attempt.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }
"""

content = content.replace('class AiViewModel(application: Application) : AndroidViewModel(application) {', 'class AiViewModel(application: Application) : AndroidViewModel(application) {\n' + noti_function)

# Trigger notification
trigger_old = """                        // Insert mock test
                        db.dao().insertMockTest(MockTest(
                            title = "Generated Mock Test", // Parse title from JSON in real app
                            testDataJson = responseText,
                            date = System.currentTimeMillis()
                        ))
                        db.dao().insertAiChat(AiChat(role = "model", message = "I have generated a new Mock Test for you. You can find it in the AI Mock Tests section.", timestamp = System.currentTimeMillis()))
"""
trigger_new = """                        // Insert mock test
                        val testTitle = org.json.JSONObject(responseText).optString("title", "Generated Mock Test")
                        db.dao().insertMockTest(MockTest(
                            title = testTitle,
                            testDataJson = responseText,
                            date = System.currentTimeMillis()
                        ))
                        db.dao().insertAiChat(AiChat(role = "model", message = "I have generated a new Mock Test for you. You can find it in the AI Mock Tests section.", timestamp = System.currentTimeMillis()))
                        sendMockTestReadyNotification(testTitle)
"""
content = content.replace(trigger_old, trigger_new)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
