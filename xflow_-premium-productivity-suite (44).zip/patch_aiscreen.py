with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'fun AiScreen(navController: NavController, viewModel: AiViewModel = viewModel()) {',
    'fun AiScreen(navController: NavController, viewModel: AiViewModel = viewModel(), xFlowViewModel: XFlowViewModel) {'
)

# update NavigationDrawerItem
old_mock_drawer = """                NavigationDrawerItem(
                    label = { Text("AI Mock Tests (Pro)", color = XFlowTextPrimary) },
                    selected = selectedItem == "MockTests",
                    onClick = {
                        selectedItem = "MockTests"
                        scope.launch { drawerState.close() }
                    },"""
new_mock_drawer = """                val isPremium by xFlowViewModel.isPremium.collectAsStateWithLifecycle()
                var showPremiumDialog by remember { mutableStateOf(false) }
                
                if (showPremiumDialog) {
                    AlertDialog(
                        onDismissRequest = { showPremiumDialog = false },
                        title = { Text("Premium Feature", color = XFlowTextPrimary) },
                        text = { Text("Mock Tests are only available for Premium users.", color = XFlowTextSecondary) },
                        confirmButton = { TextButton(onClick = { showPremiumDialog = false }) { Text("OK", color = XFlowAccent) } },
                        containerColor = XFlowSurface
                    )
                }
                
                NavigationDrawerItem(
                    label = { Text("AI Mock Tests (Pro)", color = XFlowTextPrimary) },
                    selected = selectedItem == "MockTests",
                    onClick = {
                        if (isPremium) {
                            selectedItem = "MockTests"
                        } else {
                            showPremiumDialog = true
                        }
                        scope.launch { drawerState.close() }
                    },"""
content = content.replace(old_mock_drawer, new_mock_drawer)

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)
