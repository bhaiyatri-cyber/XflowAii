import re

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

old_logic = """                    } else if (latestVersion > currentVersion && latestVersion <= lastDownloadedVersion) {
                        Log.d(TAG, "Already downloaded version $latestVersion but not installed. Skipping automatic download.")
                        // We could show the install notification again here if the file exists
                        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                        if (dir != null && dir.exists()) {
                            val file = java.io.File(dir, "update.apk")
                            if (file.exists()) {
                                // The file is already here, just show the notification
                                showInstallNotification()
                            }
                        }
                    }"""

new_logic = """                    } else if (latestVersion > currentVersion && latestVersion <= lastDownloadedVersion) {
                        Log.d(TAG, "Already downloaded version $latestVersion but not installed. Skipping automatic download.")
                        // We could show the install notification again here if the file exists
                        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                        if (dir != null && dir.exists()) {
                            val file = java.io.File(dir, "update.apk")
                            if (file.exists()) {
                                // The file is already here, just show the notification
                                showInstallNotification()
                            }
                        }
                    } else {
                        Log.d(TAG, "App is up to date. Cleaning up any old downloaded APKs.")
                        cleanupOldUpdates()
                    }"""

content = content.replace(old_logic, new_logic)

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)
