import re

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

# We need to find the `AllTimeHistoryScreen` function.
# It starts with `@OptIn(ExperimentalMaterial3Api::class)\n@Composable\nfun AllTimeHistoryScreen` or similar.

def replace_all_time(match):
    body = match.group(0)
    # The body has a Column containing Row, Text, Row, Text, if else LazyColumn
    # Let's replace the top Column with just val declarations and then LazyColumn
    
    new_body = body.replace(
        """    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {""",
        """    ) { padding ->
        val groupedHistory = history.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }.toSortedMap(compareByDescending { 
            try { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).parse(it)?.time ?: 0L } catch(e: Exception) { 0L }
        })
        val groupedOvertime = overtimeEntries.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }
        var expandedDates by remember { mutableStateOf(setOf(SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date()))) }
        
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))"""
    )
    
    new_body = new_body.replace(
        """            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {""",
        """            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {"""
    )
    
    # After "Spacer(modifier = Modifier.height(16.dp))" it has "if (history.isEmpty())"
    new_body = new_body.replace(
        """            if (history.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No history yet.", color = XFlowTextSecondary)
                }
            } else {
                val groupedHistory = history.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }.toSortedMap(compareByDescending { 
                    try { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).parse(it)?.time ?: 0L } catch(e: Exception) { 0L }
                })
                val groupedOvertime = overtimeEntries.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }
                var expandedDates by remember { mutableStateOf(setOf(SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date()))) }
                
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {""",
        """            } // end item
            
            if (history.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No history yet.", color = XFlowTextSecondary)
                    }
                }
            } else {"""
    )
    
    # We also need to remove one closing brace for the `else` block if we removed the inner LazyColumn
    # Actually, the original inner LazyColumn had a block `) {` which we matched and removed.
    # The `groupedHistory.forEach` is now directly under our new top-level `LazyColumn`.
    
    return new_body

content = re.sub(r'fun AllTimeHistoryScreen.*?(?=fun OvertimeSummaryCard)', replace_all_time, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)

