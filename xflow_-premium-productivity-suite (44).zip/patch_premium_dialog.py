import re

with open('app/src/main/java/com/example/ui/PremiumDialog.kt', 'r') as f:
    content = f.read()

content = content.replace('import androidx.compose.ui.graphics.Color', 'import androidx.compose.ui.graphics.Color\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R')

old_icon = """                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = "Premium",
                    tint = Color(0xFFFFD700),
                    modifier = Modifier.size(64.dp)
                )"""

new_icon = """                Image(
                    painter = painterResource(id = R.drawable.app_logo),
                    contentDescription = "Premium",
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
                )"""

content = content.replace(old_icon, new_icon)

with open('app/src/main/java/com/example/ui/PremiumDialog.kt', 'w') as f:
    f.write(content)
