import re

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

# Let's check where the Chatbot item is
print("Chatbot item in Settings:", 'onNavigateToChatbot' in content)
