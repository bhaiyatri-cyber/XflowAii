with open('app/build.gradle.kts', 'r') as f:
    content = f.read()
content = content.replace('versionCode = 60', 'versionCode = 65').replace('versionName = "60.0"', 'versionName = "65.0"')
with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
