with open('app/src/main/java/com/example/service/SchedulingWorker.kt', 'r') as f:
    content = f.read()

# We need to remove the rollover logic from SchedulingWorker.kt to prevent conflicts
# or just let it stay as it's doing the same thing. 
# Actually, the user specifically mentioned it should happen at midnight.
