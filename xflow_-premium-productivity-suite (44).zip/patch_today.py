import re

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

old_start = """    val history by viewModel.history.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()"""

new_start = """    val history by viewModel.history.collectAsStateWithLifecycle()
    val overtimeEntries by viewModel.overtimeEntries.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()"""

content = content.replace(old_start, new_start)

old_body = """            if (todayHistory.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No sessions completed today.", color = XFlowTextSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(todayHistory) { session ->
                        HistoryCard(session, cardStyle = cardStyle)
                    }
                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }"""

new_body = """            val todayOvertime = overtimeEntries.filter { it.date > todayStart }
            if (todayHistory.isEmpty() && todayOvertime.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No sessions completed today.", color = XFlowTextSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (todayOvertime.isNotEmpty()) {
                        item {
                            OvertimeSummaryCard(
                                dateTitle = "Today",
                                totalSeconds = todayOvertime.sumOf { it.overtimeSeconds },
                                entries = todayOvertime,
                                cardStyle = cardStyle
                            )
                        }
                    }
                    items(todayHistory) { session ->
                        HistoryCard(session, cardStyle = cardStyle)
                    }
                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }"""

content = content.replace(old_body, new_body)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
