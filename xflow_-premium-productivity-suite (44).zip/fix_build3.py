with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace('    } \n    else {\n        val newContent = propContent.replace(Regex("GEMINI_API_KEY=.*"), "GEMINI_API_KEY=$ciGeminiKey")\n        localProps.writeText(newContent)\n    }\n}', '    }\n}')

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
