import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Add imports
imports_to_add = """
import android.text.format.DateFormat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
"""

# add imports after package
content = content.replace(
    'package com.example.ui',
    'package com.example.ui\n' + imports_to_add
)

# replace Text("XFlow"...)
content = content.replace(
    'title = { Text("XFlow", color = XFlowAccent, fontWeight = FontWeight.Bold) },',
    'title = { DynamicHeader() },'
)

# append DynamicHeader
dynamic_header = """
@Composable
fun DynamicHeader() {
    var now by remember { mutableStateOf(Date()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000L)
        }
    }

    val calendar = Calendar.getInstance().apply { time = now }
    val hour = calendar.get(Calendar.HOUR_OF_DAY)

    val icon = when (hour) {
        in 5..11 -> "☀️"
        in 12..16 -> "🌤️"
        in 17..19 -> "🌇"
        else -> "🌙"
    }

    val format = if (DateFormat.is24HourFormat(LocalContext.current)) "HH:mm" else "hh:mm a"

    Text(
        text = "$icon ${SimpleDateFormat(format, Locale.getDefault()).format(now)}",
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold,
        color = XFlowAccent
    )
}
"""

content += "\n" + dynamic_header

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
