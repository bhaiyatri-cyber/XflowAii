#!/bin/bash
sed -i '/super.onCreate(savedInstanceState)/a \        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT' app/src/main/java/com/example/MainActivity.kt
