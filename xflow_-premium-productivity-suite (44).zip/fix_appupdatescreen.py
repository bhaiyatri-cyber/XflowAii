import re

with open('app/src/main/java/com/example/ui/AppUpdateScreen.kt', 'r') as f:
    content = f.read()

new_content = """package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.UpdateInfo
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppUpdateScreen(
    updateInfo: UpdateInfo?,
    onCheckForUpdates: () -> Unit,
    onUpdateNow: () -> Unit,
    onBack: () -> Unit, 
    onShowReleaseNotes: () -> Unit
) {
    var isChecking by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("App Update", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.app_logo),
                contentDescription = "App Logo",
                modifier = Modifier
                    .size(120.dp)
                    .clip(RoundedCornerShape(24.dp))
            )
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "XFlow Premium",
                style = MaterialTheme.typography.headlineMedium,
                color = XFlowTextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Version ${com.example.BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.bodyLarge,
                color = XFlowTextSecondary
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            if (isChecking) {
                CircularProgressIndicator(color = XFlowAccent)
                Spacer(modifier = Modifier.height(16.dp))
                Text("Checking for updates...", color = XFlowTextSecondary)
                
                LaunchedEffect(Unit) {
                    onCheckForUpdates()
                    delay(2000) // minimum delay for visual feedback
                    isChecking = false
                }
            } else if (updateInfo?.isAvailable == true) {
                Text(
                    text = "New Update Available: ${updateInfo.versionName}",
                    style = MaterialTheme.typography.titleLarge,
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onUpdateNow,
                    colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text("Update Now", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            } else {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Up to date",
                    tint = Color(0xFF4CAF50),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "You're on the latest version!",
                    style = MaterialTheme.typography.titleLarge,
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "XFlow is up to date and running smoothly.",
                    color = XFlowTextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { isChecking = true },
                    colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text("Check for Updates", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            OutlinedButton(
                onClick = onShowReleaseNotes,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = XFlowAccent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("View Release Notes")
            }
        }
    }
}
"""
with open('app/src/main/java/com/example/ui/AppUpdateScreen.kt', 'w') as f:
    f.write(new_content)
