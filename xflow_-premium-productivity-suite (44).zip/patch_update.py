import re

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

# Fix 1: Check if download was successful
old_receiver = """    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == DownloadManager.ACTION_DOWNLOAD_COMPLETE) {
                val downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                if (downloadId != -1L) {
                    showInstallNotification()
                }
            }
        }
    }"""

new_receiver = """    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == DownloadManager.ACTION_DOWNLOAD_COMPLETE) {
                val downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                if (downloadId != -1L && context != null) {
                    try {
                        val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                        val query = DownloadManager.Query().setFilterById(downloadId)
                        val cursor = downloadManager.query(query)
                        if (cursor != null && cursor.moveToFirst()) {
                            val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                            if (statusIndex >= 0) {
                                val status = cursor.getInt(statusIndex)
                                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                                    showInstallNotification()
                                } else {
                                    Log.e(TAG, "Download failed with status: $status")
                                }
                            }
                            cursor.close()
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error checking download status", e)
                    }
                }
            }
        }
    }"""
content = content.replace(old_receiver, new_receiver)

# Fix 2: Catch SecurityException on notification and don't force start activity
old_notify = """        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
        
        // Also try to start it automatically if app is in foreground
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start install intent", e)
        }"""

new_notify = """        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        try {
            notificationManager.notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
            Log.e(TAG, "Missing POST_NOTIFICATIONS permission", e)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to show notification", e)
        }
        
        // Also try to start it automatically if app is in foreground
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start install intent. User can tap notification instead.", e)
        }"""
content = content.replace(old_notify, new_notify)

# Also, unregistering receiver to prevent leaks? We can't easily without a lifecycle hook, but it's okay for now.

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)
print("Patched UpdateManager")
