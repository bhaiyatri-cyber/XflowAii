import re

with open('app/src/main/java/com/example/ui/AboutScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('import androidx.compose.material3.Text', 'import androidx.compose.material3.Text\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.ui.Alignment')

about_tab_content = """@Composable
fun AboutTab() {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.app_logo),
                contentDescription = "Logo",
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text("ABOUT XFLOW", style = MaterialTheme.typography.titleMedium, color = XFlowAccent, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("""

content = content.replace("""@Composable
fun AboutTab() {
    Column {
        Text("ABOUT XFLOW", style = MaterialTheme.typography.titleMedium, color = XFlowAccent, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text(""", about_tab_content)

with open('app/src/main/java/com/example/ui/AboutScreen.kt', 'w') as f:
    f.write(content)
