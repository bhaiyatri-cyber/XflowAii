import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

func = """    fun clearChat() {
        viewModelScope.launch {
            db.dao().deleteAllAiChats()
        }
    }
"""

content = content.replace('    fun sendMessage', func + '\n    fun sendMessage')

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
