import re

with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

# Fix 1: if (!shouldTrack) { ... db.dao().updateScheduleProgress(...) }
content = content.replace(
    "db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)",
    "if (schedule.isRunning) db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)"
)

# Fix 2: inside `else` for app exit or offline screen on
content = content.replace(
    "if (schedule.elapsedSeconds >= targetTime)",
    "if (schedule.elapsedSeconds >= targetTime && schedule.isRunning)" # Wait, history insertion needs to happen when it transitions to done! Wait, no, it's better to just leave it if it works, or check if we can prevent double insertion.
)

# Wait, `if (schedule.elapsedSeconds >= targetTime)` is inside a block where the app is NOT active. 
# If it is already completed, it would be inactive! `db.dao().deactivateSchedule(schedule.id)` sets `isActive = false`, so it won't be in `activeSchedules` next loop!

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)

print("Writes fixed")
