import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Add states for update
imports = """import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Schedule
import com.example.data.UpdateInfo"""
content = content.replace("""import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Schedule""", imports)

states = """    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()
    
    val updateInfo by viewModel.updateInfo.collectAsStateWithLifecycle()
    val updateDismissed by viewModel.updateDismissedForSession.collectAsStateWithLifecycle()"""
content = content.replace("""    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()""", states)

# Inside Scaffold -> Column -> LazyColumn
# we can inject the UpdatePromptCard after "item { Spacer(modifier = Modifier.height(16.dp)) }" inside LazyColumn

lazy_column = """        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                
                if (updateInfo?.isAvailable == true && !updateDismissed) {
                    UpdatePromptCard(
                        updateInfo = updateInfo!!,
                        onUpdateNow = { viewModel.startUpdateDownload() },
                        onLater = { viewModel.dismissUpdatePrompt() }
                    )
                }
                """
content = re.sub(r'LazyColumn\([\s\S]*?\) \{\s*item \{\s*Spacer\(modifier = Modifier.height\(16.dp\)\)', lazy_column, content)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)

