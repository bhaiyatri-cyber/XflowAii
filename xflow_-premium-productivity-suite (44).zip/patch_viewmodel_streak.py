with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

streak_code = """
    val currentStreak: StateFlow<Int> = history.map { list ->
        if (list.isEmpty()) return@map 0
        
        val dates = list.map { 
            val cal = Calendar.getInstance()
            cal.timeInMillis = it.date
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            cal.timeInMillis
        }.distinct().sortedDescending()
        
        if (dates.isEmpty()) return@map 0
        
        var streak = 0
        val todayCal = Calendar.getInstance()
        todayCal.set(Calendar.HOUR_OF_DAY, 0)
        todayCal.set(Calendar.MINUTE, 0)
        todayCal.set(Calendar.SECOND, 0)
        todayCal.set(Calendar.MILLISECOND, 0)
        val today = todayCal.timeInMillis
        val yesterday = today - (24 * 60 * 60 * 1000)
        
        var expectedDate = today
        if (dates[0] == today) {
            streak = 1
            expectedDate = yesterday
            for (i in 1 until dates.size) {
                if (dates[i] == expectedDate) {
                    streak++
                    expectedDate -= (24 * 60 * 60 * 1000)
                } else {
                    break
                }
            }
        } else if (dates[0] == yesterday) {
            streak = 1
            expectedDate = yesterday - (24 * 60 * 60 * 1000)
            for (i in 1 until dates.size) {
                if (dates[i] == expectedDate) {
                    streak++
                    expectedDate -= (24 * 60 * 60 * 1000)
                } else {
                    break
                }
            }
        }
        streak
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0)
"""

if 'val currentStreak' not in content:
    content = content.replace('val history: StateFlow<List<HistorySession>> = db.dao().getAllHistory()\n        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())', 'val history: StateFlow<List<HistorySession>> = db.dao().getAllHistory()\n        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())\n' + streak_code)
    
    with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
        f.write(content)
    print("Patched XFlowViewModel with currentStreak")
else:
    print("Already patched XFlowViewModel")
