with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    db = f.read()

offline_chat_entity = """@Entity(tableName = "offline_chats")
data class OfflineChat(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val role: String,
    val message: String,
    val timestamp: Long
)"""

if "OfflineChat" not in db:
    db = db.replace('data class AiChat(', f'{offline_chat_entity}\n\ndata class AiChat(')

dao_methods = """    @Query("SELECT * FROM offline_chats ORDER BY timestamp ASC")
    fun getAllOfflineChats(): kotlinx.coroutines.flow.Flow<List<OfflineChat>>

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun insertOfflineChat(chat: OfflineChat)

    @Query("DELETE FROM offline_chats")
    suspend fun clearOfflineChats()
"""
if "getAllOfflineChats" not in db:
    db = db.replace('interface XFlowDao {', f'interface XFlowDao {{\n{dao_methods}')

db = db.replace('version = 7', 'version = 8')
db = db.replace('MockTest::class, AiChat::class]', 'MockTest::class, AiChat::class, OfflineChat::class]')

migration_8 = """val MIGRATION_7_8 = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `offline_chats` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `role` TEXT NOT NULL, `message` TEXT NOT NULL, `timestamp` INTEGER NOT NULL)")
    }
}"""
if "MIGRATION_7_8" not in db:
    db = db.replace('val MIGRATION_6_7', f'{migration_8}\n\nval MIGRATION_6_7')
    db = db.replace('.addMigrations(MIGRATION_6_7)', '.addMigrations(MIGRATION_6_7, MIGRATION_7_8)')

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(db)
