# XFlow AI Assistant — Master Specification

**IMPORTANT: Is file ko har naye change se pehle padho. Isme jo likha hai usi ke 
hisaab se kaam karo. Golden Rules kabhi mat todo.**

---

## 🔒 GOLDEN RULES (Kabhi Nahi Todni)

1. **API Key Connection**: Chat/AI features hamesha `BuildConfig.GEMINI_API_KEY` 
   use karenge. Ye value GitHub Actions build ke time `-PGEMINI_API_KEY` gradle 
   property se automatically aati hai. Isko kabhi bhi:
   - Manual "Settings/Secrets" entry system mein convert mat karo
   - Kisi doosre variable/naam mein mat badlo
   - Hardcode mat karo
   
2. **App Icon**: App ka launcher icon `res/mipmap-*` folders mein defined hai 
   (adaptive icon: foreground + background layers). Koi bhi naya feature/change 
   karte waqt in files ko touch mat karo jab tak specifically icon change karne 
   ko na bola jaye.

3. **Version Sync**: `app/build.gradle.kts` mein `versionCode` GitHub Release 
   tag se directly link hai (`build.yml` mein grep se nikalta hai). Har naye 
   build se pehle `versionCode` ko manually +1 karna hoga.

4. **Ek Baar Mein Ek Bada Change**: Agar ek saath bahut saare features add karne 
   ko bola jaye, to pehle confirm karo ki existing working features (jaise 
   chat ka API connection) na tootein. Change ke baad summary do ki kya-kya 
   touch hua.

5. **Preview ≠ Real Device**: AI Studio ka Preview simulated environment hai. 
   Real APK (GitHub Actions build) alag tarike se behave kar sakti hai — 
   database migrations, file paths, aur native crashes sirf real device pe 
   pakde ja sakte hain. Isliye risky changes (jaise database schema) ke baad 
   extra careful rehna.

---

## 🤖 XFlow AI Assistant — Kya Karega Aur Kaise

### 1. Basic Chat
- User text likhta hai, "Send" dabata hai
- App `BuildConfig.GEMINI_API_KEY` use karke Gemini API (`gemini-2.0-flash` 
  model) ko call karta hai
- Response Kotlin Coroutines mein background thread pe aata hai, UI thread 
  pe update hota hai
- Agar API fail ho (no internet, error, rate limit), user ko friendly message 
  dikhe: "Kuch gadbad hui, dobara try karo" — app crash nahi honi chahiye

### 2. Typing/Streaming Animation
- AI ka response poora ek saath nahi, **word-by-word ya character-by-character 
  type hote hue** dikhna chahiye (jaise ChatGPT)
- Jab tak type ho raha ho, chhota blinking cursor dikhe

### 3. Loading/Thinking Animation
- Jab API call chal rahi ho (response abhi nahi aaya), tab tak ek smooth 
  animation dikhe (jaise 3 dots pulse karte hue)
- Jerky/abrupt nahi honi chahiye, premium feel honi chahiye

### 4. App-Aware Context (Personalized Suggestions)
- Chat shuru hote hi, app ka current data (study hours, active schedules, 
  streaks — jo bhi app track karta hai) ek summary text ke roop mein Gemini 
  API call ke system prompt mein bhej diya jaye
- Isse AI real data ke basis pe suggestions de sake
- Ye data sirf local rahega, kahin bahar store nahi hoga

### 5. AI-Generated Mock Test
- User bole "mujhe [X] number ka [topic] test bana do" (jaise "29 number 
  Haryana GK test")
- AI ek premium-styled card generate kare chat ke andar (title, question 
  count, "Start Test" button)
- Card tap karne se Test Screen khule:
  - Gemini API se requested topic pe MCQ questions generate ho (4 options, 
    ek sahi)
  - Ek time pe ek question, "Next" button se aage
  - Progress indicator ("Question 5/29")
- **Timer**: Test shuru hote hi countdown chale (user-defined duration, ya 
  default 1 min/question). Khatam hone par auto-submit. Manual submit bhi 
  possible ho.
- **Result Screen**: Score (jaise "18/29"), time taken, "Analysis" button
- **Analysis Screen**: Har question ka review — user ka answer aur sahi 
  answer dono highlight (green = sahi, red = galat)

### 6. Chat History Sidebar
- Hamburger/menu icon se left sidebar slide-in ho (jaise ChatGPT)
- Purani chat sessions ki list (date/title ke saath)
- Tap karke us conversation mein wapas ja sake
- Mock tests bhi history mein alag entries ke roop mein dikhein (score ke 
  saath, "Analysis" dubara dekh sakein)
- "+ New Chat" option ho naya session start karne ke liye
- History local database (Room) mein save ho, app band hone ke baad bhi rahe

---

## ✅ CHECKLIST — Har Update Ke Baad Ye Zaroor Check Karo

1. [ ] Build successful hua? (Actions tab green tick)
2. [ ] App fresh install ke baad crash to nahi ho rahi (cold start test)?
3. [ ] AI Chat mein "hi" bhejke normal response aa raha hai (offline mode 
      wala error to nahi aa raha)?
4. [ ] App icon custom XFlow logo hi dikha raha hai (generic robot to nahi)?
5. [ ] Naya feature test kiya — sahi kaam kar raha hai?
6. [ ] Koi purana working feature tuta to nahi (jaise update-check system, 
      basic navigation)?

---

## 📝 Naya Change Maangne Ka Tarika (Template)

Jab bhi AI Studio ko koi naya change bolna ho, ye format use karo:

```
[Attach karo ye "XFlow_AI_Master_Spec.md" file agar pehli baar reference 
de rahe ho, ya bolo "Master Spec file follow karo"]

Mujhe ye ek change chahiye: [SIRF EK SPECIFIC CHEEZ LIKHO]

Golden Rules mat todna — especially API key connection aur app icon files 
ko mat chhedna jab tak specifically na bola jaye.
```
