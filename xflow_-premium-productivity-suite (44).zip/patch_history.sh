sed -i 's/import androidx.compose.runtime.getValue/import androidx.compose.runtime.*\nimport androidx.compose.foundation.clickable/g' app/src/main/java/com/example/ui/HistoryScreen.kt
