import re

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()

old = """        if (isPremium) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(XFlowSurfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    BasicTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier.weight(1f).padding(vertical = 8.dp),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = XFlowTextPrimary),
                        cursorBrush = SolidColor(XFlowAccent),
                        decorationBox = { innerTextField ->
                            if (inputText.isEmpty()) {
                                Text("Message XFlow AI...", color = XFlowTextSecondary, style = MaterialTheme.typography.bodyLarge)
                            }
                            innerTextField()
                        }
                    )
                    
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank() && !isGenerating) {
                                viewModel.sendMessage(inputText)
                                inputText = ""
                            }
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .background(if (inputText.isNotBlank()) XFlowAccent else XFlowSurfaceVariant, RoundedCornerShape(20.dp))
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = if (inputText.isNotBlank()) Color.White else XFlowTextSecondary)
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurfaceVariant)
            ) {
                Text(
                    "AI Chat is a Premium feature.",
                    modifier = Modifier.padding(16.dp),
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }"""

new = """        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message XFlow AI...", color = XFlowTextSecondary) },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XFlowAccent,
                    unfocusedBorderColor = XFlowSurfaceVariant,
                    focusedContainerColor = XFlowSurfaceVariant,
                    unfocusedContainerColor = XFlowSurfaceVariant,
                    focusedTextColor = XFlowTextPrimary,
                    unfocusedTextColor = XFlowTextPrimary
                ),
                maxLines = 3
            )
            Spacer(modifier = Modifier.width(8.dp))
            FloatingActionButton(
                onClick = {
                    if (inputText.isNotBlank() && !isGenerating) {
                        viewModel.sendMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier.size(48.dp),
                containerColor = XFlowAccent,
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
            }
        }"""

content = content.replace(old, new)
with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)

