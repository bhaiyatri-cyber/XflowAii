import re

with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'r') as f:
    content = f.read()

# Imports for drawer and animations
new_imports = """
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.rememberDrawerState
"""
content = content.replace("import androidx.compose.foundation.background", new_imports + "import androidx.compose.foundation.background")

# Scaffold to Drawer wrap
content = content.replace("""    Scaffold(
        topBar = {""", """    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val allSessions by aiViewModel.allSessions.collectAsStateWithLifecycle()
    val allMockTests by aiViewModel.allMockTests.collectAsStateWithLifecycle()
    
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = XFlowSurface) {
                Spacer(Modifier.height(16.dp))
                Text("Chat History", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = XFlowTextPrimary)
                Divider(color = XFlowSurfaceVariant)
                
                NavigationDrawerItem(
                    label = { Text("New Chat") },
                    selected = false,
                    onClick = {
                        aiViewModel.createNewSession()
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = XFlowAccent.copy(alpha=0.1f), unselectedIconColor = XFlowAccent, unselectedTextColor = XFlowAccent)
                )
                
                LazyColumn(modifier = Modifier.weight(1f)) {
                    item {
                        Text("Past Sessions", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleSmall, color = XFlowTextSecondary)
                    }
                    items(allSessions) { session ->
                        NavigationDrawerItem(
                            label = { Text(if (session == "default") "Main Chat" else "Session: ${session.takeLast(6)}") },
                            selected = aiViewModel.currentSessionId.value == session,
                            onClick = {
                                aiViewModel.loadSession(session)
                                scope.launch { drawerState.close() }
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = XFlowSurfaceVariant,
                                unselectedContainerColor = Color.Transparent,
                                selectedTextColor = XFlowTextPrimary,
                                unselectedTextColor = XFlowTextPrimary
                            )
                        )
                    }
                    if (allMockTests.isNotEmpty()) {
                        item {
                            Divider(color = XFlowSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
                            Text("Mock Tests", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleSmall, color = XFlowTextSecondary)
                        }
                        items(allMockTests) { test ->
                            NavigationDrawerItem(
                                label = { Text(test.title) },
                                badge = { if (test.isCompleted) Text("${test.score}/${test.totalQuestions}") else Text("Pending") },
                                selected = false,
                                onClick = {
                                    navController.navigate("mock_test/${test.id}")
                                    scope.launch { drawerState.close() }
                                },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                                colors = NavigationDrawerItemDefaults.colors(
                                    unselectedContainerColor = Color.Transparent,
                                    unselectedTextColor = XFlowTextPrimary
                                )
                            )
                        }
                    }
                }
            }
        }
    ) {
    Scaffold(
        topBar = {""")

# Update top bar to include Menu icon
content = content.replace("""                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },""", """                navigationIcon = {
                    Row {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                        }
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = XFlowTextPrimary)
                        }
                    }
                },""")

# Update ChatBubble to TypewriterText
content = content.replace("""                Text(
                    text = chat.message,
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f).padding(top = 2.dp)
                )""", """                TypewriterText(
                    text = chat.message,
                    modifier = Modifier.weight(1f).padding(top = 2.dp)
                )""")

# Add custom components
custom_components = """
@Composable
fun TypewriterText(text: String, modifier: Modifier = Modifier) {
    var textToDisplay by remember { mutableStateOf("") }
    LaunchedEffect(text) {
        if (textToDisplay == text) return@LaunchedEffect
        textToDisplay = ""
        for (i in text.indices) {
            textToDisplay += text[i]
            delay(15) // Natural typing speed
        }
    }
    Row(modifier = modifier) {
        Text(
            text = textToDisplay,
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.bodyLarge
        )
        if (textToDisplay.length < text.length) {
            Box(
                modifier = Modifier
                    .padding(start = 2.dp, top = 4.dp)
                    .size(width = 8.dp, height = 16.dp)
                    .background(XFlowAccent)
            )
        }
    }
}

@Composable
fun TypingIndicator() {
    val infiniteTransition = rememberInfiniteTransition()
    val alpha1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )
    val alpha2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing, delayMillis = 200),
            repeatMode = RepeatMode.Reverse
        )
    )
    val alpha3 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing, delayMillis = 400),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha1)))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha2)))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha3)))
    }
}
"""

content += custom_components

# Use TypingIndicator instead of Text("Thinking...")
content = content.replace("""Text(
                                text = "Thinking...",
                                color = XFlowTextSecondary,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f).padding(top = 2.dp)
                            )""", """TypingIndicator()""")

# Fix closing brace for ModalNavigationDrawer
content = content.replace("""        }
    }
}

@Composable
fun ChatBubble(chat: AiChat, navController: androidx.navigation.NavController) {""", """        }
    }
    } // End ModalNavigationDrawer
}

@Composable
fun ChatBubble(chat: AiChat, navController: androidx.navigation.NavController) {""")

with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'w') as f:
    f.write(content)
