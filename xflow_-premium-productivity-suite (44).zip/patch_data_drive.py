import re

with open('app/src/main/java/com/example/ui/DataDriveScreen.kt', 'r') as f:
    content = f.read()

# Add imports
if "import androidx.core.content.FileProvider" not in content:
    content = content.replace("import androidx.compose.ui.viewinterop.AndroidView", "import androidx.compose.ui.viewinterop.AndroidView\nimport androidx.core.content.FileProvider\nimport android.content.Intent")

old_row = """                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Folder, contentDescription = null, tint = XFlowAccent)
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = file.name, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                                Text(text = "${file.length() / 1024} KB", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                            }"""

new_row = """                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    try {
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            val extension = android.webkit.MimeTypeMap.getFileExtensionFromUrl(file.absolutePath)
                                            val mimeType = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "*/*"
                                            setDataAndType(uri, mimeType)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(intent, "Open with"))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Cannot open file", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Folder, contentDescription = null, tint = XFlowAccent)
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = file.name, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                                Text(text = "${file.length() / 1024} KB", color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                            }"""

content = content.replace(old_row, new_row)

with open('app/src/main/java/com/example/ui/DataDriveScreen.kt', 'w') as f:
    f.write(content)

