import re

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

# Fix cleanup to delete all apks
old_cleanup = """    private fun cleanupOldUpdates() {
        try {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            if (dir != null && dir.exists()) {
                val file = File(dir, "update.apk")
                if (file.exists()) {
                    file.delete()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to cleanup", e)
        }
    }"""

new_cleanup = """    private fun cleanupOldUpdates() {
        try {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            if (dir != null && dir.exists()) {
                // Delete all .apk files in the directory to prevent storage from filling up
                dir.listFiles()?.forEach { file ->
                    if (file.name.endsWith(".apk")) {
                        file.delete()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to cleanup", e)
        }
    }"""
content = content.replace(old_cleanup, new_cleanup)

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)
