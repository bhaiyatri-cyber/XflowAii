import re

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

old_changes = """                    val changes = listOf(
                        "AI Chat Integration: Added a dedicated AI Chatbot powered by Gemini to assist you with scheduling and focus.",
                        "Abstract Monogram Logo: Redesigned the brand identity with a premium geometric icon.",
                        "Performance & Security: Enhanced core security and fixed various bugs for a smoother, safer experience."
                    )"""

new_changes = """                    val changes = listOf(
                        "App Launcher Icons V2: Upgraded the app with high-resolution adaptive and legacy launcher icons across all DPIs.",
                        "Visual Consistency: Applied the new premium monogram logo to all screens, splash, and settings.",
                        "Performance & Security: Enhanced core security and fixed various bugs for a smoother, safer experience."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)
