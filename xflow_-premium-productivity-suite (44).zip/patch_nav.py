import re
with open('app/src/main/java/com/example/ui/Navigation.kt', 'r') as f:
    content = f.read()

content = content.replace("SimpleAiChatScreen(onBack = { navController.popBackStack() })",
                          "ChatbotScreen(navController = navController, onBack = { navController.popBackStack() }, viewModel = viewModel)")
with open('app/src/main/java/com/example/ui/Navigation.kt', 'w') as f:
    f.write(content)
