with open('app/src/main/java/com/example/ui/SplashScreen.kt', 'r') as f:
    content = f.read()

import re
new_effect = """LaunchedEffect(Unit) {
        kotlinx.coroutines.launch {
            alpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing)
            )
        }
        kotlinx.coroutines.launch {
            scale.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing)
            )
        }
        delay(600)
        onNavigateToHome()
    }"""

content = re.sub(r'LaunchedEffect\(Unit\)\s*\{.*?onNavigateToHome\(\)\s*\}', new_effect, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/SplashScreen.kt', 'w') as f:
    f.write(content)
