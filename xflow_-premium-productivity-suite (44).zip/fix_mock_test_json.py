with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

old_prompt = """val prompt = "Generate $number multiple choice questions about $topic. Respond ONLY with valid JSON in this exact format: [{\\"q\\": \\"Question text?\\", \\"options\\": [\\"A\\", \\"B\\", \\"C\\", \\"D\\"], \\"ans\\": 0}] where ans is the index (0-3) of the correct option. No markdown, no code blocks, just raw JSON." """

new_prompt = """val prompt = "Generate $number multiple choice questions about $topic. Respond ONLY with valid JSON in this exact format: {\\"questions\\": [{\\"q\\": \\"Question text?\\", \\"options\\": [\\"A\\", \\"B\\", \\"C\\", \\"D\\"], \\"answerIndex\\": 0}]} where answerIndex is the index (0-3) of the correct option. No markdown, no code blocks, just raw JSON." """

content = content.replace(old_prompt, new_prompt)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)

