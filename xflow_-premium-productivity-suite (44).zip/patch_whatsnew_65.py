import re
with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

content = re.sub(r'val changes = listOf\([^)]+\)', """val changes = listOf(
                        "AI Chat Integration: Added a dedicated AI Chatbot powered by Gemini to assist you with scheduling and focus.",
                        "Abstract Monogram Logo: Redesigned the brand identity with a premium geometric icon.",
                        "Performance & Security: Enhanced core security and fixed various bugs for a smoother, safer experience."
                    )""", content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)
