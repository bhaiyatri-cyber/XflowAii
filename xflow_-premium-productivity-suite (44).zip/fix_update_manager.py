with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

old_init = """    init {
        createNotificationChannel()
        androidx.core.content.ContextCompat.registerReceiver(
            context,
            downloadReceiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            androidx.core.content.ContextCompat.RECEIVER_EXPORTED
        )
    }"""

new_init = """    init {
        try {
            createNotificationChannel()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(
                    downloadReceiver,
                    IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                    Context.RECEIVER_EXPORTED
                )
            } else {
                context.registerReceiver(
                    downloadReceiver,
                    IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing UpdateManager", e)
        }
    }"""

content = content.replace(old_init, new_init)
with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)

