import re

with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

replacement = """val ciGeminiKey = project.findProperty("GEMINI_API_KEY") as? String
if (ciGeminiKey != null) {
    val envFile = rootProject.file(".env")
    val envContent = if (envFile.exists()) envFile.readText() else ""
    if (!envContent.contains("GEMINI_API_KEY=")) {
        envFile.appendText("\\nGEMINI_API_KEY=$ciGeminiKey\\n")
    } else {
        val newContent = envContent.replace(Regex("GEMINI_API_KEY=.*"), "GEMINI_API_KEY=$ciGeminiKey")
        envFile.writeText(newContent)
    }
}"""

replacement_new = """val ciGeminiKey = project.findProperty("GEMINI_API_KEY") as? String
if (ciGeminiKey != null) {
    val envFile = rootProject.file(".env")
    val envContent = if (envFile.exists()) envFile.readText() else ""
    if (!envContent.contains("GEMINI_API_KEY=")) {
        envFile.appendText("\\nGEMINI_API_KEY=$ciGeminiKey\\n")
    } else {
        val newContent = envContent.replace(Regex("GEMINI_API_KEY=.*"), "GEMINI_API_KEY=$ciGeminiKey")
        envFile.writeText(newContent)
    }
    
    val localProps = rootProject.file("local.properties")
    val propContent = if (localProps.exists()) localProps.readText() else ""
    if (!propContent.contains("GEMINI_API_KEY=")) {
        localProps.appendText("\\nGEMINI_API_KEY=$ciGeminiKey\\n")
    } else {
        val newContent = propContent.replace(Regex("GEMINI_API_KEY=.*"), "GEMINI_API_KEY=$ciGeminiKey")
        localProps.writeText(newContent)
    }
}"""

content = content.replace(replacement, replacement_new)

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
