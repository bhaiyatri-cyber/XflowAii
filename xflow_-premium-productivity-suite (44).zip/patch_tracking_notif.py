with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

content = content.replace('context.resources', 'resources')

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)
