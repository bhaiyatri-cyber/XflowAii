import re

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

# Add OvertimeSummaryCard at the end
card_code = """
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OvertimeSummaryCard(dateTitle: String, totalSeconds: Int, entries: List<com.example.data.OvertimeEntry>, cardStyle: String = "Solid") {
    var showSheet by remember { mutableStateOf(false) }
    val isImageStyle = cardStyle == "Image"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showSheet = true },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isImageStyle) androidx.compose.ui.graphics.Color.Transparent else XFlowSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, XFlowAccent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.3f),
                                    androidx.compose.ui.graphics.Color(0xFF8B5CF6).copy(alpha = 0.3f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("🔥 Overtime $dateTitle", color = XFlowAccent, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    val formatTime = String.format("%02d:%02d:%02d", totalSeconds / 3600, (totalSeconds % 3600) / 60, totalSeconds % 60)
                    Text(formatTime, color = XFlowTextPrimary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            containerColor = XFlowSurface,
            contentColor = XFlowTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "Overtime Details",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = XFlowTextPrimary
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                val subjectMap = entries.groupBy { it.subject }.mapValues { (_, v) -> v.sumOf { it.overtimeSeconds } }
                
                subjectMap.forEach { (subject, seconds) ->
                    val studiedStr = String.format("%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60)
                    DetailRow(subject, studiedStr)
                }
                
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
"""

if "fun OvertimeSummaryCard" not in content:
    content += "\n" + card_code

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)

