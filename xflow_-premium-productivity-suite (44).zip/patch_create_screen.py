import re

with open('app/src/main/java/com/example/ui/CreateScheduleScreen.kt', 'r') as f:
    content = f.read()

# Add TimeUtils and activeSchedules
if "import com.example.utils.TimeUtils" not in content:
    content = content.replace("import com.example.ui.theme.*", "import com.example.ui.theme.*\nimport com.example.utils.TimeUtils\nimport androidx.lifecycle.compose.collectAsStateWithLifecycle")

# We need to collect activeSchedules. It might already be collected?
if "val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()" not in content:
    content = content.replace("var appsList by remember { mutableStateOf<List<AppInfo>>(emptyList()) }", "var appsList by remember { mutableStateOf<List<AppInfo>>(emptyList()) }\n    val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()")

save_old = """                    viewModel.addSchedule(
                        Schedule(
                            subject = subject,
                            description = description,
                            isDurationMode = isDurationMode,"""

save_new = """                    if (!isDurationMode) {
                        val newStart = TimeUtils.timeToMinutes(startTimeStr)
                        val newEnd = TimeUtils.timeToMinutes(endTimeStr)
                        if (newEnd <= newStart) {
                            Toast.makeText(context, "End time must be after start time", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (TimeUtils.hasTimeOverlap(startTimeStr, endTimeStr, -1, activeSchedules)) {
                            Toast.makeText(context, "This time overlaps with another schedule", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                    }
                    viewModel.addSchedule(
                        Schedule(
                            subject = subject,
                            description = description,
                            isDurationMode = isDurationMode,"""

content = content.replace(save_old, save_new)

# Add Toast import if not present
if "import android.widget.Toast" not in content:
    content = content.replace("import androidx.compose.ui.unit.dp", "import androidx.compose.ui.unit.dp\nimport android.widget.Toast")

with open('app/src/main/java/com/example/ui/CreateScheduleScreen.kt', 'w') as f:
    f.write(content)
