import re

def replace_format(filepath):
    with open(filepath, 'r') as f:
        content = f.read()

    # Add import if needed
    if 'import com.example.utils.TimeUtils' not in content:
        content = content.replace('import androidx.compose.runtime.*', 'import androidx.compose.runtime.*\nimport com.example.utils.TimeUtils')
        
    content = content.replace('String.format("%.1fh", todayHours)', 'TimeUtils.formatHours(todayHours)')
    content = content.replace('String.format("%.1f", todayHours)}h', '${TimeUtils.formatHours(todayHours)}')
    content = content.replace('String.format("%.1fh", lifetimeHours)', 'TimeUtils.formatHours(lifetimeHours)')
    content = content.replace('String.format("%.1f", lifetimeHours)}h', '${TimeUtils.formatHours(lifetimeHours)}')

    with open(filepath, 'w') as f:
        f.write(content)

replace_format('app/src/main/java/com/example/ui/HomeScreen.kt')
replace_format('app/src/main/java/com/example/ui/HistoryScreen.kt')
replace_format('app/src/main/java/com/example/ui/SettingsScreen.kt')
replace_format('app/src/main/java/com/example/ui/DailyReportScreen.kt')
