import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

new_tool = """
                            addJsonObject {
                                put("name", "createMockTest")
                                put("description", "Create a mock test with multiple choice questions.")
                                putJsonObject("parameters") {
                                    put("type", "OBJECT")
                                    putJsonObject("properties") {
                                        putJsonObject("title") {
                                            put("type", "STRING")
                                            put("description", "Title of the mock test")
                                        }
                                        putJsonObject("questions") {
                                            put("type", "ARRAY")
                                            put("description", "List of questions")
                                            putJsonObject("items") {
                                                put("type", "OBJECT")
                                                putJsonObject("properties") {
                                                    putJsonObject("q") {
                                                        put("type", "STRING")
                                                    }
                                                    putJsonObject("options") {
                                                        put("type", "ARRAY")
                                                        put("description", "List of exactly 4 options")
                                                        putJsonObject("items") {
                                                            put("type", "STRING")
                                                        }
                                                    }
                                                    putJsonObject("answerIndex") {
                                                        put("type", "INTEGER")
                                                        put("description", "0-based index of the correct option")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    putJsonArray("required") {
                                        add("title")
                                        add("questions")
                                    }
                                }
                            }"""

if 'createMockTest' not in content:
    content = content.replace(
        'putJsonArray("functionDeclarations") {',
        'putJsonArray("functionDeclarations") {\n' + new_tool
    )

    sys_inst_find = 'If the user asks to create a schedule, use the createSchedule function.'
    sys_inst_repl = 'If the user asks to create a schedule, use the createSchedule function. If the user asks for a mock test, use the createMockTest function.'
    content = content.replace(sys_inst_find, sys_inst_repl)

    handle_find = """
                    if (name == "createSchedule") {
                        val args = functionCall["args"]?.jsonObject"""
    handle_repl = """
                    if (name == "createMockTest") {
                        val args = functionCall["args"]?.jsonObject
                        val title = args?.get("title")?.jsonPrimitive?.content ?: "Generated Mock Test"
                        val testDataJson = args.toString()
                        
                        val insertedId = db.dao().insertMockTest(
                            MockTest(
                                title = title,
                                testDataJson = testDataJson,
                                date = System.currentTimeMillis()
                            )
                        )
                        
                        db.dao().insertAiChat(AiChat(role = "model", message = "[MOCK_TEST_CARD:$insertedId:$title]", timestamp = System.currentTimeMillis()))
                    } else if (name == "createSchedule") {
                        val args = functionCall["args"]?.jsonObject"""
    
    content = content.replace(handle_find, handle_repl)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
