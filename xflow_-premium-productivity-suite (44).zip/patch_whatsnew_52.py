import re

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

old_changes = """                    val changes = listOf(
                        "Fixed Data & Web Hub: You can now download and open files easily.",
                        "YouTube Sizing: Videos now properly scale to fit the screen.",
                        "ChatGPT Fix: Resolved loading issues and optimized the chat view.",
                        "Full-Screen Updates: Removed popup dialogs for a cleaner update announcement screen.",
                        "Performance and stability improvements."
                    )"""

new_changes = """                    val changes = listOf(
                        "All Time History Scroll Fix: The entire history page is now fully scrollable so you can easily view your timeline, streaks, and all your history folders without getting stuck.",
                        "Data & Web Hub Fixes: Resolved file download & open issues.",
                        "YouTube & ChatGPT Fixes: Improved scaling, loading, and chat views.",
                        "Full-Screen Updates: Removed popup dialogs for a cleaner screen.",
                        "Performance and stability improvements."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)

