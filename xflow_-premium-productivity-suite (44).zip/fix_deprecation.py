import re

for filename in ['app/src/main/java/com/example/ui/PermissionsScreen.kt', 'app/src/main/java/com/example/utils/PermissionUtils.kt']:
    with open(filename, 'r') as f:
        content = f.read()
    
    # replace 'fun hasUsageStatsPermission' with '@Suppress("DEPRECATION")\n    fun hasUsageStatsPermission'
    # Wait, the structure might be different. Let's just find `unsafeCheckOpNoThrow` and suppress the method.
    content = content.replace('fun hasUsageStatsPermission', '@Suppress("DEPRECATION")\nfun hasUsageStatsPermission')
    content = content.replace('    @Suppress("DEPRECATION")\nfun', '    @Suppress("DEPRECATION")\n    fun') # Fix indentation if needed
    
    with open(filename, 'w') as f:
        f.write(content)

print("Deprecation suppressed")
