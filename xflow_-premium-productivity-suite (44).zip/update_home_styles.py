with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

old_card = """    val isImageStyle = cardStyle == "Image" && schedule.isFromStudyPlan
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isImageStyle) Color.Transparent else containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isPremium) 4.dp else 2.dp),
        border = androidx.compose.foundation.BorderStroke(if (isPremium) 2.dp else 1.dp, borderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.3f),
                                    Color(0xFF8B5CF6).copy(alpha = 0.3f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {"""

new_card = """    val isImageStyle = cardStyle == "Image" && schedule.isFromStudyPlan
    val isGradientStyle = cardStyle == "Gradient"
    val isOutlinedStyle = cardStyle == "Outlined"
    val isSoftStyle = cardStyle == "Soft"
    
    val finalContainerColor = when {
        isImageStyle || isGradientStyle -> Color.Transparent
        isSoftStyle -> XFlowSurfaceVariant.copy(alpha = 0.3f)
        isOutlinedStyle -> Color.Transparent
        else -> containerColor
    }

    val defaultElev = when {
        isPremium -> 4.dp
        isOutlinedStyle || isSoftStyle -> 0.dp
        else -> 2.dp
    }
    
    val strokeWidth = when {
        isPremium -> 2.dp
        isOutlinedStyle -> 1.dp
        isSoftStyle -> 0.dp
        else -> 1.dp
    }

    val finalBorderColor = if (isOutlinedStyle) XFlowTextSecondary.copy(alpha=0.3f) else borderColor

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = finalContainerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = defaultElev),
        border = androidx.compose.foundation.BorderStroke(strokeWidth, finalBorderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isImageStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.3f),
                                    Color(0xFF8B5CF6).copy(alpha = 0.3f),
                                    XFlowSurface
                                )
                            )
                        )
                    } else if (isGradientStyle) {
                        Modifier.background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(
                                    XFlowAccent.copy(alpha = 0.1f),
                                    XFlowSurface,
                                    XFlowAccent.copy(alpha = 0.05f)
                                )
                            )
                        )
                    } else {
                        Modifier
                    }
                )
        ) {"""

content = content.replace(old_card, new_card)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
