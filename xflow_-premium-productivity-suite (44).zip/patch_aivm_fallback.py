with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

fallback = """
            if (BuildConfig.GEMINI_API_KEY.isEmpty() || !BuildConfig.GEMINI_API_KEY.startsWith("AIza")) {
                kotlinx.coroutines.delay(1000)
                if (message.lowercase().contains("mock test") || message.lowercase().contains("test")) {
                    val testTitle = "Demo Mock Test (Offline)"
                    val mockJson = "{\\"title\\": \\"Demo Mock Test (Offline)\\", \\"questions\\": [{\\"q\\": \\"What is 2+2?\\", \\"options\\": [\\"3\\", \\"4\\", \\"5\\", \\"6\\"], \\"answerIndex\\": 1}, {\\"q\\": \\"What is the capital of France?\\", \\"options\\": [\\"Berlin\\", \\"Madrid\\", \\"Paris\\", \\"Rome\\"], \\"answerIndex\\": 2}, {\\"q\\": \\"Which planet is known as the Red Planet?\\", \\"options\\": [\\"Venus\\", \\"Mars\\", \\"Jupiter\\", \\"Saturn\\"], \\"answerIndex\\": 1}]}"
                    val insertedId = db.dao().insertMockTest(MockTest(
                        title = testTitle,
                        testDataJson = mockJson,
                        date = System.currentTimeMillis()
                    ))
                    db.dao().insertAiChat(AiChat(role = "model", message = "[MOCK_TEST_CARD:$insertedId:$testTitle]", timestamp = System.currentTimeMillis()))
                } else if (message.lowercase().contains("schedule")) {
                    val schedName = "Demo Offline Schedule"
                    db.dao().insertSchedule(
                        Schedule(
                            subject = schedName,
                            description = "This is a demo schedule.",
                            isDurationMode = true,
                            durationMinutes = 25,
                            startTimeStr = "",
                            endTimeStr = "",
                            isOnlineMode = false,
                            selectedAppPackage = null,
                            isActive = true
                        )
                    )
                    db.dao().insertAiChat(AiChat(role = "model", message = "🎉 Schedule '$schedName' created successfully! You can view it on your Home screen.", timestamp = System.currentTimeMillis()))
                } else {
                    val reply = "I am running in offline mode. Please configure a valid Gemini API Key (starting with 'AIza') in Settings/Secrets to enable full AI chat. For now, try asking me to 'create a mock test' or 'create a schedule'."
                    db.dao().insertAiChat(AiChat(role = "model", message = reply, timestamp = System.currentTimeMillis()))
                }
                isGenerating.value = false
                return@launch
            }"""

if 'BuildConfig.GEMINI_API_KEY.isEmpty()' not in content:
    content = content.replace(
        '            try {',
        fallback + '\n            try {'
    )
    if 'import kotlinx.coroutines.delay' not in content:
        content = content.replace('import kotlinx.coroutines.launch', 'import kotlinx.coroutines.launch\nimport kotlinx.coroutines.delay')

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
