with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    vm = f.read()

offline_chat_props = """    val offlineChats: kotlinx.coroutines.flow.StateFlow<List<com.example.data.OfflineChat>> = db.dao().getAllOfflineChats()
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.Lazily, emptyList())

    fun insertOfflineChat(role: String, message: String) {
        viewModelScope.launch {
            db.dao().insertOfflineChat(com.example.data.OfflineChat(role = role, message = message, timestamp = System.currentTimeMillis()))
        }
    }
    
    fun clearOfflineChats() {
        viewModelScope.launch {
            db.dao().clearOfflineChats()
        }
    }
    
    fun createScheduleFromChatbot(name: String, description: String, time: String) {
        viewModelScope.launch {
            db.dao().insertSchedule(
                com.example.data.Schedule(
                    title = name,
                    description = "$description\\nTime: $time",
                    totalDurationMinutes = 25,
                    isPomodoro = true,
                    isActive = true
                )
            )
        }
    }
"""

if "offlineChats" not in vm:
    vm = vm.replace('val overtimeEntries', f'{offline_chat_props}\n    val overtimeEntries')

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(vm)
