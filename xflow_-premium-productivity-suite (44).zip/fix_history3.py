with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

part = """                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }
        }
    }

@OptIn(ExperimentalMaterial3Api::class)"""

fixed_part = """                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)"""

content = content.replace(part, fixed_part)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
