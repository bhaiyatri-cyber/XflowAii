from PIL import Image
img = Image.new('RGB', (512, 512), color = (0, 0, 0))
img.save('app/src/main/res/drawable/app_logo.png')
