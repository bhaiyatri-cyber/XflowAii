with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

new_autocomplete = """                    if (autoComplete && schedule.isOnlineMode && schedule.selectedAppPackage == currentApp) {
                        autoComplete = false
                    }

                    if (autoComplete) {
                        db.dao().insertHistory(
                            com.example.data.HistorySession(
                                scheduleId = schedule.id,
                                subject = schedule.subject,
                                mode = "Exact Time",
                                date = System.currentTimeMillis(),
                                timeStudiedSeconds = schedule.elapsedSeconds,
                                completionPercentage = if (targetTime > 0) ((schedule.elapsedSeconds.toFloat() / targetTime.toFloat()) * 100).toInt().coerceIn(0, 100) else 100,
                                status = "Completed"
                            )
                        )
                        if (schedule.overtimeSeconds > 0) {
                            db.dao().insertOvertimeEntry(
                                com.example.data.OvertimeEntry(
                                    scheduleId = schedule.id,
                                    subject = schedule.subject,
                                    overtimeSeconds = schedule.overtimeSeconds,
                                    date = System.currentTimeMillis()
                                )
                            )
                        }
                        db.dao().deactivateSchedule(schedule.id)
                        sendAlertNotification(
                            "Goal Reached \\uD83C\\uDF89",
                            "You've completed your focus session for '${schedule.subject}'!",
                            schedule.id + 2000
                        )
                        continue
                    }"""

content = content.replace(
    """                    if (autoComplete) {
                        db.dao().insertHistory(
                            com.example.data.HistorySession(
                                scheduleId = schedule.id,
                                subject = schedule.subject,
                                mode = "Exact Time",
                                date = System.currentTimeMillis(),
                                timeStudiedSeconds = schedule.elapsedSeconds,
                                completionPercentage = if (targetTime > 0) ((schedule.elapsedSeconds.toFloat() / targetTime.toFloat()) * 100).toInt().coerceIn(0, 100) else 100,
                                status = "Completed"
                            )
                        )
                        db.dao().deactivateSchedule(schedule.id)
                        sendAlertNotification(
                            "Goal Reached \\uD83C\\uDF89",
                            "You've completed your focus session for '${schedule.subject}'!",
                            schedule.id + 2000
                        )
                        continue
                    }""",
    new_autocomplete
)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)
