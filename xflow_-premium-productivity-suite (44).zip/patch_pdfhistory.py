import re

with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'r') as f:
    content = f.read()

# Add launcher at the top of PdfHistoryTab
old_top = """    var showRenameDialog by remember { mutableStateOf<File?>(null) }
    var renameText by remember { mutableStateOf("") }"""

new_top = """    var showRenameDialog by remember { mutableStateOf<File?>(null) }
    var renameText by remember { mutableStateOf("") }
    
    var fileToAppend by remember { mutableStateOf<File?>(null) }
    var isAppending by remember { mutableStateOf(false) }

    val appendLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty() && fileToAppend != null) {
            isAppending = true
            coroutineScope.launch {
                val success = PdfGenerator.appendImagesToPdf(context, fileToAppend!!, uris)
                isAppending = false
                if (success) {
                    savedPdfs = PdfGenerator.getSavedPdfs(context)
                    Toast.makeText(context, "Pages added successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Failed to add pages", Toast.LENGTH_SHORT).show()
                }
                fileToAppend = null
            }
        }
    }"""
content = content.replace(old_top, new_top)

# Add DropdownMenuItem
old_menu = """                                DropdownMenuItem(
                                    text = { Text("Rename", color = XFlowTextPrimary) },
                                    onClick = {
                                        renameText = file.nameWithoutExtension
                                        showRenameDialog = file
                                        menuExpanded = false
                                    }
                                )"""

new_menu = """                                DropdownMenuItem(
                                    text = { Text("Add Page", color = XFlowTextPrimary) },
                                    onClick = {
                                        menuExpanded = false
                                        fileToAppend = file
                                        appendLauncher.launch("image/*")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Rename", color = XFlowTextPrimary) },
                                    onClick = {
                                        renameText = file.nameWithoutExtension
                                        showRenameDialog = file
                                        menuExpanded = false
                                    }
                                )"""
content = content.replace(old_menu, new_menu)

# Show progress indicator if appending
old_empty_check = """    if (savedPdfs.isEmpty()) {"""
new_empty_check = """    if (isAppending) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = XFlowAccent)
        }
    } else if (savedPdfs.isEmpty()) {"""

content = content.replace(old_empty_check, new_empty_check)

with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'w') as f:
    f.write(content)
