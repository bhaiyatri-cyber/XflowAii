import re
import os

def remove_duplicates(content):
    lines = content.split('\n')
    seen_imports = set()
    new_lines = []
    for line in lines:
        if line.startswith('import '):
            if line in seen_imports:
                continue
            seen_imports.add(line)
        new_lines.append(line)
    return '\n'.join(new_lines)

files = [
    'app/src/main/java/com/example/service/DailySummaryWorker.kt',
    'app/src/main/java/com/example/service/SchedulingWorker.kt',
    'app/src/main/java/com/example/service/TrackingService.kt',
    'app/src/main/java/com/example/ui/AboutScreen.kt',
    'app/src/main/java/com/example/ui/PremiumDialog.kt',
    'app/src/main/java/com/example/utils/UpdateManager.kt',
    'app/src/main/java/com/example/ui/SplashScreen.kt',
    'app/src/main/java/com/example/ui/SettingsScreen.kt',
    'app/src/main/java/com/example/ui/HomeScreen.kt',
    'app/src/main/java/com/example/ui/WhatsNewScreen.kt'
]

for fpath in files:
    if os.path.exists(fpath):
        with open(fpath, 'r') as f:
            content = f.read()
        content = remove_duplicates(content)
        with open(fpath, 'w') as f:
            f.write(content)

