import re
with open('app/src/main/java/com/example/ui/SimpleAiChatScreen.kt', 'r') as f:
    content = f.read()

# find SimpleChatBubble and change the Text to TypewriterText
if "TypewriterText(" not in content:
    # let's append the TypewriterText to the end of the file if not exists
    content += """
@Composable
fun SimpleTypewriterText(text: String, modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier) {
    var textToDisplay by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    var isFinished by androidx.compose.runtime.saveable.rememberSaveable(text) { androidx.compose.runtime.mutableStateOf(false) }
    var cursorVisible by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }

    androidx.compose.runtime.LaunchedEffect(text) {
        if (isFinished) {
            textToDisplay = text
            return@LaunchedEffect
        }
        textToDisplay = ""
        
        val cursorJob = kotlinx.coroutines.launch {
            while (true) {
                cursorVisible = !cursorVisible
                kotlinx.coroutines.delay(300)
            }
        }
        
        val chars = text.toCharArray()
        for (i in chars.indices) {
            textToDisplay += chars[i]
            kotlinx.coroutines.delay(15) 
        }
        
        isFinished = true
        cursorJob.cancel()
        cursorVisible = false
    }

    androidx.compose.material3.Text(
        text = textToDisplay + if (!isFinished && cursorVisible) " ▌" else "",
        color = com.example.ui.theme.XFlowTextPrimary,
        style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
        modifier = modifier
    )
}
"""
    # now replace the Text(msg.text) in SimpleChatBubble with SimpleTypewriterText
    old_bubble = """                Text(
                    text = msg.text,
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f).padding(top = 2.dp)
                )"""
    new_bubble = """                SimpleTypewriterText(
                    text = msg.text,
                    modifier = Modifier.weight(1f).padding(top = 2.dp)
                )"""
    content = content.replace(old_bubble, new_bubble)

with open('app/src/main/java/com/example/ui/SimpleAiChatScreen.kt', 'w') as f:
    f.write(content)

