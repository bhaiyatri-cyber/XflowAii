with open('app/src/main/java/com/example/utils/BackupRestoreUtils.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'val overtime = kotlinx.coroutines.flow.first(dao.getAllOvertimeEntries())',
    'val overtime = dao.getAllOvertimeEntries().first()'
)

with open('app/src/main/java/com/example/utils/BackupRestoreUtils.kt', 'w') as f:
    f.write(content)
