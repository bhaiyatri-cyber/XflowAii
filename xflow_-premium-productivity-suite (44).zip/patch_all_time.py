import re

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

# Add overtimeEntries to AllTimeHistoryScreen
old_start = """    val history by viewModel.history.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()"""

new_start = """    val history by viewModel.history.collectAsStateWithLifecycle()
    val overtimeEntries by viewModel.overtimeEntries.collectAsStateWithLifecycle()
    val cardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()"""

content = content.replace(old_start, new_start)

# Group overtime
old_group = """                val groupedHistory = history.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }.toSortedMap(compareByDescending { 
                    try { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).parse(it)?.time ?: 0L } catch(e: Exception) { 0L }
                })"""

new_group = """                val groupedHistory = history.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }.toSortedMap(compareByDescending { 
                    try { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).parse(it)?.time ?: 0L } catch(e: Exception) { 0L }
                })
                val groupedOvertime = overtimeEntries.groupBy { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it.date)) }"""

content = content.replace(old_group, new_group)

# Add overtime card inside expanded block
old_expanded = """                        if (expandedDates.contains(dateStr)) {
                            items(sessions.sortedByDescending { it.date }) { session ->
                                Box(modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp)) {
                                    HistoryCard(session, cardStyle = cardStyle)
                                }
                            }
                            item { Spacer(modifier = Modifier.height(8.dp)) }
                        }"""

new_expanded = """                        if (expandedDates.contains(dateStr)) {
                            val overtimeForDate = groupedOvertime[dateStr]
                            if (!overtimeForDate.isNullOrEmpty()) {
                                item {
                                    Box(modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp)) {
                                        OvertimeSummaryCard(
                                            dateTitle = if (dateStr == SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())) "Today" else dateStr,
                                            totalSeconds = overtimeForDate.sumOf { it.overtimeSeconds },
                                            entries = overtimeForDate,
                                            cardStyle = cardStyle
                                        )
                                    }
                                }
                            }
                            items(sessions.sortedByDescending { it.date }) { session ->
                                Box(modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp)) {
                                    HistoryCard(session, cardStyle = cardStyle)
                                }
                            }
                            item { Spacer(modifier = Modifier.height(8.dp)) }
                        }"""

content = content.replace(old_expanded, new_expanded)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)

