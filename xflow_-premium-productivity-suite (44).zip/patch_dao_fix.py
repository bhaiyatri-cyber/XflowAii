import re

with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

content = content.replace('DELETE FROM aichats', 'DELETE FROM ai_chats')

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)
