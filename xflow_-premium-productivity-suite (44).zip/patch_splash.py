import re

with open('app/src/main/java/com/example/ui/SplashScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('import androidx.compose.material.icons.filled.AvTimer', 'import androidx.compose.ui.res.painterResource\nimport androidx.compose.foundation.Image\nimport com.example.R\nimport androidx.compose.foundation.shape.RoundedCornerShape\nimport androidx.compose.ui.draw.clip')
content = content.replace("""            Icon(
                imageVector = Icons.Default.AvTimer,
                contentDescription = "XFlow Logo",
                tint = XFlowAccent,
                modifier = Modifier.size(80.dp)
            )""", """            Image(
                painter = painterResource(id = R.drawable.app_logo),
                contentDescription = "XFlow Logo",
                modifier = Modifier.size(120.dp).clip(RoundedCornerShape(24.dp))
            )""")
            
with open('app/src/main/java/com/example/ui/SplashScreen.kt', 'w') as f:
    f.write(content)
