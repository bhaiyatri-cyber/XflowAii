import urllib.request
import json
import os

api_key = os.environ.get("GEMINI_API_KEY", "")

data = {
  "contents": [
    {
      "parts": [
        {"text": "Hello"}
      ]
    }
  ]
}

req = urllib.request.Request(f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={api_key}", data=json.dumps(data).encode("utf-8"), headers={"Content-Type": "application/json"})
try:
  res = urllib.request.urlopen(req)
  print("Success")
except Exception as e:
  print("Failed", e)
