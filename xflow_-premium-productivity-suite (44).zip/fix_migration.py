import re
with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

content = content.replace('db.execSQL("ALTER TABLE offline_chats ADD COLUMN sessionId TEXT NOT NULL DEFAULT \'default\'")', 'db.execSQL("CREATE TABLE IF NOT EXISTS `offline_chats` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `role` TEXT NOT NULL, `message` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, `sessionId` TEXT NOT NULL DEFAULT \'default\')")')

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)
