import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

fallback_logic = """
            if (BuildConfig.GEMINI_API_KEY.isEmpty() || !BuildConfig.GEMINI_API_KEY.startsWith("AIza")) {
                delay(1000)
                if (isMockTestRequest) {
                    val testTitle = "Demo Mock Test"
                    val mockJson = "{\"title\": \"Demo Mock Test\", \"questions\": [{\"q\": \"What is 2+2?\", \"options\": [\"3\", \"4\", \"5\", \"6\"], \"answerIndex\": 1}, {\"q\": \"What is the capital of France?\", \"options\": [\"Berlin\", \"Madrid\", \"Paris\", \"Rome\"], \"answerIndex\": 2}]}"
                    val insertedId = db.dao().insertMockTest(MockTest(
                        title = testTitle,
                        testDataJson = mockJson,
                        date = System.currentTimeMillis()
                    ))
                    db.dao().insertAiChat(AiChat(role = "model", message = "Since there is no valid API key configured, I have generated a Demo Mock Test for you.", timestamp = System.currentTimeMillis()))
                    sendMockTestReadyNotification(testTitle, insertedId.toInt())
                } else {
                    val lowerMessage = message.lowercase()
                    val reply = if (lowerMessage.contains("hello") || lowerMessage.contains("hi")) {
                        "Hello! I am currently running in offline mock mode because no valid Gemini API Key was found."
                    } else if (lowerMessage.contains("help")) {
                        "I can help you create study plans or mock tests. (Offline Mode)"
                    } else {
                        "I am running in offline mode. Please configure a valid Gemini API Key (starting with 'AIza') in AI Studio Secrets to enable full AI chat. For now, try asking me to 'create a mock test'."
                    }
                    db.dao().insertAiChat(AiChat(role = "model", message = reply, timestamp = System.currentTimeMillis()))
                }
                isGenerating.value = false
                return@launch
            }
"""

# Find the start of the try block
target = "            try {"
if target in content:
    content = content.replace(target, fallback_logic + "\n" + target)

# add delay import
if "import kotlinx.coroutines.delay" not in content:
    content = content.replace("import kotlinx.coroutines.launch", "import kotlinx.coroutines.launch\nimport kotlinx.coroutines.delay")

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
print("Patched AiViewModel with fallback logic")
