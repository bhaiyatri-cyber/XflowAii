with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

if 'UpdateManager' not in content:
    content = content.replace('import android.os.Bundle', 'import android.os.Bundle\nimport com.example.utils.UpdateManager')
    content = content.replace('super.onCreate(savedInstanceState)\n        enableEdgeToEdge()', 'super.onCreate(savedInstanceState)\n        enableEdgeToEdge()\n        UpdateManager(this).checkForUpdate()')
    with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
        f.write(content)
