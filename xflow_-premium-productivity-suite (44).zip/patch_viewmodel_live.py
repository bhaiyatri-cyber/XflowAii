with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

target1 = """    val todayHours: StateFlow<Float> = history.map { list ->
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val todayStart = cal.timeInMillis
        list.filter { it.date > todayStart }.sumOf { it.timeStudiedSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val lifetimeHours: StateFlow<Float> = history.map { list ->
        list.sumOf { it.timeStudiedSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val todayOvertimeHours: StateFlow<Float> = overtimeEntries.map { list ->
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val todayStart = cal.timeInMillis
        list.filter { it.date > todayStart }.sumOf { it.overtimeSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val lifetimeOvertimeHours: StateFlow<Float> = overtimeEntries.map { list ->
        list.sumOf { it.overtimeSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)"""

replacement1 = """    val todayHours: StateFlow<Float> = kotlinx.coroutines.flow.combine(history, activeSchedules) { list, actives ->
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val todayStart = cal.timeInMillis
        val historySum = list.filter { it.date > todayStart }.sumOf { it.timeStudiedSeconds }
        val activeSum = actives.sumOf { it.elapsedSeconds }
        (historySum + activeSum) / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val lifetimeHours: StateFlow<Float> = kotlinx.coroutines.flow.combine(history, activeSchedules) { list, actives ->
        val historySum = list.sumOf { it.timeStudiedSeconds }
        val activeSum = actives.sumOf { it.elapsedSeconds }
        (historySum + activeSum) / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val todayOvertimeHours: StateFlow<Float> = kotlinx.coroutines.flow.combine(overtimeEntries, activeSchedules) { list, actives ->
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val todayStart = cal.timeInMillis
        val historySum = list.filter { it.date > todayStart }.sumOf { it.overtimeSeconds }
        val activeSum = actives.sumOf { it.overtimeSeconds }
        (historySum + activeSum) / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val lifetimeOvertimeHours: StateFlow<Float> = kotlinx.coroutines.flow.combine(overtimeEntries, activeSchedules) { list, actives ->
        val historySum = list.sumOf { it.overtimeSeconds }
        val activeSum = actives.sumOf { it.overtimeSeconds }
        (historySum + activeSum) / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)"""

content = content.replace(target1, replacement1)

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(content)
print("Patched XFlowViewModel live tracking")
