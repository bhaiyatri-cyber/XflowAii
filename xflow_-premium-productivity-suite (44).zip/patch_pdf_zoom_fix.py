import re

with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'r') as f:
    content = f.read()

bad_zoom = """                    Modifier
                        .fillMaxWidth()
                        .heightIn(max = 600.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                val maxOffset = (scale - 1) * size.width
                                val x = (offset.x + pan.x * scale).coerceIn(-maxOffset, maxOffset)
                                val y = (offset.y + pan.y * scale).coerceIn(-maxOffset * 2, maxOffset * 2) 
                                offset = androidx.compose.ui.geometry.Offset(x, y)
                            }
                        }
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offset.x,
                            translationY = offset.y
                        )"""

good_zoom = """                    Modifier
                        .fillMaxWidth()
                        .heightIn(max = 600.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .pointerInput(Unit) {
                            detectTransformGestures { centroid, pan, zoom, _ ->
                                val oldScale = scale
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                val fractionalX = (centroid.x - offset.x) / oldScale
                                val fractionalY = (centroid.y - offset.y) / oldScale
                                
                                val newOffsetX = offset.x + pan.x * scale - fractionalX * (scale - oldScale)
                                val newOffsetY = offset.y + pan.y * scale - fractionalY * (scale - oldScale)
                                
                                val maxX = (size.width * (scale - 1)) / 2f
                                val maxY = (size.height * (scale - 1)) / 2f
                                offset = androidx.compose.ui.geometry.Offset(
                                    x = newOffsetX.coerceIn(-maxX, maxX),
                                    y = newOffsetY.coerceIn(-maxY, maxY)
                                )
                            }
                        }
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offset.x,
                            translationY = offset.y
                        )"""

if bad_zoom in content:
    content = content.replace(bad_zoom, good_zoom)
else:
    # Try generic search
    content = re.sub(
        r'detectTransformGestures \{ _, pan, zoom, _ ->[\s\S]*?offset = androidx\.compose\.ui\.geometry\.Offset\(x, y\)\n\s*\}',
        """detectTransformGestures { centroid, pan, zoom, _ ->
                                val oldScale = scale
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                val fractionalX = (centroid.x - offset.x) / oldScale
                                val fractionalY = (centroid.y - offset.y) / oldScale
                                
                                val newOffsetX = offset.x + pan.x * scale - fractionalX * (scale - oldScale)
                                val newOffsetY = offset.y + pan.y * scale - fractionalY * (scale - oldScale)
                                
                                val maxX = (size.width * (scale - 1)) / 2f
                                val maxY = (size.height * (scale - 1)) / 2f
                                offset = androidx.compose.ui.geometry.Offset(
                                    x = newOffsetX.coerceIn(-maxX, maxX),
                                    y = newOffsetY.coerceIn(-maxY, maxY)
                                )
                            }""",
        content
    )

with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'w') as f:
    f.write(content)
print("Zoom fixed")
