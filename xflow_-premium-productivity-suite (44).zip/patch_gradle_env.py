import re

with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

# Add the script to read property and write to .env right after plugins block
injection = """
// Read API key from Gradle property (e.g. passed via GitHub Actions: -PGEMINI_API_KEY=...)
val ciGeminiKey = project.findProperty("GEMINI_API_KEY") as? String
if (ciGeminiKey != null) {
    val envFile = rootProject.file(".env")
    val envContent = if (envFile.exists()) envFile.readText() else ""
    if (!envContent.contains("GEMINI_API_KEY=")) {
        envFile.appendText("\\nGEMINI_API_KEY=$ciGeminiKey\\n")
    } else {
        val newContent = envContent.replace(Regex("GEMINI_API_KEY=.*"), "GEMINI_API_KEY=$ciGeminiKey")
        envFile.writeText(newContent)
    }
}
"""

if "val ciGeminiKey" not in content:
    content = content.replace("android {", injection + "\nandroid {")
    with open('app/build.gradle.kts', 'w') as f:
        f.write(content)
    print("Patched build.gradle.kts")
else:
    print("Already patched")
