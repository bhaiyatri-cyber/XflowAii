with open('app/src/main/java/com/example/service/SchedulingWorker.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import android.app.NotificationChannel',
    'import android.app.NotificationChannel\nimport android.app.PendingIntent\nimport android.net.Uri'
)

old_alert = """    private fun sendAlertNotification(title: String, text: String, id: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    "xflow_alerts_vibrate",
                    "Alerts",
                    NotificationManager.IMPORTANCE_HIGH
                )
                val manager = context.getSystemService(NotificationManager::class.java)
                channel.enableVibration(true)
                channel.vibrationPattern = longArrayOf(0, 2000)
                manager?.createNotificationChannel(channel)
            }
            val notification = NotificationCompat.Builder(context, "xflow_alerts_vibrate")
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setVibrate(longArrayOf(0, 2000))
                .build()
            
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Ignore
        }
    }"""
new_alert = """    private fun sendAlertNotification(title: String, text: String, id: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    "xflow_alerts_vibrate",
                    "Alerts",
                    NotificationManager.IMPORTANCE_HIGH
                )
                val manager = context.getSystemService(NotificationManager::class.java)
                channel.enableVibration(true)
                channel.vibrationPattern = longArrayOf(0, 2000)
                manager?.createNotificationChannel(channel)
            }
            
            val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("xflow://home"))
            val pendingIntent = PendingIntent.getActivity(context, id, deepLinkIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

            val notification = NotificationCompat.Builder(context, "xflow_alerts_vibrate")
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setVibrate(longArrayOf(0, 2000))
                .build()
            
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Ignore
        }
    }"""
content = content.replace(old_alert, new_alert)

with open('app/src/main/java/com/example/service/SchedulingWorker.kt', 'w') as f:
    f.write(content)
