import re

with open('app/src/main/java/com/example/utils/PdfGenerator.kt', 'r') as f:
    content = f.read()

new_func = """
    suspend fun appendImagesToPdf(context: Context, existingFile: File, newImageUris: List<Uri>): Boolean = withContext(Dispatchers.IO) {
        if (newImageUris.isEmpty()) return@withContext false
        val pdfDocument = PdfDocument()
        try {
            var pageIndex = 1
            val fileDescriptor = android.os.ParcelFileDescriptor.open(existingFile, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
            val pdfRenderer = android.graphics.pdf.PdfRenderer(fileDescriptor)
            
            for (i in 0 until pdfRenderer.pageCount) {
                val rendererPage = pdfRenderer.openPage(i)
                val bitmap = Bitmap.createBitmap(rendererPage.width, rendererPage.height, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(android.graphics.Color.WHITE)
                rendererPage.render(bitmap, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                rendererPage.close()
                
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, pageIndex++).create()
                val page = pdfDocument.startPage(pageInfo)
                page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDocument.finishPage(page)
                bitmap.recycle()
            }
            pdfRenderer.close()
            fileDescriptor.close()

            for (uri in newImageUris) {
                val bitmap = getBitmap(context, uri) ?: continue
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, pageIndex++).create()
                val page = pdfDocument.startPage(pageInfo)
                page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDocument.finishPage(page)
                bitmap.recycle()
            }
            
            val tempFile = File(existingFile.parent, existingFile.name + ".tmp")
            pdfDocument.writeTo(FileOutputStream(tempFile))
            pdfDocument.close()
            
            if (existingFile.delete()) {
                tempFile.renameTo(existingFile)
            } else {
                tempFile.renameTo(existingFile)
            }
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        }
    }
"""

content = content.replace("fun getSavedPdfs", new_func + "\n    fun getSavedPdfs")

with open('app/src/main/java/com/example/utils/PdfGenerator.kt', 'w') as f:
    f.write(content)
