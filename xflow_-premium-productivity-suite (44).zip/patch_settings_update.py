import re

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

# Add import for Update icon
if "import androidx.compose.material.icons.filled.Update" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.Build", "import androidx.compose.material.icons.filled.Build\nimport androidx.compose.material.icons.filled.Update\nimport androidx.compose.ui.window.Dialog")

# Replace App Settings bottom sheet
old_sheet = """                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Build, title = "Theme & Appearance", onClick = { showAppSettings = false; onNavigateToThemeSettings() })
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }"""

new_sheet = """                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Build, title = "Theme & Appearance", onClick = { showAppSettings = false; onNavigateToThemeSettings() })
                }
                SettingsSection("") {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val prefs = context.getSharedPreferences("xflow_prefs", android.content.Context.MODE_PRIVATE)
                    val updateTime = prefs.getLong("update_time_${com.example.BuildConfig.VERSION_CODE}", 0L)
                    
                    // We need a live-updating string, so let's use a state that refreshes
                    var currentTime by remember { mutableStateOf(System.currentTimeMillis()) }
                    LaunchedEffect(Unit) {
                        while (true) {
                            kotlinx.coroutines.delay(60000)
                            currentTime = System.currentTimeMillis()
                        }
                    }
                    
                    val timeStr = if (updateTime > 0L) {
                        val diff = currentTime - updateTime
                        when {
                            diff < 60000 -> "updated just now"
                            diff < 3600000 -> "updated ${diff / 60000} min ago"
                            diff < 86400000 -> "updated ${diff / 3600000} hour(s) ago"
                            diff < 31536000000L -> "updated ${diff / 86400000} day(s) ago"
                            else -> "updated ${diff / 31536000000L} year(s) ago"
                        }
                    } else "updated recently"
                    
                    var showUpdateScreen by remember { mutableStateOf(false) }
                    
                    SettingsItem(icon = Icons.Default.Update, title = "App Update", subtitle = timeStr, onClick = { showUpdateScreen = true })
                    
                    if (showUpdateScreen) {
                        Dialog(
                            onDismissRequest = { showUpdateScreen = false },
                            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
                        ) {
                            WhatsNewScreen(onDismiss = { showUpdateScreen = false })
                        }
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }"""

content = content.replace(old_sheet, new_sheet)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)

