import re
with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

# Let's completely rewrite the gradle script snippet manually for cleanliness
content = re.sub(
    r'val ciGeminiKey.*?android \{', 
    """val ciGeminiKey = project.findProperty("GEMINI_API_KEY") as? String
if (ciGeminiKey != null) {
    val envFile = rootProject.file(".env")
    val envContent = if (envFile.exists()) envFile.readText() else ""
    if (!envContent.contains("GEMINI_API_KEY=")) {
        envFile.appendText("\\nGEMINI_API_KEY=$ciGeminiKey\\n")
    } else {
        val newContent = envContent.replace(Regex("GEMINI_API_KEY=.*"), "GEMINI_API_KEY=$ciGeminiKey")
        envFile.writeText(newContent)
    }
}

android {""", 
    content, 
    flags=re.DOTALL
)

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
