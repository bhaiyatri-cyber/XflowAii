with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

old_changes = """                    val changes = listOf(
                        "New XFlow Logo: Brand new official logo implemented across Splash Screen, Settings, About, Premium and Notifications.",
                        "Clean Home Header: Removed logo from the home screen for a more minimal layout.",
                        "Visual Polish: Updated app icon and internal graphics to match the new XFlow identity."
                    )"""

new_changes = """                    val changes = listOf(
                        "Corrected Logo: Updated the logo to the correct XFlow icon across the entire app.",
                        "Splash Screen & Settings: Added the new logo seamlessly to all areas (except the Home screen).",
                        "Notifications: Icons updated to match the new identity."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)
