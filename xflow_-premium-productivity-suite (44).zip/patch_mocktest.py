import re

with open('app/src/main/java/com/example/ui/MockTestAttemptScreen.kt', 'r') as f:
    content = f.read()

# Add kotlinx.coroutines.delay to imports
content = content.replace("import kotlinx.coroutines.launch", "import kotlinx.coroutines.launch\nimport kotlinx.coroutines.delay")

# Add timer state
timer_state = """    var showResults by remember { mutableStateOf(false) }
    var showAnalysis by remember { mutableStateOf(false) }
    var timeRemaining by remember { mutableIntStateOf(0) }
    var timeTaken by remember { mutableIntStateOf(0) }
    var isTimerRunning by remember { mutableStateOf(false) }

    // Timer logic
    LaunchedEffect(isTimerRunning, timeRemaining) {
        if (isTimerRunning && timeRemaining > 0) {
            delay(1000L)
            timeRemaining--
            timeTaken++
        } else if (isTimerRunning && timeRemaining == 0) {
            isTimerRunning = false
            // Auto submit
            var score = 0
            val test = mockTest ?: return@LaunchedEffect
            val testData = JSONObject(test.testDataJson)
            val questionsArray = testData.getJSONArray("questions")
            val totalQuestions = questionsArray.length()
            
            for (i in 0 until totalQuestions) {
                val q = questionsArray.getJSONObject(i)
                val ansIndex = q.getInt("answerIndex")
                if (userAnswers[i] == ansIndex) {
                    score++
                }
            }
            val ansJson = JSONObject()
            userAnswers.forEach { (k, v) -> ansJson.put(k.toString(), v) }
            ansJson.put("timeTaken", timeTaken)
            
            val updatedTest = test.copy(
                score = score,
                totalQuestions = totalQuestions,
                isCompleted = true,
                userAnswersJson = ansJson.toString()
            )
            scope.launch {
                dao.updateMockTest(updatedTest)
                mockTest = updatedTest
                showResults = true
            }
        }
    }
"""
content = content.replace("    var showResults by remember { mutableStateOf(false) }", timer_state)

# Initialize timer
init_timer = """                val ansMap = mutableMapOf<Int, Int>()
                ansJson.keys().forEach { key ->
                    if (key != "timeTaken") ansMap[key.toInt()] = ansJson.getInt(key)
                }
                userAnswers = ansMap
                if (ansJson.has("timeTaken")) timeTaken = ansJson.getInt("timeTaken")
            } else {
                val testData = JSONObject(test.testDataJson)
                val totalQ = testData.getJSONArray("questions").length()
                timeRemaining = totalQ * 60
                isTimerRunning = true
            }
"""
content = re.sub(r'val ansMap.*?\}', init_timer, content, flags=re.DOTALL, count=1)

# Display timer and handle manual submit
content = content.replace("Text(test.title", """Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(test.title, color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge)
                        if (!test.isCompleted) {
                            Text(String.format("%02d:%02d", timeRemaining / 60, timeRemaining % 60), color = XFlowAccent, fontWeight = FontWeight.Bold)
                        }
                    }""")

content = content.replace("""Text(test.title, color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge)""", "")

# Handle "showResults" rendering to render either "MockTestResults" or "MockTestAnalysis"
render_logic = """                if (showAnalysis) {
                    MockTestAnalysis(test, questionsArray, userAnswers, padding)
                } else if (showResults) {
                    MockTestResults(test, questionsArray, userAnswers, timeTaken, padding) { showAnalysis = true }
                } else {"""
content = content.replace("""                if (showResults) {
                    MockTestResults(test, questionsArray, userAnswers, padding)
                } else {""", render_logic)

# Manual Submit Logic Update (also storing time taken and stopping timer)
manual_submit = """                            Button(
                                onClick = {
                                    isTimerRunning = false
                                    var score = 0
                                    for (i in 0 until totalQuestions) {
                                        val q = questionsArray.getJSONObject(i)
                                        val ansIndex = q.getInt("answerIndex")
                                        if (userAnswers[i] == ansIndex) {
                                            score++
                                        }
                                    }
                                    
                                    val ansJson = JSONObject()
                                    userAnswers.forEach { (k, v) -> ansJson.put(k.toString(), v) }
                                    ansJson.put("timeTaken", timeTaken)
                                    
                                    val updatedTest = mockTest!!.copy(
                                        score = score,
                                        totalQuestions = totalQuestions,
                                        isCompleted = true,
                                        userAnswersJson = ansJson.toString()
                                    )
                                    scope.launch {
                                        dao.updateMockTest(updatedTest)
                                        mockTest = updatedTest
                                        showResults = true
                                    }
                                },"""
content = re.sub(r'Button\(\s*onClick = \{\s*var score = 0.*?\}\s*\}', manual_submit, content, flags=re.DOTALL)


# Results Screen Redesign
new_results = """@Composable
fun MockTestResults(test: MockTest, questionsArray: JSONArray, userAnswers: Map<Int, Int>, timeTaken: Int, padding: PaddingValues, onShowAnalysis: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = XFlowAccent, modifier = Modifier.size(80.dp))
        Spacer(modifier = Modifier.height(24.dp))
        Text("Test Completed!", color = XFlowTextPrimary, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(32.dp))
        
        Card(
            colors = CardDefaults.cardColors(containerColor = XFlowSurface),
            modifier = Modifier.fillMaxWidth(),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Your Score", color = XFlowTextSecondary, style = MaterialTheme.typography.titleMedium)
                Text("${test.score} / ${test.totalQuestions}", color = XFlowTextPrimary, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                
                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = XFlowSurfaceVariant)
                Spacer(modifier = Modifier.height(16.dp))
                
                Text("Time Taken", color = XFlowTextSecondary, style = MaterialTheme.typography.titleMedium)
                Text(String.format("%02d:%02d", timeTaken / 60, timeTaken % 60), color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = onShowAnalysis,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent)
        ) {
            Text("View Analysis", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MockTestAnalysis(test: MockTest, questionsArray: JSONArray, userAnswers: Map<Int, Int>, padding: PaddingValues) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "Analysis",
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        for (i in 0 until test.totalQuestions) {
            val q = questionsArray.getJSONObject(i)
            val qText = q.getString("q")
            val optionsArray = q.getJSONArray("options")
            val correctIndex = q.getInt("answerIndex")
            val selectedIndex = userAnswers[i] ?: -1
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Q${i + 1}: $qText", color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    for (j in 0 until optionsArray.length()) {
                        val optionText = optionsArray.getString(j)
                        val isCorrect = j == correctIndex
                        val isSelected = j == selectedIndex
                        
                        val textColor = when {
                            isCorrect -> Color(0xFF4CAF50)
                            isSelected && !isCorrect -> Color(0xFFF44336)
                            else -> XFlowTextSecondary
                        }
                        val icon = when {
                            isCorrect -> "✓"
                            isSelected && !isCorrect -> "✗"
                            else -> "•"
                        }
                        
                        Text(
                            text = "$icon $optionText",
                            color = textColor,
                            modifier = Modifier.padding(vertical = 4.dp),
                            fontWeight = if (isCorrect || isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}
"""

content = re.sub(r'@Composable\s*fun MockTestResults.*?\}\s*\}', new_results, content, flags=re.DOTALL)
content = content.replace("import androidx.compose.material.icons.automirrored.filled.ArrowBack", "import androidx.compose.material.icons.automirrored.filled.ArrowBack\nimport androidx.compose.material.icons.filled.CheckCircle")

with open('app/src/main/java/com/example/ui/MockTestAttemptScreen.kt', 'w') as f:
    f.write(content)
