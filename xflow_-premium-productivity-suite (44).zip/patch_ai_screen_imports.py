with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()

imports = """import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Edit
"""
content = content.replace("import androidx.compose.ui.graphics.SolidColor", "import androidx.compose.ui.graphics.SolidColor\n" + imports)

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)
