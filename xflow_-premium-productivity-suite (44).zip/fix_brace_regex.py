import re
with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()
content = re.sub(r'(\s*\}\s*\}\s*\}\s*\}\s*)(@Composable\s*fun OnlineAnimation\(\))', r'\1    }\n\2', content)
with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()
content = re.sub(r'(\s*\}\s*\}\s*\}\s*\}\s*)(@Composable\s*fun HistoryScreen\()', r'\1    }\n\2', content)
with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
