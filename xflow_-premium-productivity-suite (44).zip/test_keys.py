import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace('if (BuildConfig.GEMINI_API_KEY.isEmpty() || !BuildConfig.GEMINI_API_KEY.startsWith("AIza")) {', 'if (BuildConfig.GEMINI_API_KEY.isEmpty() || !BuildConfig.GEMINI_API_KEY.startsWith("AIza")) {')

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)

