import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

# Add context gathering
context_code = """
            isGenerating.value = true
            
            // Gather context
            var contextStr = ""
            try {
                val schedules = db.dao().getAllSchedulesSync()
                val history = db.dao().getAllHistorySync()
                val totalStudied = history.sumOf { it.timeStudiedSeconds }
                val hours = totalStudied / 3600
                val mins = (totalStudied % 3600) / 60
                val activeCount = schedules.count { it.isActive }
                contextStr = "USER CONTEXT: The user has active schedules: $activeCount. Total time studied: ${hours}h ${mins}m. Use this context to give personalized advice."
            } catch (e: Exception) {
                // Ignore context errors
            }
"""

content = content.replace("isGenerating.value = true", context_code)

system_prompt = 'systemInstruction = Content(parts = listOf(Part(text = "You are XFlow AI, a helpful assistant. You help users with study tips, app customization, productivity, and focus techniques. If the user asks to create a schedule, use the createSchedule function. If the user asks for a mock test, use the createMockTest function.")))'
new_system_prompt = 'systemInstruction = Content(parts = listOf(Part(text = "You are XFlow AI, a helpful assistant. You help users with study tips, productivity, and focus techniques. If the user asks to create a schedule, use the createSchedule function. If the user asks for a mock test, use the createMockTest function. $contextStr")))'

content = content.replace(system_prompt, new_system_prompt)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
