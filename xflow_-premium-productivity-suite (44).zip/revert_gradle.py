import re

with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

# We need to fall back to the env plugin parsing, because there's a conflict. Let's fix this properly.

content = content.replace('buildConfigField("String", "GEMINI_API_KEY", "\\"${project.findProperty(\\"GEMINI_API_KEY\\") ?: \\"\\"}\\"")', '')
with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
