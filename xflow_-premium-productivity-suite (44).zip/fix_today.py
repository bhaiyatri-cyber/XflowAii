with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

target1 = """    val todayHours: StateFlow<Float> = history.map { list ->
        val todayStart = System.currentTimeMillis() - (24 * 60 * 60 * 1000)
        list.filter { it.date > todayStart }.sumOf { it.timeStudiedSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)"""

replacement1 = """    val todayHours: StateFlow<Float> = history.map { list ->
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val todayStart = cal.timeInMillis
        list.filter { it.date > todayStart }.sumOf { it.timeStudiedSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)"""

content = content.replace(target1, replacement1)

target2 = """    val todayOvertimeHours: StateFlow<Float> = overtimeEntries.map { list ->
        val todayStart = System.currentTimeMillis() - (24 * 60 * 60 * 1000)
        list.filter { it.date > todayStart }.sumOf { it.overtimeSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)"""

replacement2 = """    val todayOvertimeHours: StateFlow<Float> = overtimeEntries.map { list ->
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val todayStart = cal.timeInMillis
        list.filter { it.date > todayStart }.sumOf { it.overtimeSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)"""

content = content.replace(target2, replacement2)

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(content)
print("Patched XFlowViewModel for midnight reset")
