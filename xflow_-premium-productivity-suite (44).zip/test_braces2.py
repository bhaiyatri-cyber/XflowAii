with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    text = f.read()

count = 0
for i, char in enumerate(text):
    if char == '{':
        count += 1
    elif char == '}':
        count -= 1
        if count < 0:
            print(f"Extra closing brace at index {i}")
            print("Context:")
            print(text[max(0, i-200):min(len(text), i+200)])
            break
