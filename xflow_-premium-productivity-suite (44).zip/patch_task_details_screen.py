import re

with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

# Make sure we import TimeUtils
if "import com.example.utils.TimeUtils" not in content:
    content = content.replace("import com.example.ui.theme.*", "import com.example.ui.theme.*\nimport com.example.utils.TimeUtils")

# Now change EditScheduleDialog's signature to include activeSchedules
dialog_old = """@Composable
fun EditScheduleDialog(schedule: com.example.data.Schedule, onDismiss: () -> Unit, onSave: (com.example.data.Schedule) -> Unit) {"""
dialog_new = """@Composable
fun EditScheduleDialog(schedule: com.example.data.Schedule, activeSchedules: List<com.example.data.Schedule>, onDismiss: () -> Unit, onSave: (com.example.data.Schedule) -> Unit) {"""
content = content.replace(dialog_old, dialog_new)

# Update the call site
call_old = """        if (showEditDialog && schedule != null) {
            EditScheduleDialog(
                schedule = schedule,
                onDismiss = { showEditDialog = false },
                onSave = { updatedSchedule ->"""
call_new = """        if (showEditDialog && schedule != null) {
            EditScheduleDialog(
                schedule = schedule,
                activeSchedules = schedules,
                onDismiss = { showEditDialog = false },
                onSave = { updatedSchedule ->"""
content = content.replace(call_old, call_new)

# Add validation in EditScheduleDialog save button
save_old = """                    Button(
                        onClick = {
                            if (subject.isNotBlank()) {
                                onSave(schedule.copy("""

save_new = """                    Button(
                        onClick = {
                            if (subject.isNotBlank()) {
                                if (!schedule.isDurationMode) {
                                    val newStart = TimeUtils.timeToMinutes(startTimeStr)
                                    val newEnd = TimeUtils.timeToMinutes(endTimeStr)
                                    if (newEnd <= newStart) {
                                        Toast.makeText(context, "End time must be after start time", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    if (TimeUtils.hasTimeOverlap(startTimeStr, endTimeStr, schedule.id, activeSchedules)) {
                                        Toast.makeText(context, "This time overlaps with another schedule", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                }
                                onSave(schedule.copy("""

content = content.replace(save_old, save_new)

with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
