with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()
content = content.replace('"${context.packageName}.fileprovider"', 'BuildConfig.APPLICATION_ID + ".fileprovider"')
with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)
