#!/bin/bash
sed -i 's/val bookColors = listOf(accent/val bookColors = listOf(XFlowAccent/g' app/src/main/java/com/example/ui/HomeScreen.kt
