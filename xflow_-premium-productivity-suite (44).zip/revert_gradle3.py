import re

with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

# Revert local.properties since it's breaking something
content = re.sub(r'    val localProps = rootProject.file\("local\.properties"\)\n.*?    }', '', content, flags=re.DOTALL)

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
