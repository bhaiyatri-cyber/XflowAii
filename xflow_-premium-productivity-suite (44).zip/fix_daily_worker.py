with open('app/src/main/java/com/example/service/DailySummaryWorker.kt', 'r') as f:
    content = f.read()

premium_check = """
            val prefs = context.getSharedPreferences("xflow_prefs", Context.MODE_PRIVATE)
            val isPremium = prefs.getBoolean("is_premium", false)
            
            if (!isPremium) {
                return@withContext Result.success()
            }
"""

content = content.replace(
    'val db = XFlowDatabase.getDatabase(context)',
    premium_check + '\n            val db = XFlowDatabase.getDatabase(context)'
)

with open('app/src/main/java/com/example/service/DailySummaryWorker.kt', 'w') as f:
    f.write(content)
