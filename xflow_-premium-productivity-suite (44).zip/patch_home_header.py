import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('import androidx.compose.ui.text.font.FontWeight', 'import androidx.compose.ui.text.font.FontWeight\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.ui.draw.clip')

old_header = """    Text(
        text = "$icon ${SimpleDateFormat(format, Locale.getDefault()).format(now)}",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = XFlowAccent
    )"""

new_header = """    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.app_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "$icon ${SimpleDateFormat(format, Locale.getDefault()).format(now)}",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = XFlowAccent
        )
    }"""

content = content.replace(old_header, new_header)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
