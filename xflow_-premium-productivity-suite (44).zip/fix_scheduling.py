with open('app/src/main/java/com/example/service/SchedulingWorker.kt', 'r') as f:
    content = f.read()

# Update channel
content = content.replace(
    'val channel = NotificationChannel(\n                    "xflow_alerts",',
    'val channel = NotificationChannel(\n                    "xflow_alerts_vibrate",'
)
content = content.replace(
    'manager?.createNotificationChannel(channel)',
    'channel.enableVibration(true)\n                channel.vibrationPattern = longArrayOf(0, 2000)\n                manager?.createNotificationChannel(channel)'
)

# Update builder
content = content.replace(
    'val notification = NotificationCompat.Builder(context, "xflow_alerts")',
    'val notification = NotificationCompat.Builder(context, "xflow_alerts_vibrate")'
)

content = content.replace(
    '.setDefaults(NotificationCompat.DEFAULT_ALL)',
    '.setDefaults(NotificationCompat.DEFAULT_ALL)\n                .setVibrate(longArrayOf(0, 2000))'
)

with open('app/src/main/java/com/example/service/SchedulingWorker.kt', 'w') as f:
    f.write(content)
