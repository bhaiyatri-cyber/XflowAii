#!/bin/bash
sed -i '/val isPremium/a\
\
    private val _themeColor = kotlinx.coroutines.flow.MutableStateFlow(prefs.getLong("theme_color", 0xFF00E5FF))\
    val themeColor: StateFlow<Long> = _themeColor\
\
    fun updateThemeColor(color: Long) {\
        prefs.edit().putLong("theme_color", color).apply()\
        _themeColor.value = color\
    }' app/src/main/java/com/example/ui/XFlowViewModel.kt
