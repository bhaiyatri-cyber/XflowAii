with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace('versionCode = 72', 'versionCode = 75').replace('versionName = "72.0"', 'versionName = "75.0"')

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
