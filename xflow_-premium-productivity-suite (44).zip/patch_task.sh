sed -i '80,131d' app/src/main/java/com/example/ui/TaskDetailsScreen.kt
sed -i '/var showCompleteDialog by remember { mutableStateOf(false) }/d' app/src/main/java/com/example/ui/TaskDetailsScreen.kt
