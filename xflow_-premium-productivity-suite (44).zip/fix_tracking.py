with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

# Change channel ID
content = content.replace(
    'private val ALERT_CHANNEL_ID = "AlertChannel"',
    'private val ALERT_CHANNEL_ID = "xflow_alerts_vibrate"'
)

# Update createNotificationChannel
content = content.replace(
    'manager.createNotificationChannel(alertChannel)',
    'alertChannel.enableVibration(true)\n            alertChannel.vibrationPattern = longArrayOf(0, 2000)\n            manager.createNotificationChannel(alertChannel)'
)

# Update sendAlertNotification
content = content.replace(
    '.setAutoCancel(true)',
    '.setAutoCancel(true)\n                .setVibrate(longArrayOf(0, 2000))'
)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)
