with open('app/src/main/java/com/example/ui/Navigation.kt', 'r') as f:
    content = f.read()

target = """                onNavigateToChatGPT = { navController.navigate(Routes.CHATGPT) }"""
replacement = """                onNavigateToChatGPT = { navController.navigate(Routes.CHATGPT) },
                onNavigateToDailyReport = { navController.navigate(Routes.DAILY_REPORT) }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/ui/Navigation.kt', 'w') as f:
    f.write(content)
print("Patched Navigation.kt again")
