with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace('versionCode = 71', 'versionCode = 72').replace('versionName = "71.0"', 'versionName = "72.0"')

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)

