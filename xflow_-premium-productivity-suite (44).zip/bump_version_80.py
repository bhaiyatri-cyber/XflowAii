with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace('versionCode = 75', 'versionCode = 80').replace('versionName = "75.0"', 'versionName = "80.0"')

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
