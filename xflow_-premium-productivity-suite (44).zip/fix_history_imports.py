with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

if 'import androidx.compose.ui.graphics.graphicsLayer' not in content:
    content = content.replace('import androidx.compose.ui.Modifier', 'import androidx.compose.ui.Modifier\nimport androidx.compose.ui.graphics.graphicsLayer\nimport androidx.compose.ui.unit.sp')
    
    with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
        f.write(content)
