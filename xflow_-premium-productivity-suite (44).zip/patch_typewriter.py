import re
with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'r') as f:
    content = f.read()

old_typewriter = """@Composable
fun TypewriterText(text: String, modifier: Modifier = Modifier) {
    var textToDisplay by remember { mutableStateOf("") }
    LaunchedEffect(text) {
        if (textToDisplay == text) return@LaunchedEffect
        textToDisplay = ""
        for (i in text.indices) {
            textToDisplay += text[i]
            delay(15) // Natural typing speed
        }
    }
    Row(modifier = modifier) {
        Text(
            text = textToDisplay,
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.bodyLarge
        )
        if (textToDisplay.length < text.length) {
            Box(
                modifier = Modifier
                    .padding(start = 2.dp, top = 4.dp)
                    .size(width = 8.dp, height = 16.dp)
                    .background(XFlowAccent)
            )
        }
    }
}"""

new_typewriter = """import androidx.compose.runtime.saveable.rememberSaveable

@Composable
fun TypewriterText(text: String, modifier: Modifier = Modifier) {
    var textToDisplay by remember { mutableStateOf("") }
    var isFinished by rememberSaveable(text) { mutableStateOf(false) }
    var cursorVisible by remember { mutableStateOf(true) }

    LaunchedEffect(text) {
        if (isFinished) {
            textToDisplay = text
            return@LaunchedEffect
        }
        textToDisplay = ""
        
        val cursorJob = kotlinx.coroutines.launch {
            while (true) {
                cursorVisible = !cursorVisible
                delay(300)
            }
        }
        
        val chars = text.toCharArray()
        for (i in chars.indices) {
            textToDisplay += chars[i]
            delay(15) 
        }
        
        isFinished = true
        cursorJob.cancel()
        cursorVisible = false
    }

    Text(
        text = textToDisplay + if (!isFinished && cursorVisible) " ▌" else "",
        color = XFlowTextPrimary,
        style = MaterialTheme.typography.bodyLarge,
        modifier = modifier
    )
}"""

content = content.replace(old_typewriter, new_typewriter.replace("import androidx.compose.runtime.saveable.rememberSaveable\n\n", ""))
if "import androidx.compose.runtime.saveable.rememberSaveable" not in content:
    content = content.replace("import androidx.compose.runtime.remember", "import androidx.compose.runtime.remember\nimport androidx.compose.runtime.saveable.rememberSaveable")

with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'w') as f:
    f.write(content)

