with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    text = f.read()

start_idx = text.find("fun AllTimeHistoryScreen")

count = 0
for i in range(start_idx, len(text)):
    char = text[i]
    if char == '{':
        count += 1
    elif char == '}':
        count -= 1
        if count < 0:
            print(f"Extra closing brace inside AllTimeHistoryScreen at index {i}")
            print(text[max(start_idx, i-50):min(len(text), i+50)])
            print("---")
            break
