import re

# 1. Fix AiScreen.kt
with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    ai_screen = f.read()

drawer_chatbot = """                NavigationDrawerItem(
                    label = { Text("Chatbot", color = XFlowTextPrimary) },
                    selected = selectedItem == "Chatbot",
                    onClick = {
                        selectedItem = "Chatbot"
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = XFlowSurfaceVariant,
                        unselectedContainerColor = Color.Transparent
                    )
                )
                NavigationDrawerItem(
                    label = { Text("AI Mock Tests (Pro)", color = XFlowTextPrimary) },"""
drawer_mock = """                NavigationDrawerItem(
                    label = { Text("AI Mock Tests (Pro)", color = XFlowTextPrimary) },"""
ai_screen = ai_screen.replace(drawer_chatbot, drawer_mock)

scaffold_body_new = """            Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
                if (selectedItem == "Chat") {
                    ChatContent(viewModel = viewModel)
                } else if (selectedItem == "Chatbot") {
                    ChatbotContent()
                } else {
                    MockTestsContent(viewModel = viewModel, navController = navController)
                }
            }"""
scaffold_body = """            Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
                if (selectedItem == "Chat") {
                    ChatContent(viewModel = viewModel)
                } else {
                    MockTestsContent(viewModel = viewModel, navController = navController)
                }
            }"""
ai_screen = ai_screen.replace(scaffold_body_new, scaffold_body)

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(ai_screen)

# 2. Fix ChatbotScreen.kt
with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'r') as f:
    chatbot = f.read()

# Add ChatbotScreen wrapper
wrapper = """
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Chatbot", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            ChatbotContent()
        }
    }
}
"""
if "fun ChatbotScreen" not in chatbot:
    chatbot += wrapper
with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'w') as f:
    f.write(chatbot)

# 3. Update SettingsScreen.kt
with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    settings = f.read()

settings = settings.replace('fun SettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToPdf: () -> Unit, onNavigateToPermissions: () -> Unit, onNavigateToAbout: () -> Unit, onNavigateToBackup: () -> Unit, onNavigateToThemeSettings: () -> Unit, onNavigateToOvertime: () -> Unit, onNavigateToAiTest: () -> Unit)', 'fun SettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit, onNavigateToPdf: () -> Unit, onNavigateToPermissions: () -> Unit, onNavigateToAbout: () -> Unit, onNavigateToBackup: () -> Unit, onNavigateToThemeSettings: () -> Unit, onNavigateToOvertime: () -> Unit, onNavigateToAiTest: () -> Unit, onNavigateToChatbot: () -> Unit)')
settings = settings.replace('SettingsItem(icon = androidx.compose.material.icons.Icons.Default.Build, title = "XFlow Ai Test", onClick = onNavigateToAiTest)', 'SettingsItem(icon = androidx.compose.material.icons.Icons.Default.Build, title = "XFlow Ai Test", onClick = onNavigateToAiTest)\n                SettingsItem(icon = androidx.compose.material.icons.Icons.AutoMirrored.Filled.Message, title = "Chatbot", onClick = onNavigateToChatbot)')
settings = settings.replace('1.0.0 (Build 1)', '1.1.1 (Build 1)')

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(settings)

# 4. Update Navigation.kt
with open('app/src/main/java/com/example/ui/Navigation.kt', 'r') as f:
    nav = f.read()

nav = nav.replace('const val AI_TEST = "ai_test"', 'const val AI_TEST = "ai_test"\n    const val CHATBOT = "chatbot"')
nav = nav.replace('onNavigateToAiTest = { navController.navigate(Routes.AI_TEST) }', 'onNavigateToAiTest = { navController.navigate(Routes.AI_TEST) },\n                onNavigateToChatbot = { navController.navigate(Routes.CHATBOT) }')
nav = nav.replace('composable(Routes.AI_TEST) {', 'composable(Routes.CHATBOT) {\n            ChatbotScreen(onBack = { navController.popBackStack() })\n        }\n        composable(Routes.AI_TEST) {')

with open('app/src/main/java/com/example/ui/Navigation.kt', 'w') as f:
    f.write(nav)

print("Updates applied")
