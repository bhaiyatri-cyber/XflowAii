import re

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()

# Import AutoAwesome
content = content.replace(
    'import androidx.compose.material.icons.filled.Menu',
    'import androidx.compose.material.icons.filled.Menu\nimport androidx.compose.material.icons.filled.AutoAwesome\nimport androidx.compose.animation.core.*'
)

# Add imePadding
content = content.replace(
    'Column(modifier = Modifier.fillMaxSize()) {',
    'Column(modifier = Modifier.fillMaxSize().imePadding()) {'
)

# Update ChatBubble for AI messages
old_bubble = """    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clip(RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ))
                .background(if (isUser) XFlowAccent else XFlowSurfaceVariant)
                .padding(12.dp)
        ) {
            Text(
                text = displayedText,
                color = if (isUser) Color.White else XFlowTextPrimary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }"""

new_bubble = """    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        if (isUser) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = 16.dp,
                        bottomEnd = 4.dp
                    ))
                    .background(XFlowAccent)
                    .padding(12.dp)
            ) {
                Text(
                    text = displayedText,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth(0.95f).padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "AI",
                    tint = XFlowAccent,
                    modifier = Modifier.size(24.dp).padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = displayedText,
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }"""
content = content.replace(old_bubble, new_bubble)

# Replace CircularProgressIndicator with custom typing indicator
old_loading = """                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = XFlowAccent)"""
new_loading = """                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "AI",
                                tint = XFlowAccent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            TypingIndicator()
                        }"""
content = content.replace(old_loading, new_loading)

# Add TypingIndicator composable
typing_indicator = """
@Composable
fun TypingIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "")
    val alpha1 by infiniteTransition.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(400, delayMillis = 0), repeatMode = RepeatMode.Reverse),
        label = ""
    )
    val alpha2 by infiniteTransition.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(400, delayMillis = 200), repeatMode = RepeatMode.Reverse),
        label = ""
    )
    val alpha3 by infiniteTransition.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(400, delayMillis = 400), repeatMode = RepeatMode.Reverse),
        label = ""
    )
    
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha1)))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha2)))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(XFlowAccent.copy(alpha = alpha3)))
    }
}
"""
content = content + typing_indicator

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)
