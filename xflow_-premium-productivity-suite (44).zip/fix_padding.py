import re

# Fix AiScreen.kt
with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    ai = f.read()
ai = ai.replace('Box(modifier = Modifier.padding(padding)) {', 'Box(modifier = Modifier.padding(padding).consumeWindowInsets(padding).imePadding()) {')
ai = ai.replace('Column(modifier = Modifier.fillMaxSize().imePadding()) {', 'Column(modifier = Modifier.fillMaxSize()) {')
with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(ai)

# Fix ChatbotScreen.kt
with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'r') as f:
    chatbot = f.read()
chatbot = chatbot.replace('Box(modifier = Modifier.padding(paddingValues)) {', 'Box(modifier = Modifier.padding(paddingValues).consumeWindowInsets(paddingValues).imePadding()) {')
chatbot = chatbot.replace('Column(modifier = Modifier.fillMaxSize().imePadding()) {', 'Column(modifier = Modifier.fillMaxSize()) {')
with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'w') as f:
    f.write(chatbot)

print("Padding fixed")
