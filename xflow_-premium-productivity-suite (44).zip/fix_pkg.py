with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

import re
pkg_match = re.search(r'package com\.example\.ui', content)
if pkg_match and pkg_match.start() != 0:
    content = content[:pkg_match.start()] + content[pkg_match.end():]
    content = 'package com.example.ui\n' + content

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
