import re
with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Delete duplicate StatCard and ScheduleCard at the end
content = re.sub(r'@Composable\s*fun StatCard\(\s*modifier: Modifier = Modifier,\s*title: String = "",\s*value: String,\s*isAccent: Boolean = false,\s*text: String = "",\s*icon: ImageVector = Icons.Default.Add\s*\)\s*\{.*?\}\s*\}', '', content, flags=re.DOTALL)
content = re.sub(r'@Composable\s*fun ScheduleCard\(schedule: Schedule, onClick: \(\) -> Unit = \{\}\)\s*\{.*?\}\s*\}', '', content, flags=re.DOTALL)

# Update the FIRST StatCard
new_stat_card = """@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    title: String = "",
    value: String,
    isAccent: Boolean = false,
    text: String = "",
    icon: androidx.compose.ui.graphics.vector.ImageVector = androidx.compose.material.icons.Icons.Default.Add
) {
    androidx.compose.material3.Card(
        modifier = modifier,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = if (isAccent) com.example.ui.theme.XFlowAccent.copy(alpha = 0.1f) else com.example.ui.theme.XFlowSurface)
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = Modifier.padding(16.dp)
        ) {
            androidx.compose.material3.Text(
                text = title.ifEmpty { text },
                style = androidx.compose.material3.MaterialTheme.typography.labelMedium,
                color = com.example.ui.theme.XFlowTextSecondary
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(8.dp))
            androidx.compose.material3.Text(
                text = value,
                style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = if (isAccent) com.example.ui.theme.XFlowAccent else com.example.ui.theme.XFlowTextPrimary
            )
        }
    }
}"""
content = re.sub(r'@Composable\s*fun StatCard\(title: String = "", value: String, modifier: Modifier = Modifier\)\s*\{.*?\}\s*\}', new_stat_card, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
