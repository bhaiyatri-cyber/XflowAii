with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace('alias(libs.plugins.google.services)\n}', 'alias(libs.plugins.google.services)\n  alias(libs.plugins.kotlin.serialization)\n}')

deps_addition = """  implementation(libs.retrofit)
  implementation(libs.kotlinx.serialization.json)
  implementation(libs.retrofit.converter.serialization)"""
content = content.replace('  implementation(libs.retrofit)', deps_addition)

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
