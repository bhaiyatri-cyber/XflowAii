import re

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

# Add imports if needed
if 'import android.content.SharedPreferences' not in content:
    content = content.replace('import android.content.IntentFilter', 'import android.content.IntentFilter\nimport android.content.SharedPreferences')

# Add property
old_init = """    private val CHANNEL_ID = "xflow_update_channel\""""
new_init = """    private val CHANNEL_ID = "xflow_update_channel"
    private val prefs: SharedPreferences = context.getSharedPreferences("xflow_updates", Context.MODE_PRIVATE)"""
if 'private val prefs' not in content:
    content = content.replace(old_init, new_init)

# Update check logic
old_check = """                    if (latestVersion > currentVersion) {
                        val assets = json.getJSONArray("assets")
                        if (assets.length() > 0) {
                            val downloadUrl = assets.getJSONObject(0).getString("browser_download_url")
                            withContext(Dispatchers.Main) {
                                startDownload(downloadUrl)
                            }
                        }
                    }"""

new_check = """                    val lastDownloadedVersion = prefs.getInt("last_downloaded_version", 0)
                    if (latestVersion > currentVersion && latestVersion > lastDownloadedVersion) {
                        val assets = json.getJSONArray("assets")
                        if (assets.length() > 0) {
                            val downloadUrl = assets.getJSONObject(0).getString("browser_download_url")
                            
                            // Save this version so we don't download it again if user doesn't install it or if versionCode wasn't bumped
                            prefs.edit().putInt("last_downloaded_version", latestVersion).apply()
                            
                            withContext(Dispatchers.Main) {
                                startDownload(downloadUrl)
                            }
                        }
                    } else if (latestVersion > currentVersion && latestVersion <= lastDownloadedVersion) {
                        Log.d(TAG, "Already downloaded version $latestVersion but not installed. Skipping automatic download.")
                        // We could show the install notification again here if the file exists
                        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                        if (dir != null && dir.exists()) {
                            val file = java.io.File(dir, "update.apk")
                            if (file.exists()) {
                                // The file is already here, just show the notification
                                showInstallNotification()
                            }
                        }
                    }"""
content = content.replace(old_check, new_check)

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)
