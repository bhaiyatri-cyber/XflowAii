#!/bin/bash
cat << 'INNER_EOF' > tmp_picker.kt
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                val maxWidth = constraints.maxWidth.toFloat()
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color.hsv(0f, 1f, 1f),
                                    Color.hsv(60f, 1f, 1f),
                                    Color.hsv(120f, 1f, 1f),
                                    Color.hsv(180f, 1f, 1f),
                                    Color.hsv(240f, 1f, 1f),
                                    Color.hsv(300f, 1f, 1f),
                                    Color.hsv(360f, 1f, 1f)
                                )
                            )
                        )
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                if (!isPremium) {
                                    showPremiumDialog = true
                                    return@detectDragGestures
                                }
                                val position = change.position.x.coerceIn(0f, maxWidth)
                                customHue = (position / maxWidth) * 360f
                            }
                        }
                        .clickable {
                            if (!isPremium) {
                                showPremiumDialog = true
                            }
                        }
                ) {
                    if (isPremium) {
                        Box(
                            modifier = Modifier
                                .offset(
                                    x = ((customHue / 360f) * (this@BoxWithConstraints.maxWidth.value - 24)).dp,
                                    y = 8.dp
                                )
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(customColor)
                                .border(2.dp, Color.White, CircleShape)
                        )
                    }
                }
            }
INNER_EOF
awk '
/Box\(/ {
    if (in_box == 0 && getline_done == 0) {
        in_box = 1
        print "// INSERT_PICKER_HERE"
        next
    }
}
in_box == 1 {
    if (/Spacer\(modifier = Modifier.height\(16.dp\)\)/) {
        in_box = 0
        getline_done = 1
        print
    }
    next
}
{ print }
' app/src/main/java/com/example/ui/ThemeSettingsScreen.kt > temp.kt

sed -e '/\/\/ INSERT_PICKER_HERE/r tmp_picker.kt' -e '/\/\/ INSERT_PICKER_HERE/d' temp.kt > app/src/main/java/com/example/ui/ThemeSettingsScreen.kt
