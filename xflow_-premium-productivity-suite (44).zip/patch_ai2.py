import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

# Replace any references to BuildConfig.GEMINI_API_KEY with just checking if it is valid
# But ensure that we fallback correctly.

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
