import re

with open('app/src/main/java/com/example/utils/TimeUtils.kt', 'r') as f:
    content = f.read()

new_fun = """    fun formatHours(hours: Float): String {
        val totalMinutes = (hours * 60).toInt()
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }
}"""

content = content.replace("}", new_fun, 1) # This might not be right, let's just append it before the last brace.

with open('app/src/main/java/com/example/utils/TimeUtils.kt', 'w') as f:
    f.write(content)
