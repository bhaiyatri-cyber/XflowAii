import re

with open('app/src/main/java/com/example/ui/ChatGPTScreen.kt', 'r') as f:
    content = f.read()

old_settings = """                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true"""

new_settings = """                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true"""

content = content.replace(old_settings, new_settings)

with open('app/src/main/java/com/example/ui/ChatGPTScreen.kt', 'w') as f:
    f.write(content)

