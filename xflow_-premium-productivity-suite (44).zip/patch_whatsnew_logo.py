import re

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('import androidx.compose.foundation.layout.*', 'import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.ui.draw.clip\nimport androidx.compose.foundation.shape.RoundedCornerShape')

old_icon = """            Icon(
                imageVector = Icons.Default.WorkspacePremium,
                contentDescription = null,
                tint = XFlowAccent,
                modifier = Modifier.size(120.dp)
            )"""

new_icon = """            Image(
                painter = painterResource(id = R.drawable.app_logo),
                contentDescription = "Logo",
                modifier = Modifier.size(120.dp).clip(RoundedCornerShape(24.dp))
            )"""

content = content.replace(old_icon, new_icon)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)
