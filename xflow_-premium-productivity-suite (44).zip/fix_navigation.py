with open('app/src/main/java/com/example/ui/Navigation.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'const val BACKUP = "backup"',
    'const val BACKUP = "backup"\n    const val OVERTIME = "overtime"'
)

content = content.replace(
    'onNavigateToBackup = { navController.navigate(Routes.BACKUP) }',
    'onNavigateToBackup = { navController.navigate(Routes.BACKUP) },\n                onNavigateToOvertime = { navController.navigate(Routes.OVERTIME) }'
)

content = content.replace(
    'composable(Routes.BACKUP) {',
    'composable(Routes.OVERTIME) {\n            OvertimeScreen(viewModel = viewModel, onBack = { navController.popBackStack() })\n        }\n        composable(Routes.BACKUP) {'
)

with open('app/src/main/java/com/example/ui/Navigation.kt', 'w') as f:
    f.write(content)
