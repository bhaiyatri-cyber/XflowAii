import re

with open('app/src/main/java/com/example/utils/BackupRestoreUtils.kt', 'r') as f:
    content = f.read()

# ADD EXPORT LOGIC
# 1. schedules overtimeSeconds
content = content.replace(
    'obj.put("elapsedSeconds", s.elapsedSeconds)',
    'obj.put("elapsedSeconds", s.elapsedSeconds)\n                obj.put("overtimeSeconds", s.overtimeSeconds)'
)

# 2. overtime entries export
overtime_export_logic = """
            val overtime = kotlinx.coroutines.flow.first(dao.getAllOvertimeEntries())
            val overtimeArray = JSONArray()
            overtime.forEach { o ->
                val obj = JSONObject()
                obj.put("id", o.id)
                obj.put("scheduleId", o.scheduleId)
                obj.put("subject", o.subject)
                obj.put("overtimeSeconds", o.overtimeSeconds)
                obj.put("date", o.date)
                overtimeArray.put(obj)
            }
            rootObj.put("overtime_entries", overtimeArray)
"""

content = content.replace(
    'rootObj.put("history", historyArray)',
    'rootObj.put("history", historyArray)' + overtime_export_logic
)

# ADD IMPORT LOGIC
# 1. schedule overtimeSeconds
content = content.replace(
    'elapsedSeconds = obj.getInt("elapsedSeconds"),',
    'elapsedSeconds = obj.getInt("elapsedSeconds"),\n                            overtimeSeconds = obj.optInt("overtimeSeconds", 0),'
)

# 2. overtime entries import
overtime_import_logic = """
            if (rootObj.has("overtime_entries")) {
                val overtimeArray = rootObj.getJSONArray("overtime_entries")
                for (i in 0 until overtimeArray.length()) {
                    val obj = overtimeArray.getJSONObject(i)
                    dao.insertOvertimeEntry(
                        com.example.data.OvertimeEntry(
                            id = obj.getInt("id"),
                            scheduleId = obj.getInt("scheduleId"),
                            subject = obj.getString("subject"),
                            overtimeSeconds = obj.getInt("overtimeSeconds"),
                            date = obj.getLong("date")
                        )
                    )
                }
            }
"""

content = content.replace(
    'if (rootObj.has("history")) {',
    overtime_import_logic + '\n            if (rootObj.has("history")) {'
)

# Add import for kotlinx.coroutines.flow.first
if 'import kotlinx.coroutines.flow.first' not in content:
    content = content.replace(
        'import kotlinx.coroutines.withContext',
        'import kotlinx.coroutines.withContext\nimport kotlinx.coroutines.flow.first'
    )


with open('app/src/main/java/com/example/utils/BackupRestoreUtils.kt', 'w') as f:
    f.write(content)
