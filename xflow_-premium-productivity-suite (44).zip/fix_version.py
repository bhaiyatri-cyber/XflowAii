with open('app/build.gradle.kts', 'r') as f:
    content = f.read()
content = content.replace('versionCode = 61', 'versionCode = 60').replace('versionName = "61.0"', 'versionName = "60.0"')
with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
