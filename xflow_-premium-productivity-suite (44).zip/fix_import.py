with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    lines = f.readlines()

if lines[0].startswith('import'):
    lines.insert(2, lines.pop(0))

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.writelines(lines)
