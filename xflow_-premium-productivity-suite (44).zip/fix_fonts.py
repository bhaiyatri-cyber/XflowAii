with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'fontSize = 22.sp,',
    'fontSize = 18.sp,'
)

old_text = 'Text("Study Plan", color = XFlowTextPrimary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)'
new_text = 'Text("Study Plan", color = XFlowTextPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)'
content = content.replace(old_text, new_text)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
