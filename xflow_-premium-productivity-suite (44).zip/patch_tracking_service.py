with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

target1 = """                val currentTotalMins = currentHour * 60 + currentMin

                                for (schedule in activeSchedules) {"""

replacement1 = """                val currentTotalMins = currentHour * 60 + currentMin
                
                var hasActiveScheduledTask = false
                for (s in activeSchedules) {
                    if (!s.isDurationMode) {
                        try {
                            val p1 = s.startTimeStr.split(":")
                            val sMins = p1[0].toInt() * 60 + p1[1].toInt()
                            val p2 = s.endTimeStr.split(":")
                            val eMins = p2[0].toInt() * 60 + p2[1].toInt()
                            if (currentTotalMins >= sMins && currentTotalMins < eMins) {
                                hasActiveScheduledTask = true
                                break
                            }
                        } catch (e: Exception) {}
                    }
                }

                                for (schedule in activeSchedules) {"""

if 'hasActiveScheduledTask' not in content:
    content = content.replace(target1, replacement1)

target2 = """                        if (wasActiveAtEnd) {
                            shouldTrack = true
                            autoComplete = false
                        } else {"""

replacement2 = """                        if (wasActiveAtEnd && !hasActiveScheduledTask) {
                            shouldTrack = true
                            autoComplete = false
                        } else {"""

content = content.replace(target2, replacement2)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)
print("Patched TrackingService")
