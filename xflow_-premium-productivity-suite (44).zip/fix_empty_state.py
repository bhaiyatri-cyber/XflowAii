import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Add history state
content = content.replace(
    'val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()',
    'val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()\n    val history by viewModel.history.collectAsStateWithLifecycle()'
)

# Update empty state
old_empty_state = """                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No active schedules", color = XFlowTextSecondary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = handleCreateClick,
                            colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowAccent)
                        ) {
                            Text("Create one now")
                        }
                    }"""

new_empty_state = """                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (history.isNotEmpty()) {
                            Text("All caught up for today! 🎉", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Great job crushing your tasks.", color = XFlowTextSecondary)
                            Spacer(modifier = Modifier.height(24.dp))
                            Button(
                                onClick = handleCreateClick,
                                colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowAccent)
                            ) {
                                Text("Add another task")
                            }
                        } else {
                            Text("No active schedules", color = XFlowTextSecondary)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = handleCreateClick,
                                colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowAccent)
                            ) {
                                Text("Create one now")
                            }
                        }
                    }"""

content = content.replace(old_empty_state, new_empty_state)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
