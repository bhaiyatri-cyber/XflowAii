with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

import re

online_anim = """@Composable
fun OnlineAnimation() {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(4000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        )
    )
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(XFlowSurfaceVariant.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        val accent = XFlowAccent
        
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(accent)
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .androidx.compose.ui.draw.rotate(rotation)
            ) {
                val appColors = listOf(
                    androidx.compose.ui.graphics.Color(0xFF4285F4),
                    androidx.compose.ui.graphics.Color(0xFF34A853),
                    androidx.compose.ui.graphics.Color(0xFFFBBC05),
                    androidx.compose.ui.graphics.Color(0xFFEA4335)
                )
                
                Box(modifier = Modifier.size(12.dp).align(Alignment.TopCenter).clip(RoundedCornerShape(3.dp)).background(appColors[0]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.CenterEnd).clip(RoundedCornerShape(3.dp)).background(appColors[1]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.BottomCenter).clip(RoundedCornerShape(3.dp)).background(appColors[2]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.CenterStart).clip(RoundedCornerShape(3.dp)).background(appColors[3]))
            }
        }
    }
}"""

pattern = r'@Composable\s*fun OnlineAnimation\(\)\s*\{.*?(?=@Composable\s*fun OfflineIllustration)'
new_content = re.sub(pattern, online_anim + '\n\n', content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(new_content)
