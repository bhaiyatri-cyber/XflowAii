import re

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()

# Make the chat view premium
content = content.replace('ChatContent(viewModel)', 'val isPremium by xFlowViewModel.isPremium.collectAsStateWithLifecycle()\n                    ChatContent(viewModel, isPremium)')
content = content.replace('fun ChatContent(viewModel: AiViewModel) {', 'fun ChatContent(viewModel: AiViewModel, isPremium: Boolean) {')

chat_input_old = """        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask anything or 'Create a mock test'...") },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XFlowAccent,
                    unfocusedBorderColor = XFlowSurfaceVariant,
                    focusedTextColor = XFlowTextPrimary
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (inputText.isNotBlank() && !isGenerating) {
                        viewModel.sendMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(XFlowAccent, RoundedCornerShape(24.dp))
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = Color.White)
            }
        }"""
chat_input_new = """        if (isPremium) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask anything or 'Create a mock test'...") },
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = XFlowAccent,
                        unfocusedBorderColor = XFlowSurfaceVariant,
                        focusedTextColor = XFlowTextPrimary
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank() && !isGenerating) {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(XFlowAccent, RoundedCornerShape(24.dp))
                ) {
                    Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                }
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurfaceVariant)
            ) {
                Text(
                    "AI Chat is a Premium feature.",
                    modifier = Modifier.padding(16.dp),
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }"""
content = content.replace(chat_input_old, chat_input_new)

# Typewriter effect in ChatBubble
chat_bubble_old = """@Composable
fun ChatBubble(chat: AiChat) {
    val isUser = chat.role == "user"
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clip(RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ))
                .background(if (isUser) XFlowAccent else XFlowSurfaceVariant)
                .padding(12.dp)
        ) {
            Text(
                text = chat.message,
                color = if (isUser) Color.White else XFlowTextPrimary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}"""
chat_bubble_new = """@Composable
fun ChatBubble(chat: AiChat) {
    val isUser = chat.role == "user"
    var displayedText by remember { mutableStateOf(if (isUser) chat.message else "") }
    
    if (!isUser) {
        LaunchedEffect(chat.message) {
            val words = chat.message.split(" ")
            var currentText = ""
            for (word in words) {
                currentText += "$word "
                displayedText = currentText
                kotlinx.coroutines.delay(50) // Adjust delay for typing speed
            }
            displayedText = chat.message
        }
    }

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clip(RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ))
                .background(if (isUser) XFlowAccent else XFlowSurfaceVariant)
                .padding(12.dp)
        ) {
            Text(
                text = displayedText,
                color = if (isUser) Color.White else XFlowTextPrimary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}"""
content = content.replace(chat_bubble_old, chat_bubble_new)

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)
