import re

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

# Add showAppSettings state
old_state = """    var showStatsDialog by remember { mutableStateOf(false) }"""
new_state = """    var showStatsDialog by remember { mutableStateOf(false) }
    var showAppSettings by remember { mutableStateOf(false) }"""
content = content.replace(old_state, new_state)

# Replace Permissions and Personalization sections
old_sections = """            SettingsSection("Permissions") {
                SettingsItem(icon = Icons.Default.Security, title = "Manage Permissions", onClick = onNavigateToPermissions)
            }
            SettingsSection("Personalization") {
                SettingsItem(icon = Icons.Default.Build, title = "Theme & Appearance", onClick = onNavigateToThemeSettings)
            }"""
new_sections = """            SettingsSection("App Settings") {
                SettingsItem(icon = Icons.Default.Build, title = "App Settings", subtitle = "Permissions, Theme & Appearance", onClick = { showAppSettings = true })
            }"""
content = content.replace(old_sections, new_sections)

# Add bottom sheet for showAppSettings
bottom_sheet_code = """
    if (showAppSettings) {
        ModalBottomSheet(
            onDismissRequest = { showAppSettings = false },
            containerColor = XFlowBackground,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("App Settings", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                Spacer(modifier = Modifier.height(8.dp))
                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Security, title = "Manage Permissions", onClick = { showAppSettings = false; onNavigateToPermissions() })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Build, title = "Theme & Appearance", onClick = { showAppSettings = false; onNavigateToThemeSettings() })
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
"""
content = content.replace("    if (showDataOptions) {", bottom_sheet_code + "    if (showDataOptions) {")

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)
