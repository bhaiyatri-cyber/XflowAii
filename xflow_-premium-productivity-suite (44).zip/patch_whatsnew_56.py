with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

old_changes = """                    val changes = listOf(
                        "Corrected Logo: Updated the logo to the correct XFlow icon across the entire app.",
                        "Splash Screen & Settings: Added the new logo seamlessly to all areas (except the Home screen).",
                        "Notifications: Icons updated to match the new identity."
                    )"""

new_changes = """                    val changes = listOf(
                        "Reverted Original Logo: Brought back the classic XFlow vector icon design based on user feedback.",
                        "Performance Improvements: Restored the original adaptive icon layout to fix random crashes and bugs.",
                        "Bug Fixes: Fixed screen-skipping and UI bugs caused by the previous update."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)
