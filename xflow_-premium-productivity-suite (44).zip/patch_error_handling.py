import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

old_catch = """            } catch (e: Exception) {
                db.dao().insertAiChat(AiChat(role = "model", message = "Error: ${e.message}. (Make sure you have configured a valid GEMINI_API_KEY in Settings/Secrets).", timestamp = System.currentTimeMillis()))
            } finally {"""

new_catch = """            } catch (e: Exception) {
                val errorMessage = e.message ?: ""
                val msg = if (errorMessage.contains("429") || errorMessage.contains("quota", ignoreCase = true) || errorMessage.contains("exhausted", ignoreCase = true)) {
                    "Daily limit reached for AI chatting. The API quota has been exhausted and will reset tomorrow (midnight Pacific Time)."
                } else {
                    "Error: ${e.message}. (Make sure you have configured a valid GEMINI_API_KEY in Settings/Secrets)."
                }
                db.dao().insertAiChat(AiChat(role = "model", message = msg, timestamp = System.currentTimeMillis()))
            } finally {"""

content = content.replace(old_catch, new_catch)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
