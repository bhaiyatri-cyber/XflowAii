with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    lines = f.readlines()

start_line = 0
for i, line in enumerate(lines):
    if "fun AllTimeHistoryScreen" in line:
        start_line = i
        break

end_line = 0
for i in range(start_line, len(lines)):
    if "fun HistoryCard" in line:
        end_line = i
        break

count = 0
for i in range(start_line, end_line):
    line = lines[i]
    for char in line:
        if char == '{': count += 1
        elif char == '}': count -= 1
    print(f"{i+1:03d} [{count:2d}] {line.rstrip()}")
