import re

# 1. Fix ImageToPdfScreen.kt
with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'r') as f:
    pdf_content = f.read()

# Change CreatePdfTab call
pdf_content = pdf_content.replace(
    "                CreatePdfTab()\n",
    "                CreatePdfTab(onPdfCreated = { selectedTabIndex = 1 })\n"
)

# Change CreatePdfTab definition
pdf_content = pdf_content.replace(
    "fun CreatePdfTab() {",
    "fun CreatePdfTab(onPdfCreated: () -> Unit = {}) {"
)

# Fix PDF generation success handling to stop buffering and change tab
old_success = """                        generatedPdfUri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            pdfFile
                        )
                        imageUris = emptyList() // Clear selection on success"""

new_success = """                        generatedPdfUri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            pdfFile
                        )
                        imageUris = emptyList() // Clear selection on success
                        onPdfCreated()
                        Toast.makeText(context, "PDF generated successfully!", Toast.LENGTH_LONG).show()"""

pdf_content = pdf_content.replace(old_success, new_success)

# Also fix the append action success state
old_append_success = """                    savedPdfs = PdfGenerator.getSavedPdfs(context)
                    Toast.makeText(context, "Pages added successfully", Toast.LENGTH_SHORT).show()"""

new_append_success = """                    savedPdfs = PdfGenerator.getSavedPdfs(context)
                    Toast.makeText(context, "Pages added successfully", Toast.LENGTH_LONG).show()"""

pdf_content = pdf_content.replace(old_append_success, new_append_success)

with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'w') as f:
    f.write(pdf_content)

# 2. Fix AiScreen.kt scrolling logic
with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    ai_content = f.read()

old_scroll = """    LaunchedEffect(aiChats.size) {
        if (aiChats.isNotEmpty()) {
            listState.animateScrollToItem(aiChats.size - 1)
        }
    }"""

new_scroll = """    LaunchedEffect(aiChats.size, isGenerating) {
        if (aiChats.isNotEmpty()) {
            val targetIndex = if (isGenerating) aiChats.size else aiChats.size - 1
            if (targetIndex >= 0) {
                listState.animateScrollToItem(targetIndex)
            }
        }
    }"""

ai_content = ai_content.replace(old_scroll, new_scroll)

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(ai_content)

print("Patches applied.")
