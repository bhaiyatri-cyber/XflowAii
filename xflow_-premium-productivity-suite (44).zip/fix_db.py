with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

bad_string = '''    @Query("SELECT * FROM ai_chats WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    @Query("SELECT DISTINCT sessionId FROM ai_chats")
    fun getAiChatSessions(): Flow<List<String>>'''

good_string = '''    @Query("SELECT DISTINCT sessionId FROM ai_chats")
    fun getAiChatSessions(): Flow<List<String>>'''

content = content.replace(bad_string, good_string)

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)
