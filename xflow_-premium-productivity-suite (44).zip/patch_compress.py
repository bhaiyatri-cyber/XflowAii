import re

with open('app/src/main/java/com/example/utils/PdfGenerator.kt', 'r') as f:
    content = f.read()

new_compress_fun = """    suspend fun compressPdf(context: Context, existingFile: File, targetSizeKb: Long): File? = withContext(Dispatchers.IO) {
        val targetSizeBytes = targetSizeKb * 1024
        val currentSizeBytes = existingFile.length()
        if (currentSizeBytes <= targetSizeBytes) return@withContext existingFile

        // Area scales with the square of linear dimensions
        var scaleFactor = kotlin.math.sqrt(targetSizeBytes.toDouble() / currentSizeBytes.toDouble()).toFloat()
        // Ensure scaleFactor isn't too small to avoid completely unreadable PDFs
        if (scaleFactor < 0.1f) scaleFactor = 0.1f
        
        var bestFile: File? = null
        var bestDiff = Long.MAX_VALUE
        
        // We'll do a simple iteration (up to 3 times) to get close to the target size
        for (attempt in 0 until 3) {
            val pdfDocument = PdfDocument()
            try {
                val fileDescriptor = android.os.ParcelFileDescriptor.open(existingFile, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
                val pdfRenderer = android.graphics.pdf.PdfRenderer(fileDescriptor)
                
                for (i in 0 until pdfRenderer.pageCount) {
                    val rendererPage = pdfRenderer.openPage(i)
                    
                    val scaledWidth = (rendererPage.width * scaleFactor).toInt().coerceAtLeast(1)
                    val scaledHeight = (rendererPage.height * scaleFactor).toInt().coerceAtLeast(1)
                    
                    val bitmap = Bitmap.createBitmap(scaledWidth, scaledHeight, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    
                    val matrix = android.graphics.Matrix()
                    matrix.postScale(scaleFactor, scaleFactor)
                    
                    rendererPage.render(bitmap, null, matrix, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    rendererPage.close()
                    
                    // We need to compress the bitmap to reduce size before drawing? 
                    // Actually PdfDocument doesn't compress bitmaps aggressively.
                    // Another trick is to compress bitmap to JPEG, then decode back to draw, it loses quality and maybe saves size in PDF?
                    // But in PdfDocument on Android, bitmaps are stored in a raw-like format or zlib compressed, 
                    // the main factor is the pixel count.
                    
                    val pageInfo = PdfDocument.PageInfo.Builder(scaledWidth, scaledHeight, i + 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                    pdfDocument.finishPage(page)
                    bitmap.recycle()
                }
                pdfRenderer.close()
                fileDescriptor.close()
                
                val tempFile = File(existingFile.parent, "compressed_${System.currentTimeMillis()}.pdf")
                pdfDocument.writeTo(FileOutputStream(tempFile))
                pdfDocument.close()
                
                val newSize = tempFile.length()
                val diff = kotlin.math.abs(newSize - targetSizeBytes)
                
                if (bestFile == null || diff < bestDiff) {
                    bestFile?.delete()
                    bestFile = tempFile
                    bestDiff = diff
                } else {
                    tempFile.delete()
                }
                
                if (newSize <= targetSizeBytes * 1.1 && newSize >= targetSizeBytes * 0.9) {
                    break
                }
                
                // Adjust scaleFactor for next iteration
                val ratio = targetSizeBytes.toDouble() / newSize.toDouble()
                scaleFactor = (scaleFactor * kotlin.math.sqrt(ratio)).toFloat().coerceIn(0.1f, 1.0f)
                
            } catch (e: Exception) {
                e.printStackTrace()
                pdfDocument.close()
                break
            }
        }
        
        if (bestFile != null) {
            val finalFile = File(existingFile.parent, "Compressed_" + existingFile.name)
            if (bestFile.renameTo(finalFile)) {
                return@withContext finalFile
            }
            return@withContext bestFile
        }
        
        return@withContext null
    }
"""

# Insert before the last brace
content = content.rstrip()
if content.endswith("}"):
    content = content[:-1] + new_compress_fun + "\n}"

with open('app/src/main/java/com/example/utils/PdfGenerator.kt', 'w') as f:
    f.write(content)
print("Patched PdfGenerator with compressPdf")
