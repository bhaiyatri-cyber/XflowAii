import re

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

# Add updateInfo state
states = """    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val updateInfo by viewModel.updateInfo.collectAsStateWithLifecycle()"""
content = content.replace("val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()", states)

# Modify AppUpdateScreen call
old_call = """        AppUpdateScreen(
            onBack = { showUpdateScreen = false },
            onShowReleaseNotes = { showReleaseNotes = true }
        )"""
new_call = """        AppUpdateScreen(
            updateInfo = updateInfo,
            onCheckForUpdates = { viewModel.checkForUpdatesManual() },
            onUpdateNow = { viewModel.startUpdateDownload() },
            onBack = { showUpdateScreen = false },
            onShowReleaseNotes = { showReleaseNotes = true }
        )"""
content = content.replace(old_call, new_call)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)
