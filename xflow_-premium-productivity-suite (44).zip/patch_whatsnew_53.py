import re

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

old_changes = """                    val changes = listOf(
                        "All Time History Scroll Fix: The entire history page is now fully scrollable so you can easily view your timeline, streaks, and all your history folders without getting stuck.",
                        "Data & Web Hub Fixes: Resolved file download & open issues.",
                        "YouTube & ChatGPT Fixes: Improved scaling, loading, and chat views.",
                        "Full-Screen Updates: Removed popup dialogs for a cleaner screen.",
                        "Performance and stability improvements."
                    )"""

new_changes = """                    val changes = listOf(
                        "Time Format Improvement: Stats now display hours and minutes intuitively instead of decimals (e.g., 4h 12m instead of 4.2h).",
                        "All Time History Scroll Fix: The entire history page is now fully scrollable so you can easily view your timeline, streaks, and all your history folders without getting stuck.",
                        "Data & Web Hub Fixes: Resolved file download & open issues.",
                        "YouTube & ChatGPT Fixes: Improved scaling, loading, and chat views.",
                        "Full-Screen Updates: Removed popup dialogs for a cleaner screen."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)

