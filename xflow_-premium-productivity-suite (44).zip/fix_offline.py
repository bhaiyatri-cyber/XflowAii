import re

with open('app/src/main/java/com/example/service/TrackingService.kt', 'r', encoding='utf-8') as f:
    content = f.read()

pattern = re.compile(r'(\} else if \(!schedule\.isOnlineMode\) \{.*?)(?=\s+\}\s+updateNotification)', re.DOTALL)

def repl(m):
    return """} else if (!schedule.isOnlineMode) {
                        // Offline Mode: Track continuously regardless of screen state
                        trackingAny = true
                        val newElapsed = schedule.elapsedSeconds + 1
                        db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                        titleText = "Offline Tracking: ${schedule.subject}"
                        contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                        if (newElapsed >= targetTime) {
                            db.dao().insertHistory(
                                com.example.data.HistorySession(
                                    scheduleId = schedule.id,
                                    subject = schedule.subject,
                                    mode = if (isDuration) "Duration" else "Exact Time",
                                    date = System.currentTimeMillis(),
                                    timeStudiedSeconds = newElapsed,
                                    completionPercentage = 100,
                                    status = "Completed"
                                )
                            )
                            db.dao().deactivateSchedule(schedule.id)
                            sendAlertNotification(
                                "Goal Reached \\uD83C\\uDF89",
                                "You've completed your focus session for '${schedule.subject}'!",
                                schedule.id + 2000
                            )
                        }
                    }"""

new_content = pattern.sub(repl, content)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w', encoding='utf-8') as f:
    f.write(new_content)
