import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

pattern = re.compile(r'@Composable\s*fun DynamicHeader\(\)\s*\{.*?\n\}', re.DOTALL)
new_header = """@Composable
fun DynamicHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.app_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "XFlow",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = XFlowAccent
        )
    }
}"""

# Since the regex might be tricky, let's just do a replace on the exact text block
exact_target = """@Composable
fun DynamicHeader() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000L)
        }
    }

    val calendar = Calendar.getInstance().apply { time = now }
    val hour = calendar.get(Calendar.HOUR_OF_DAY)
    val icon = when (hour) {
        in 5..11 -> "☀️"
        in 12..16 -> "🌤️"
        in 17..19 -> "🌇"
        else -> "🌙"
    }

    val format = if (DateFormat.is24HourFormat(LocalContext.current)) "HH:mm" else "hh:mm a"
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.app_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "$icon ${SimpleDateFormat(format, Locale.getDefault()).format(now)}",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = XFlowAccent
        )
    }
}"""

content = content.replace(exact_target, new_header)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
