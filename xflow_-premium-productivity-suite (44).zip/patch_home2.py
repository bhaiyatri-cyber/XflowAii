import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

pattern = re.compile(r'    LaunchedEffect\(Unit\) \{.*?    \}', re.DOTALL)

replacement = """    LaunchedEffect(Unit) {
        if (lastOpenedVersion < currentVersion) {
            showWhatsNew = true
            val updateTimeKey = "update_time_$currentVersion"
            if (prefs.getLong(updateTimeKey, 0L) == 0L) {
                prefs.edit().putLong(updateTimeKey, System.currentTimeMillis()).apply()
            }
        }
    }

    if (showWhatsNew) {
        WhatsNewScreen(onDismiss = {
            showWhatsNew = false
            prefs.edit().putInt("last_opened_version", currentVersion).apply()
        })
        return
    }"""

# Find the start of LaunchedEffect and replace the whole block until the last `    }`
start_idx = content.find("    LaunchedEffect(Unit) {")
end_idx = content.find("    val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()")

content = content[:start_idx] + replacement + "\n" + content[end_idx:]

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)

