import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

pattern = re.compile(r'@Composable\s*fun DynamicHeader\(\)\s*\{.*?\n\}', re.DOTALL)
new_header = """@Composable
fun DynamicHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.app_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "XFlow",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = XFlowAccent
        )
    }
}"""

content = re.sub(pattern, new_header, content)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
