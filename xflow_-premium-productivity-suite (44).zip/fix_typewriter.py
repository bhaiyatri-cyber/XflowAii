import re
with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("kotlinx.coroutines.launch {", "launch {")

with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/SimpleAiChatScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("kotlinx.coroutines.launch {", "launch {")

with open('app/src/main/java/com/example/ui/SimpleAiChatScreen.kt', 'w') as f:
    f.write(content)

