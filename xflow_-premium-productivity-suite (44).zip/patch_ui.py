with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

# Update SettingsSection
old_section = """@Composable
fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            text = title,
            color = XFlowAccent,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp, start = 8.dp)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(XFlowSurface)
        ) {
            content()
        }
    }
}"""

new_section = """@Composable
fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        if (title.isNotEmpty()) {
            Text(
                text = title,
                color = XFlowAccent,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp, start = 8.dp)
            )
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(XFlowSurface)
        ) {
            content()
        }
    }
}"""
content = content.replace(old_section, new_section)

# Now update the bottom sheets
old_data_hub = """        ModalBottomSheet(
            onDismissRequest = { showDataOptions = false },
            containerColor = XFlowSurface,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                Text("Data & Web Hub", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                SettingsItem(icon = Icons.Filled.Public, title = "Data Drive", subtitle = "Secure In-App Browser & Storage", onClick = { showDataOptions = false; onNavigateToDataDrive() })
                SettingsItem(icon = Icons.Filled.PlayCircle, title = "YouTube", subtitle = "Watch videos in full screen", onClick = { showDataOptions = false; onNavigateToYouTube() })
                SettingsItem(icon = Icons.Filled.Chat, title = "ChatGPT", subtitle = "AI Chat Assistant", onClick = { showDataOptions = false; onNavigateToChatGPT() })
                Spacer(modifier = Modifier.height(32.dp))
            }
        }"""

new_data_hub = """        ModalBottomSheet(
            onDismissRequest = { showDataOptions = false },
            containerColor = XFlowBackground,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Data & Web Hub", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                Spacer(modifier = Modifier.height(8.dp))
                SettingsSection("") {
                    SettingsItem(icon = Icons.Filled.Public, title = "Data Drive", subtitle = "Secure In-App Browser & Storage", onClick = { showDataOptions = false; onNavigateToDataDrive() })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Filled.PlayCircle, title = "YouTube", subtitle = "Watch videos in full screen", onClick = { showDataOptions = false; onNavigateToYouTube() })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Filled.Chat, title = "ChatGPT", subtitle = "AI Chat Assistant", onClick = { showDataOptions = false; onNavigateToChatGPT() })
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }"""
content = content.replace(old_data_hub, new_data_hub)

old_tools_hub = """        ModalBottomSheet(
            onDismissRequest = { showToolOptions = false },
            containerColor = XFlowSurface,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                Text("Tools Hub", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "24h Daily Report", subtitle = "Study vs Wasted Time", onClick = { showToolOptions = false; onNavigateToDailyReport() })
                SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { showToolOptions = false; if (isPremium) onNavigateToPdf() else showPremiumDialog = true })
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "🔥 Overtime (PRO)", onClick = { showToolOptions = false; if (isPremium) onNavigateToOvertime() else showPremiumDialog = true })
                SettingsItem(icon = Icons.Default.Build, title = "Backup & Restore", onClick = { showToolOptions = false; onNavigateToBackup() })
                Spacer(modifier = Modifier.height(32.dp))
            }
        }"""

new_tools_hub = """        ModalBottomSheet(
            onDismissRequest = { showToolOptions = false },
            containerColor = XFlowBackground,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Tools Hub", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                Spacer(modifier = Modifier.height(8.dp))
                SettingsSection("") {
                    SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "24h Daily Report", subtitle = "Study vs Wasted Time", onClick = { showToolOptions = false; onNavigateToDailyReport() })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { showToolOptions = false; if (isPremium) onNavigateToPdf() else showPremiumDialog = true })
                }
                SettingsSection("") {
                    SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "🔥 Overtime (PRO)", onClick = { showToolOptions = false; if (isPremium) onNavigateToOvertime() else showPremiumDialog = true })
                }
                SettingsSection("") {
                    SettingsItem(icon = Icons.Default.Build, title = "Backup & Restore", onClick = { showToolOptions = false; onNavigateToBackup() })
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }"""
content = content.replace(old_tools_hub, new_tools_hub)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)

