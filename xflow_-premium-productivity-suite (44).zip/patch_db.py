import re

with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

# Add sessionId to AiChat
content = content.replace("val timestamp: Long\n)", "val timestamp: Long,\n    val sessionId: String = \"default\"\n)")

# Change queries to support sessionId
content = content.replace("fun getAllAiChats(): Flow<List<AiChat>>", "fun getAllAiChats(sessionId: String): Flow<List<AiChat>>")
content = content.replace("SELECT * FROM ai_chats ORDER BY timestamp ASC", "SELECT * FROM ai_chats WHERE sessionId = :sessionId ORDER BY timestamp ASC")
content = content.replace("DELETE FROM ai_chats", "DELETE FROM ai_chats WHERE sessionId = :sessionId")
content = content.replace("suspend fun deleteAllAiChats()", "suspend fun deleteAllAiChats(sessionId: String)")

# Add a query to get unique sessions
if "fun getAiChatSessions()" not in content:
    content = content.replace("fun getAllAiChats", "@Query(\"SELECT DISTINCT sessionId FROM ai_chats\")\n    fun getAiChatSessions(): Flow<List<String>>\n\n    @Query(\"SELECT * FROM ai_chats WHERE sessionId = :sessionId ORDER BY timestamp ASC\")\n    fun getAllAiChats")

# Increment DB version and add migration
content = content.replace("version = 8", "version = 9")

migration = """
                val MIGRATION_8_9 = object : androidx.room.migration.Migration(8, 9) {
                    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        db.execSQL("ALTER TABLE ai_chats ADD COLUMN sessionId TEXT NOT NULL DEFAULT 'default'")
                    }
                }
"""
content = content.replace("val instance = Room.databaseBuilder(", migration + "\n                val instance = Room.databaseBuilder(")
content = content.replace(".addMigrations(MIGRATION_5_6)", ".addMigrations(MIGRATION_5_6, MIGRATION_8_9)")

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)
