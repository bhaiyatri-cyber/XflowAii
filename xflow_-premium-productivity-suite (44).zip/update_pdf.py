import re

with open('app/src/main/java/com/example/utils/PdfGenerator.kt', 'r') as f:
    content = f.read()

# Update createPdfFromImages
old_create = """        val pdfDocument = PdfDocument()
        
        try {
            for ((index, uri) in imageUris.withIndex()) {
                val bitmap = getBitmap(context, uri) ?: continue
                
                val pageWidth = 595
                val pageHeight = 842
                
                val scale = Math.min(pageWidth.toFloat() / bitmap.width, pageHeight.toFloat() / bitmap.height)
                val scaledWidth = (bitmap.width * scale).toInt()
                val scaledHeight = (bitmap.height * scale).toInt()
                
                val scaledBitmap = Bitmap.createScaledBitmap(bitmap, scaledWidth, scaledHeight, true)
                
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                
                val canvas = page.canvas
                val left = (pageWidth - scaledWidth) / 2f
                val top = (pageHeight - scaledHeight) / 2f
                
                canvas.drawBitmap(scaledBitmap, left, top, null)
                pdfDocument.finishPage(page)
                
                if (scaledBitmap != bitmap) {
                    scaledBitmap.recycle()
                }
                bitmap.recycle()
            }"""

new_create = """        val pdfDocument = PdfDocument()
        
        try {
            for ((index, uri) in imageUris.withIndex()) {
                val bitmap = getBitmap(context, uri) ?: continue
                
                // Keep original quality and dimensions
                val pageWidth = bitmap.width
                val pageHeight = bitmap.height
                
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                
                val canvas = page.canvas
                canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDocument.finishPage(page)
                
                bitmap.recycle()
            }"""

content = content.replace(old_create, new_create)

# Update getBitmap
old_bitmap_1 = """                    val maxDim = 1200
                    val size = info.size
                    if (size.width > maxDim || size.height > maxDim) {
                        val scale = Math.min(maxDim.toFloat() / size.width, maxDim.toFloat() / size.height)
                        decoder.setTargetSize((size.width * scale).toInt(), (size.height * scale).toInt())
                    }"""
new_bitmap_1 = """                    // No downscaling, keep original quality"""
content = content.replace(old_bitmap_1, new_bitmap_1)

old_bitmap_2 = """                val maxDim = 1200
                var inSampleSize = 1
                if (options.outHeight > maxDim || options.outWidth > maxDim) {
                    val halfHeight = options.outHeight / 2
                    val halfWidth = options.outWidth / 2
                    while (halfHeight / inSampleSize >= maxDim && halfWidth / inSampleSize >= maxDim) {
                        inSampleSize *= 2
                    }
                }"""
new_bitmap_2 = """                var inSampleSize = 1
                // No downscaling, keep original quality"""
content = content.replace(old_bitmap_2, new_bitmap_2)

with open('app/src/main/java/com/example/utils/PdfGenerator.kt', 'w') as f:
    f.write(content)
