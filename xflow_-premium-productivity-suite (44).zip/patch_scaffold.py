import re

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()

old_scaffold = """        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (selectedItem == "Chat") "XFlow AI" else "Mock Tests", color = XFlowTextPrimary) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = XFlowTextPrimary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
                )
            },
            containerColor = XFlowBackground
        )"""

new_scaffold = """        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        if (selectedItem == "Chat") {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { /* drop down */ }) {
                                Text("XFlow AI", color = Color.White, style = MaterialTheme.typography.titleLarge)
                                Spacer(Modifier.width(4.dp))
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = "Dropdown", tint = Color.LightGray)
                            }
                        } else {
                            Text("Mock Tests", color = Color.White)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = Color.White)
                        }
                    },
                    actions = {
                        if (selectedItem == "Chat") {
                            IconButton(onClick = { viewModel.clearChat() }) {
                                Icon(Icons.Filled.Edit, contentDescription = "New Chat", tint = Color.White)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            },
            containerColor = Color.Black
        )"""

content = content.replace(old_scaffold, new_scaffold)

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)
