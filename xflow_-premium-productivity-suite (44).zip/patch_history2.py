import re

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

old_padding = "Box(modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp))"
new_padding = "Box(modifier = Modifier.padding(vertical = 4.dp))"

content = content.replace(old_padding, new_padding)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)

