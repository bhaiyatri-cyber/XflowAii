with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

target = """                        if (wasActiveAtEnd) {
                            // Convert to duration to trigger recovery tracking or overtime
                            db.dao().updateSchedule(schedule.copy(isDurationMode = true, durationMinutes = targetTime / 60))
                            if (schedule.elapsedSeconds < targetTime) {
                                sendAlertNotification(
                                    "Schedule Completed",
                                    "Remaining Study Time: ${(targetTime - schedule.elapsedSeconds)/60} Minutes. Recovery Time Started.",
                                    schedule.id + 1000
                                )
                            } else {
                                sendAlertNotification(
                                    "Schedule Completed",
                                    "Goal Reached! Overtime tracking has started.",
                                    schedule.id + 1000
                                )
                            }
                            continue
                        } else {"""

replacement = """                        if (wasActiveAtEnd) {
                            shouldTrack = true
                            autoComplete = false
                        } else {"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
        f.write(content)
    print("Success")
else:
    print("Failed to find target")
