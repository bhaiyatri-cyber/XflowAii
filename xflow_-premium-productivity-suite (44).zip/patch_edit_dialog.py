with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

idx = content.find("@Composable\nfun EditScheduleDialog")
if idx != -1:
    content = content[:idx]

new_dialog = """@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditScheduleDialog(schedule: com.example.data.Schedule, onDismiss: () -> Unit, onSave: (com.example.data.Schedule) -> Unit) {
    var subject by remember { mutableStateOf(schedule.subject) }
    var description by remember { mutableStateOf(schedule.description) }
    var isOnlineMode by remember { mutableStateOf(schedule.isOnlineMode) }
    var durationMinutes by remember { mutableStateOf(schedule.durationMinutes.toString()) }
    var startTimeStr by remember { mutableStateOf(schedule.startTimeStr) }
    var endTimeStr by remember { mutableStateOf(schedule.endTimeStr) }
    var selectedAppPackage by remember { mutableStateOf(schedule.selectedAppPackage ?: "") }
    
    var showAppSelector by remember { mutableStateOf(false) }
    var appsList by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var selectedAppName by remember { mutableStateOf("Select App") }
    
    val context = LocalContext.current
    
    LaunchedEffect(Unit) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val apps = getInstalledApps(context.packageManager)
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                appsList = apps
                val existingApp = apps.find { it.packageName == selectedAppPackage }
                if (existingApp != null) {
                    selectedAppName = existingApp.name
                } else if (apps.isNotEmpty()) {
                    if (selectedAppPackage.isBlank()) {
                        selectedAppPackage = apps[0].packageName
                        selectedAppName = apps[0].name
                    }
                }
            }
        }
    }
    
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XFlowBackground)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Edit Schedule", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = XFlowTextPrimary)
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = XFlowAccent,
                        unfocusedBorderColor = XFlowSurfaceVariant,
                        focusedLabelColor = XFlowAccent,
                        unfocusedLabelColor = XFlowTextSecondary,
                        focusedTextColor = XFlowTextPrimary,
                        unfocusedTextColor = XFlowTextPrimary
                    )
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = XFlowAccent,
                        unfocusedBorderColor = XFlowSurfaceVariant,
                        focusedLabelColor = XFlowAccent,
                        unfocusedLabelColor = XFlowTextSecondary,
                        focusedTextColor = XFlowTextPrimary,
                        unfocusedTextColor = XFlowTextPrimary
                    )
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                if (schedule.isDurationMode) {
                    OutlinedTextField(
                        value = durationMinutes,
                        onValueChange = { durationMinutes = it },
                        label = { Text("Duration (minutes)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = XFlowAccent,
                            unfocusedBorderColor = XFlowSurfaceVariant,
                            focusedLabelColor = XFlowAccent,
                            unfocusedLabelColor = XFlowTextSecondary,
                            focusedTextColor = XFlowTextPrimary,
                            unfocusedTextColor = XFlowTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                } else {
                    val showTimePicker = { isStart: Boolean ->
                        val calendar = java.util.Calendar.getInstance()
                        val currentHour = calendar.get(java.util.Calendar.HOUR_OF_DAY)
                        val currentMinute = calendar.get(java.util.Calendar.MINUTE)
                        
                        android.app.TimePickerDialog(
                            context,
                            { _, hourOfDay, minute ->
                                val timeStr = String.format("%02d:%02d", hourOfDay, minute)
                                if (isStart) startTimeStr = timeStr else endTimeStr = timeStr
                            },
                            currentHour,
                            currentMinute,
                            true
                        ).show()
                    }
                    
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        OutlinedTextField(
                            value = startTimeStr,
                            onValueChange = { },
                            readOnly = true,
                            label = { Text("Start Time") },
                            modifier = Modifier.weight(1f).clickable { showTimePicker(true) },
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = XFlowTextPrimary,
                                disabledBorderColor = XFlowSurfaceVariant,
                                disabledLabelColor = XFlowTextSecondary
                            )
                        )
                        OutlinedTextField(
                            value = endTimeStr,
                            onValueChange = { },
                            readOnly = true,
                            label = { Text("End Time") },
                            modifier = Modifier.weight(1f).clickable { showTimePicker(false) },
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = XFlowTextPrimary,
                                disabledBorderColor = XFlowSurfaceVariant,
                                disabledLabelColor = XFlowTextSecondary
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text("Tracking Type", color = XFlowTextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(XFlowSurfaceVariant)
                        .padding(4.dp)
                ) {
                    val options = listOf("Online", "Offline")
                    options.forEachIndexed { index, option ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isOnlineMode == (index == 0)) XFlowSurface else XFlowSurfaceVariant)
                                .clickable { isOnlineMode = index == 0 }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = option,
                                color = if (isOnlineMode == (index == 0)) XFlowTextPrimary else XFlowTextSecondary,
                                fontWeight = if (isOnlineMode == (index == 0)) FontWeight.Bold else FontWeight.Medium,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
                
                if (isOnlineMode) {
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedCard(
                        modifier = Modifier.fillMaxWidth().clickable { showAppSelector = true },
                        colors = CardDefaults.outlinedCardColors(containerColor = XFlowBackground),
                        border = androidx.compose.foundation.BorderStroke(1.dp, XFlowSurfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Target App", color = XFlowTextSecondary, style = MaterialTheme.typography.labelMedium)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(selectedAppName, color = XFlowTextPrimary, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = XFlowTextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (subject.isNotBlank()) {
                                onSave(schedule.copy(
                                    subject = subject,
                                    description = description,
                                    isOnlineMode = isOnlineMode,
                                    durationMinutes = durationMinutes.toIntOrNull() ?: schedule.durationMinutes,
                                    startTimeStr = startTimeStr,
                                    endTimeStr = endTimeStr,
                                    selectedAppPackage = if (isOnlineMode) selectedAppPackage else null
                                ))
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = Color.White)
                    ) {
                        Text("Save Changes")
                    }
                }
            }
        }
    }
    
    if (showAppSelector) {
        ModalBottomSheet(
            onDismissRequest = { showAppSelector = false },
            containerColor = XFlowSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("Select Target App", style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                
                if (appsList.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = XFlowAccent)
                    }
                } else {
                    androidx.compose.foundation.lazy.LazyColumn {
                        items(appsList.size) { index ->
                            val app = appsList[index]
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedAppPackage = app.packageName
                                        selectedAppName = app.name
                                        showAppSelector = false
                                    }
                                    .padding(vertical = 12.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(app.name, color = XFlowTextPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}
"""

with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'w') as f:
    f.write(content + new_dialog)
