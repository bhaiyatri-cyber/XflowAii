import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

bad_string = 'val mockJson = "{"title": "Demo Mock Test", "questions": [{"q": "What is 2+2?", "options": ["3", "4", "5", "6"], "answerIndex": 1}, {"q": "What is the capital of France?", "options": ["Berlin", "Madrid", "Paris", "Rome"], "answerIndex": 2}]}"'
good_string = 'val mockJson = "{\\"title\\": \\"Demo Mock Test\\", \\"questions\\": [{\\"q\\": \\"What is 2+2?\\", \\"options\\": [\\"3\\", \\"4\\", \\"5\\", \\"6\\"], \\"answerIndex\\": 1}, {\\"q\\": \\"What is the capital of France?\\", \\"options\\": [\\"Berlin\\", \\"Madrid\\", \\"Paris\\", \\"Rome\\"], \\"answerIndex\\": 2}]}"'

if bad_string in content:
    content = content.replace(bad_string, good_string)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
