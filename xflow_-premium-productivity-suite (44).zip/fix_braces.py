with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

bad_part = """    LaunchedEffect(Unit) {
        if (lastOpenedVersion < currentVersion) {
            showWhatsNew = true
    }

    if (showWhatsNew) {"""

good_part = """    LaunchedEffect(Unit) {
        if (lastOpenedVersion < currentVersion) {
            showWhatsNew = true
        }
    }

    if (showWhatsNew) {"""

content = content.replace(bad_part, good_part)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
