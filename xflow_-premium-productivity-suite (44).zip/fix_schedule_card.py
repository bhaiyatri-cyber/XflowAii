with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

import re
content = re.sub(r'(if \(schedule.isOnlineMode\) \{\s*OnlineAnimation\(\)\s*\} else \{\s*OfflineIllustration\(\)\s*\}\s*\})(\s*\})', r'\1\n        }\2', content)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
