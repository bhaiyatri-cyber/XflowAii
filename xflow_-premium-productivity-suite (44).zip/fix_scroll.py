with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {',
    'Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {'
)

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'w') as f:
    f.write(content)
