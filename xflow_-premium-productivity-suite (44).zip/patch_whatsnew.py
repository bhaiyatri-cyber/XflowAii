with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

old_changes = """                    val changes = listOf(
                        "Time Format Improvement: Stats now display hours and minutes intuitively instead of decimals (e.g., 4h 12m instead of 4.2h).",
                        "All Time History Scroll Fix: The entire history page is now fully scrollable so you can easily view your timeline, streaks, and all your history folders without getting stuck.",
                        "Data & Web Hub Fixes: Resolved file download & open issues.",
                        "YouTube & ChatGPT Fixes: Improved scaling, loading, and chat views.",
                        "Full-Screen Updates: Removed popup dialogs for a cleaner screen."
                    )"""

new_changes = """                    val changes = listOf(
                        "New XFlow Logo: Brand new official logo implemented across Splash Screen, Settings, About, Premium and Notifications.",
                        "Clean Home Header: Removed logo from the home screen for a more minimal layout.",
                        "Visual Polish: Updated app icon and internal graphics to match the new XFlow identity."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)
