import re

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'r') as f:
    content = f.read()

new_ui = """            Spacer(modifier = Modifier.height(32.dp))

            val currentCardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()
            val cardStyles = listOf("Solid", "Image")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Card Background (PRO)", style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                if (!isPremium) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Default.Lock, contentDescription = "Locked", tint = XFlowTextSecondary, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cardStyles.forEach { style ->
                    FilterChip(
                        selected = currentCardStyle == style,
                        onClick = {
                            if (isPremium) {
                                viewModel.updateCardStyle(style)
                            } else {
                                showPremiumDialog = true
                            }
                        },
                        label = { Text(style) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = XFlowAccent,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(32.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {"""

content = content.replace('            Spacer(modifier = Modifier.height(32.dp))\n\n            Row(verticalAlignment = Alignment.CenterVertically) {', new_ui)

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'w') as f:
    f.write(content)
