import re

with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

func = """
    @Query("DELETE FROM ai_chats")
    suspend fun deleteAllAiChats()
"""

# add right before the last closing brace of XFlowDao (before @Database)
content = content.replace('    suspend fun updateStudyPlanGeneratedDay(planId: Int, day: Long)\n}', '    suspend fun updateStudyPlanGeneratedDay(planId: Int, day: Long)\n' + func + '}')

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)
