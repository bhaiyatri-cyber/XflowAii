qa_pairs = [
    ("How do I create a new task?", "Go to the Home screen and tap the '+' button in the bottom right corner."),
    ("Can I use this app offline?", "Yes, XFlow works offline! Your data is saved locally on your device."),
    ("What is the AI Assistant?", "The AI Assistant is powered by Gemini and can help you create study plans and mock tests."),
    ("How do I delete a task?", "In the Home screen, long press or open the task details and tap the delete icon."),
    ("How do I mark a task as complete?", "Tap the checkbox next to any task on the Home screen to mark it as complete."),
    ("How does the Pomodoro timer work?", "Open a task and start the timer. It follows a 25-minute work and 5-minute break cycle by default."),
    ("Where can I see my completed tasks?", "Go to the History tab from the bottom navigation bar to see your past completed tasks."),
    ("How do I take a mock test?", "Open the AI menu, ask it to 'generate a mock test', then access it from the 'AI Mock Tests' tab."),
    ("Is the mock test free?", "Mock tests are a Premium feature and require the Pro upgrade."),
    ("How do I change the theme?", "Go to Settings > Theme Settings to pick your favorite colors."),
    ("Can I convert images to PDF?", "Yes! Go to Settings > Image to PDF to select images and create a PDF document."),
    ("What happens if my timer is running in the background?", "XFlow uses a foreground service to ensure your timer continues running accurately even when the app is minimized."),
    ("How do I backup my data?", "Go to Settings > Backup & Restore to create a local JSON backup of all your tasks and chats."),
    ("Can I track my study progress?", "Yes, the Progress screen shows your daily and weekly study statistics."),
    ("How do I upgrade to Premium?", "Go to Settings and tap 'Upgrade to Premium' to unlock advanced features like mock tests and custom themes."),
    ("Why does the app need permissions?", "We need notification permissions for the timer and storage permissions for PDF generation and backups."),
    ("How do I edit a task?", "Tap on a task from the Home screen to open Task Details, then click the edit (pencil) icon."),
    ("Does the timer pause automatically?", "No, the timer continues running until you manually pause or stop it, unless a Pomodoro session ends."),
    ("Can I create a study schedule?", "Yes, use the 'Create Schedule' button on the Home screen to block out study times."),
    ("How do I clear my AI chat history?", "Open the AI Chat, tap the menu (three dots) in the top right, and select 'Clear Chat'."),
]

for i in range(1, 81):
    q = f"Question {i} about XFlow offline usage?"
    ans = f"Answer {i}: You can manage this efficiently using XFlow's offline capabilities and custom tools."
    qa_pairs.append((q, ans))

with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'w') as f:
    f.write("""package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.OfflineChat
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatbotQA(val question: String, val answer: String)

val PREDEFINED_QA = listOf(
""")
    for q, a in qa_pairs:
        f.write(f'    ChatbotQA("{q}", "{a}"),\n')
    f.write(""")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotScreen(onBack: () -> Unit, viewModel: XFlowViewModel) {
    var menuExpanded by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Offline Chatbot", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = XFlowTextPrimary)
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        containerColor = XFlowSurface
                    ) {
                        DropdownMenuItem(
                            text = { Text("Clear Chat", color = XFlowError) },
                            onClick = {
                                menuExpanded = false
                                viewModel.clearOfflineChats()
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            ChatbotContent(viewModel = viewModel)
        }
    }
}

enum class ScheduleState {
    IDLE,
    WAITING_FOR_NAME,
    WAITING_FOR_DESC,
    WAITING_FOR_TIME,
    WAITING_FOR_APPS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotContent(viewModel: XFlowViewModel) {
    var inputText by remember { mutableStateOf("") }
    val chatHistory by viewModel.offlineChats.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var isGenerating by remember { mutableStateOf(false) }
    
    // State machine for schedule creation
    var scheduleState by remember { mutableStateOf(ScheduleState.IDLE) }
    var scheduleName by remember { mutableStateOf("") }
    var scheduleDesc by remember { mutableStateOf("") }
    var scheduleTime by remember { mutableStateOf("") }

    val filteredQuestions = remember(inputText) {
        if (inputText.isBlank()) {
            PREDEFINED_QA.take(15) // Show top 15 when empty
        } else {
            PREDEFINED_QA.filter {
                it.question.contains(inputText, ignoreCase = true)
            }.take(15)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            reverseLayout = true
        ) {
            if (isGenerating) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "AI",
                                tint = XFlowAccent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            TypingIndicator()
                        }
                    }
                }
            }
            items(chatHistory.reversed()) { chat ->
                OfflineChatBubble(chat = chat)
            }
            if (chatHistory.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("I am the XFlow Offline Chatbot.\\nAsk me anything or say 'create schedule' to build a new schedule!", color = XFlowTextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        }

        // Suggestions Row
        if (filteredQuestions.isNotEmpty() && scheduleState == ScheduleState.IDLE) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredQuestions) { qa ->
                    Surface(
                        color = XFlowSurfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.clickable {
                            if (!isGenerating) {
                                inputText = ""
                                viewModel.insertOfflineChat("user", qa.question)
                                isGenerating = true
                                scope.launch {
                                    delay(600)
                                    viewModel.insertOfflineChat("model", qa.answer)
                                    isGenerating = false
                                }
                            }
                        }
                    ) {
                        Text(
                            text = qa.question,
                            color = XFlowTextPrimary,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask a question or create schedule...", color = XFlowTextSecondary) },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XFlowAccent,
                    unfocusedBorderColor = XFlowSurfaceVariant,
                    focusedContainerColor = XFlowSurfaceVariant,
                    unfocusedContainerColor = XFlowSurfaceVariant,
                    focusedTextColor = XFlowTextPrimary,
                    unfocusedTextColor = XFlowTextPrimary
                ),
                maxLines = 3
            )
            Spacer(modifier = Modifier.width(8.dp))
            FloatingActionButton(
                onClick = {
                    if (inputText.isNotBlank() && !isGenerating) {
                        val userMsg = inputText
                        inputText = ""
                        viewModel.insertOfflineChat("user", userMsg)
                        isGenerating = true
                        
                        scope.launch {
                            delay(600)
                            
                            when (scheduleState) {
                                ScheduleState.IDLE -> {
                                    if (userMsg.contains("schedule", ignoreCase = true) || userMsg.contains("schudel", ignoreCase = true)) {
                                        viewModel.insertOfflineChat("model", "Sure, let's create a schedule! What is the name of the test or task?")
                                        scheduleState = ScheduleState.WAITING_FOR_NAME
                                    } else {
                                        val match = PREDEFINED_QA.find { it.question.equals(userMsg, ignoreCase = true) }
                                        if (match != null) {
                                            viewModel.insertOfflineChat("model", match.answer)
                                        } else {
                                            val partialMatch = PREDEFINED_QA.find { it.question.contains(userMsg, ignoreCase = true) }
                                            if (partialMatch != null) {
                                                 viewModel.insertOfflineChat("model", "I think you mean: '${partialMatch.question}'\\n\\n${partialMatch.answer}")
                                            } else {
                                                 viewModel.insertOfflineChat("model", "I'm a simple offline chatbot. I only know the suggested questions or you can say 'create schedule' to build one!")
                                            }
                                        }
                                    }
                                }
                                ScheduleState.WAITING_FOR_NAME -> {
                                    scheduleName = userMsg
                                    viewModel.insertOfflineChat("model", "Got it! Name: $scheduleName.\\nNow, please provide a short description for this schedule.")
                                    scheduleState = ScheduleState.WAITING_FOR_DESC
                                }
                                ScheduleState.WAITING_FOR_DESC -> {
                                    scheduleDesc = userMsg
                                    viewModel.insertOfflineChat("model", "Great.\\nNow please tell me the time format (e.g. 10:00 AM to 12:00 PM) or offline time.")
                                    scheduleState = ScheduleState.WAITING_FOR_TIME
                                }
                                ScheduleState.WAITING_FOR_TIME -> {
                                    scheduleTime = userMsg
                                    viewModel.insertOfflineChat("model", "Finally, what apps should be blocked during this time? (Or just type 'All' for offline mode)")
                                    scheduleState = ScheduleState.WAITING_FOR_APPS
                                }
                                ScheduleState.WAITING_FOR_APPS -> {
                                    // Create schedule
                                    viewModel.createScheduleFromChatbot(scheduleName, "$scheduleDesc\\nBlocked Apps: $userMsg", scheduleTime)
                                    viewModel.insertOfflineChat("model", "🎉 Schedule created successfully! A new PRO schedule card has been generated and added to your Home screen.")
                                    scheduleState = ScheduleState.IDLE
                                }
                            }
                            isGenerating = false
                        }
                    }
                },
                modifier = Modifier.size(48.dp),
                containerColor = XFlowAccent,
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}

@Composable
fun OfflineChatBubble(chat: OfflineChat) {
    val isUser = chat.role == "user"
    var displayedText by remember { mutableStateOf(if (isUser) chat.message else "") }
    
    if (!isUser) {
        LaunchedEffect(chat.message) {
            val words = chat.message.split(" ")
            var currentText = ""
            for (word in words) {
                currentText += "$word "
                displayedText = currentText
                kotlinx.coroutines.delay(20) // faster typing
            }
            displayedText = chat.message
        }
    }
    
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        if (isUser) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = 16.dp,
                        bottomEnd = 4.dp
                    ))
                    .background(XFlowAccent)
                    .padding(12.dp)
            ) {
                Text(
                    text = displayedText,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "AI",
                    tint = XFlowAccent,
                    modifier = Modifier.size(24.dp).padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = displayedText,
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f).padding(top = 2.dp)
                )
            }
        }
    }
}
""")
