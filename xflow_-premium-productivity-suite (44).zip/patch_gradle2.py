import re

with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

# Add a buildConfigField explicitly
pattern = r'(defaultConfig \{)'
replacement = r'\1\n    buildConfigField("String", "GEMINI_API_KEY", "\"${project.findProperty(\"GEMINI_API_KEY\") ?: \"\"}\"")'

if "buildConfigField(\"String\", \"GEMINI_API_KEY\"" not in content:
    content = re.sub(pattern, replacement, content)

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
