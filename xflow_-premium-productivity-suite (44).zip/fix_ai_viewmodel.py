import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

# Let's replace the whole sendMessage method to something simpler
# We need to find the start of sendMessage and replace it.
content = re.sub(
    r'    fun sendMessage\(message: String\) \{.*$',
    """    fun sendMessage(message: String) {
        viewModelScope.launch {
            db.dao().insertAiChat(AiChat(role = "user", message = message, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
            isGenerating.value = true
            
            try {
                // Construct history carefully to ensure strictly alternating roles for Gemini
                val currentChats = aiChats.value.toList()
                val filteredChats = if (currentChats.isNotEmpty() && currentChats.last().role == "user" && currentChats.last().message == message) {
                    currentChats.dropLast(1)
                } else {
                    currentChats
                }

                val recentChats = filteredChats.takeLast(10).toMutableList()
                while (recentChats.isNotEmpty() && recentChats.first().role != "user") {
                    recentChats.removeAt(0)
                }
                
                var lastRole = ""
                val validHistory = mutableListOf<AiChat>()
                for (chat in recentChats) {
                    val role = if (chat.role == "model") "model" else "user"
                    if (role != lastRole) {
                        validHistory.add(chat)
                        lastRole = role
                    }
                }
                
                if (validHistory.isNotEmpty() && validHistory.last().role != "model") {
                    validHistory.removeAt(validHistory.lastIndex)
                }

                val history = validHistory.map { chat ->
                    Content(role = if (chat.role == "model") "model" else "user", parts = listOf(Part(text = chat.message)))
                }.toMutableList()

                history.add(Content(role = "user", parts = listOf(Part(text = message))))
                
                val request = GenerateContentRequest(
                    contents = history,
                    systemInstruction = Content(parts = listOf(Part(text = "You are XFlow AI, a helpful assistant. You help users with study tips, productivity, and focus techniques.")))
                )
                
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isBlank() || apiKey == "null") {
                    throw Exception("API Key not found or empty.")
                }

                val response = RetrofitClient.service.generateContent(apiKey, request)
                val responseText = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "I'm sorry, I couldn't generate a response."
                db.dao().insertAiChat(AiChat(role = "model", message = responseText, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))

            } catch (e: Exception) {
                val errorMessage = e.message ?: ""
                val msg = if (errorMessage.contains("429") || errorMessage.contains("quota", ignoreCase = true) || errorMessage.contains("exhausted", ignoreCase = true)) {
                    "Daily limit reached for AI chatting. The API quota has been exhausted and will reset tomorrow."
                } else {
                    "Error: ${e.message}. (Make sure you have configured a valid GEMINI_API_KEY)."
                }
                db.dao().insertAiChat(AiChat(role = "model", message = msg, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))
            } finally {
                isGenerating.value = false
            }
        }
    }
}""",
    content,
    flags=re.DOTALL
)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)

