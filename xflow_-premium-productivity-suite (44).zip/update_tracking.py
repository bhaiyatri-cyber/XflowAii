import re

with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

offline_block = """                    } else if (!schedule.isOnlineMode) {
                        // Offline Mode: Track continuously regardless of screen state
                        trackingAny = true
                        val newElapsed = schedule.elapsedSeconds + 1
                        db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                        titleText = "Offline Tracking: ${schedule.subject}"
                        contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                        if (newElapsed >= targetTime) {
                            db.dao().insertHistory(
                                com.example.data.HistorySession(
                                    scheduleId = schedule.id,
                                    subject = schedule.subject,
                                    mode = if (isDuration) "Duration" else "Exact Time",
                                    date = System.currentTimeMillis(),
                                    timeStudiedSeconds = newElapsed,
                                    completionPercentage = 100,
                                    status = "Completed"
                                )
                            )
                            db.dao().deactivateSchedule(schedule.id)
                            sendAlertNotification(
                                "Goal Reached \\uD83C\\uDF89",
                                "You've completed your focus session for '${schedule.subject}'!",
                                schedule.id + 2000
                            )
                        }
                    }"""

new_offline_block = """                    } else if (!schedule.isOnlineMode) {
                        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                        val isScreenOn = powerManager.isInteractive
                        
                        if (!isScreenOn) {
                            trackingAny = true
                            if (schedule.elapsedSeconds < targetTime) {
                                // increment elapsed
                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                titleText = "Offline Tracking: ${schedule.subject}"
                                contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                            } else {
                                // elapsed is at target, increment overtime
                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                titleText = "🔥 Offline Overtime: ${schedule.subject}"
                                contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                            }
                        } else {
                            if (schedule.elapsedSeconds >= targetTime) {
                                // Screen turned on during overtime or right after finishing
                                db.dao().insertHistory(
                                    com.example.data.HistorySession(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        mode = if (isDuration) "Duration" else "Exact Time",
                                        date = System.currentTimeMillis(),
                                        timeStudiedSeconds = schedule.elapsedSeconds,
                                        completionPercentage = 100,
                                        status = "Completed"
                                    )
                                )
                                if (schedule.overtimeSeconds > 0) {
                                    db.dao().insertOvertimeEntry(
                                        com.example.data.OvertimeEntry(
                                            scheduleId = schedule.id,
                                            subject = schedule.subject,
                                            overtimeSeconds = schedule.overtimeSeconds,
                                            date = System.currentTimeMillis()
                                        )
                                    )
                                }
                                db.dao().deactivateSchedule(schedule.id)
                                sendAlertNotification(
                                    "Goal Reached \uD83C\uDF89",
                                    "You've completed your focus session for '${schedule.subject}'!",
                                    schedule.id + 2000
                                )
                            } else {
                                db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                            }
                        }
                    }"""

content = content.replace(offline_block, new_offline_block)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)
