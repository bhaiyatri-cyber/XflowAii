with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

target = """fun StatCard(
    modifier: Modifier = Modifier,
    title: String = "",
    value: String,
    isAccent: Boolean = false,
    text: String = "",
    icon: androidx.compose.ui.graphics.vector.ImageVector = androidx.compose.material.icons.Icons.Default.Add
) {"""

replacement = """fun StatCard(
    modifier: Modifier = Modifier,
    title: String = "",
    value: String,
    overtimeText: String = "",
    isAccent: Boolean = false,
    text: String = "",
    icon: androidx.compose.ui.graphics.vector.ImageVector = androidx.compose.material.icons.Icons.Default.Add
) {"""

content = content.replace(target, replacement)

target2 = """            androidx.compose.material3.Text(
                text = value,
                style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = if (isAccent) com.example.ui.theme.XFlowAccent else com.example.ui.theme.XFlowTextPrimary
            )
        }
    }
}"""

replacement2 = """            androidx.compose.material3.Text(
                text = value,
                style = androidx.compose.material3.MaterialTheme.typography.headlineSmall,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = if (isAccent) com.example.ui.theme.XFlowAccent else com.example.ui.theme.XFlowTextPrimary
            )
            if (overtimeText.isNotEmpty()) {
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(4.dp))
                androidx.compose.material3.Text(
                    text = overtimeText,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                    color = com.example.ui.theme.XFlowAccent,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                )
            }
        }
    }
}"""

content = content.replace(target2, replacement2)

target3 = """                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours) + if (todayOvertimeHours > 0f) String.format("\\n+%.1fh OT", todayOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours) + if (lifetimeOvertimeHours > 0f) String.format("\\n+%.1fh OT", lifetimeOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )"""

replacement3 = """                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    overtimeText = if (todayOvertimeHours > 0f) String.format("+%.1fh OT", todayOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours),
                    overtimeText = if (lifetimeOvertimeHours > 0f) String.format("+%.1fh OT", lifetimeOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )"""

content = content.replace(target3, replacement3)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)

print("Patched StatCard")
