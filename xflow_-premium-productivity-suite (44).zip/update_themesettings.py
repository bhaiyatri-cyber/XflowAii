import re

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'r') as f:
    content = f.read()

new_ui = """            val currentThemeStyle by viewModel.themeStyle.collectAsStateWithLifecycle()
            val themeStyles = listOf("Dark", "Light", "Neon")
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Base Theme Style (PRO)", style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                if (!isPremium) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Default.Lock, contentDescription = "Locked", tint = XFlowTextSecondary, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                themeStyles.forEach { style ->
                    FilterChip(
                        selected = currentThemeStyle == style,
                        onClick = {
                            if (isPremium) {
                                viewModel.updateThemeStyle(style)
                            } else {
                                showPremiumDialog = true
                            }
                        },
                        label = { Text(style) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = XFlowAccent,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(32.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {"""

content = content.replace("            Row(verticalAlignment = Alignment.CenterVertically) {\n                Text(\"Custom Theme (PRO)\"", new_ui + '\n                Text("Custom Theme (PRO)"')

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'w') as f:
    f.write(content)
