with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("@Composable\n@Composable\nfun ScheduleCard", "@Composable\nfun ScheduleCard")

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
