with open('app/src/main/java/com/example/ui/BackupRestoreScreen.kt', 'r') as f:
    content = f.read()

# Add imports
if 'rememberScrollState' not in content:
    content = content.replace(
        'import androidx.compose.foundation.layout.*',
        'import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.rememberScrollState\nimport androidx.compose.foundation.verticalScroll'
    )

# Add verticalScroll
content = content.replace(
    '.padding(16.dp),',
    '.padding(16.dp)\n                .verticalScroll(rememberScrollState()),'
)

with open('app/src/main/java/com/example/ui/BackupRestoreScreen.kt', 'w') as f:
    f.write(content)
