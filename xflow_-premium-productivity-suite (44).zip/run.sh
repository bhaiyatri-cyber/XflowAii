gradle :app:assembleDebug > build.log 2>&1
cat build.log
