with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

old_sys = 'systemInstruction = Content(parts = listOf(Part(text = "You are XFlow AI, a helpful assistant. You help users with study tips, productivity, and focus techniques.")))'
new_sys = 'systemInstruction = Content(parts = listOf(Part(text = "You are XFlow AI, a helpful assistant. You help users with study tips, productivity, and focus techniques. IF the user asks to create or generate a mock test (e.g., \'mujhe 10 number ka science test bana do\' or \'create a 5 question math test\'), you MUST respond EXACTLY with the following format: [GENERATE_MOCK_TEST:number:topic] and nothing else. For example: [GENERATE_MOCK_TEST:10:science]. Do not add any conversational text.")))'

content = content.replace(old_sys, new_sys)

old_response_handling = """                val response = RetrofitClient.service.generateContent(apiKey, request)
                val responseText = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "I'm sorry, I couldn't generate a response."
                db.dao().insertAiChat(AiChat(role = "model", message = responseText, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))"""

new_response_handling = """                val response = RetrofitClient.service.generateContent(apiKey, request)
                var responseText = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "I'm sorry, I couldn't generate a response."
                
                if (responseText.contains("[GENERATE_MOCK_TEST:")) {
                    try {
                        val parts = responseText.substringAfter("[GENERATE_MOCK_TEST:").substringBefore("]").split(":")
                        val number = parts.getOrNull(0)?.toIntOrNull() ?: 5
                        val topic = parts.getOrNull(1) ?: "General Knowledge"
                        
                        val prompt = "Generate $number multiple choice questions about $topic. Respond ONLY with valid JSON in this exact format: [{\"q\": \"Question text?\", \"options\": [\"A\", \"B\", \"C\", \"D\"], \"ans\": 0}] where ans is the index (0-3) of the correct option. No markdown, no code blocks, just raw JSON."
                        val jsonRequest = GenerateContentRequest(
                            contents = listOf(Content(role = "user", parts = listOf(Part(text = prompt))))
                        )
                        val jsonResponse = RetrofitClient.service.generateContent(apiKey, jsonRequest)
                        var jsonText = jsonResponse.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "[]"
                        jsonText = jsonText.replace("```json", "").replace("```", "").trim()
                        
                        val newTest = MockTest(
                            title = "$topic Test",
                            testDataJson = jsonText,
                            date = System.currentTimeMillis(),
                            totalQuestions = number
                        )
                        val testId = db.dao().insertMockTest(newTest).toInt()
                        responseText = "[MOCK_TEST_CARD:$testId:$topic Test]"
                    } catch (e: Exception) {
                        responseText = "Sorry, I encountered an error generating the mock test."
                    }
                }
                
                db.dao().insertAiChat(AiChat(role = "model", message = responseText, timestamp = System.currentTimeMillis(), sessionId = currentSessionId.value))"""

content = content.replace(old_response_handling, new_response_handling)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)

