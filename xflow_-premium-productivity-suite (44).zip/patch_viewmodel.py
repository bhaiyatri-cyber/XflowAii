import re

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

new_properties = """    val todayOvertimeHours: StateFlow<Float> = overtimeEntries.map { list ->
        val todayStart = System.currentTimeMillis() - (24 * 60 * 60 * 1000)
        list.filter { it.date > todayStart }.sumOf { it.overtimeSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val lifetimeOvertimeHours: StateFlow<Float> = overtimeEntries.map { list ->
        list.sumOf { it.overtimeSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)
"""

if 'todayOvertimeHours' not in content:
    content = content.replace('    init {', new_properties + '\n    init {')
    with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
        f.write(content)
    print("Patched ViewModel")
else:
    print("Already patched")
