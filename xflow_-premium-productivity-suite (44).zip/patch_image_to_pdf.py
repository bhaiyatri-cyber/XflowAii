import re

with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'r') as f:
    content = f.read()

# Add KeyboardOptions import
if "import androidx.compose.foundation.text.KeyboardOptions" not in content:
    content = content.replace("import androidx.compose.foundation.text.KeyboardActions\n", "")
    content = content.replace("import androidx.compose.ui.text.font.FontWeight\n", "import androidx.compose.ui.text.font.FontWeight\nimport androidx.compose.foundation.text.KeyboardOptions\nimport androidx.compose.ui.text.input.KeyboardType\n")

old_tabs = """            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = XFlowBackground,
                contentColor = XFlowAccent
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("Create", color = if (selectedTabIndex == 0) XFlowAccent else XFlowTextSecondary) }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("History", color = if (selectedTabIndex == 1) XFlowAccent else XFlowTextSecondary) }
                )
            }
            
            if (selectedTabIndex == 0) {
                CreatePdfTab(onPdfCreated = { selectedTabIndex = 1 })
            } else {
                PdfHistoryTab(onPdfSelected = { selectedPdfFile = it })
            }"""

new_tabs = """            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = XFlowBackground,
                contentColor = XFlowAccent
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("Create", color = if (selectedTabIndex == 0) XFlowAccent else XFlowTextSecondary) }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("History", color = if (selectedTabIndex == 1) XFlowAccent else XFlowTextSecondary) }
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    text = { Text("Compress", color = if (selectedTabIndex == 2) XFlowAccent else XFlowTextSecondary) }
                )
            }
            
            when (selectedTabIndex) {
                0 -> CreatePdfTab(onPdfCreated = { selectedTabIndex = 1 })
                1 -> PdfHistoryTab(onPdfSelected = { selectedPdfFile = it })
                2 -> CompressPdfTab(onPdfCompressed = { selectedTabIndex = 1 })
            }"""

content = content.replace(old_tabs, new_tabs)

compress_tab_code = """
@Composable
fun CompressPdfTab(onPdfCompressed: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    var selectedPdfFile by remember { mutableStateOf<File?>(null) }
    var targetSizeKb by remember { mutableStateOf("1024") }
    var isCompressing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    
    val savedPdfs = remember { PdfGenerator.getSavedPdfs(context) }
    var showPdfSelector by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (selectedPdfFile == null) {
            Button(
                onClick = { showPdfSelector = true },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowTextPrimary)
            ) {
                Text("Select PDF to Compress")
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Article, contentDescription = "PDF", tint = XFlowAccent)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(selectedPdfFile!!.name, style = MaterialTheme.typography.bodyLarge, color = XFlowTextPrimary)
                        Text("${selectedPdfFile!!.length() / 1024} KB", style = MaterialTheme.typography.bodyMedium, color = XFlowTextSecondary)
                    }
                    IconButton(onClick = { selectedPdfFile = null }) {
                        Icon(Icons.Filled.Close, contentDescription = "Remove", tint = XFlowTextPrimary)
                    }
                }
            }
            
            OutlinedTextField(
                value = targetSizeKb,
                onValueChange = { targetSizeKb = it },
                label = { Text("Target Size (KB)", color = XFlowTextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XFlowAccent,
                    unfocusedBorderColor = XFlowSurfaceVariant,
                    focusedTextColor = XFlowTextPrimary,
                    unfocusedTextColor = XFlowTextPrimary
                )
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Button(
                onClick = {
                    val target = targetSizeKb.toLongOrNull()
                    if (target == null || target <= 0) {
                        message = "Please enter a valid target size."
                        return@Button
                    }
                    isCompressing = true
                    message = "Compressing... This may take a while."
                    coroutineScope.launch {
                        val result = PdfGenerator.compressPdf(context, selectedPdfFile!!, target)
                        isCompressing = false
                        if (result != null) {
                            Toast.makeText(context, "Compressed successfully to ${result.length() / 1024} KB", Toast.LENGTH_LONG).show()
                            selectedPdfFile = null
                            onPdfCompressed()
                        } else {
                            message = "Failed to compress PDF."
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = !isCompressing,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = XFlowBackground)
            ) {
                if (isCompressing) {
                    CircularProgressIndicator(color = XFlowBackground, modifier = Modifier.size(24.dp))
                } else {
                    Text("Compress PDF", fontWeight = FontWeight.Bold)
                }
            }
        }
        
        if (message != null) {
            Text(
                text = message!!,
                color = if (isCompressing) XFlowSupport else XFlowError,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
    
    if (showPdfSelector) {
        AlertDialog(
            onDismissRequest = { showPdfSelector = false },
            title = { Text("Select PDF") },
            text = {
                if (savedPdfs.isEmpty()) {
                    Text("No saved PDFs found.")
                } else {
                    LazyColumn {
                        items(savedPdfs) { file ->
                            Text(
                                text = file.name,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedPdfFile = file
                                        showPdfSelector = false
                                    }
                                    .padding(16.dp)
                            )
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPdfSelector = false }) {
                    Text("Close")
                }
            }
        )
    }
}
"""

if "import androidx.compose.material.icons.filled.Close" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.MoreVert\n", "import androidx.compose.material.icons.filled.MoreVert\nimport androidx.compose.material.icons.filled.Close\nimport androidx.compose.material.icons.filled.Article\n")

if "fun CompressPdfTab" not in content:
    content += compress_tab_code

with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'w') as f:
    f.write(content)

print("Patched ImageToPdfScreen with CompressPdfTab")
