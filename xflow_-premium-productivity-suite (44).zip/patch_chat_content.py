import re

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()

# Add missing import for textAlign
if 'import androidx.compose.ui.text.style.TextAlign' not in content:
    content = content.replace('import androidx.compose.ui.text.font.FontWeight', 'import androidx.compose.ui.text.font.FontWeight\nimport androidx.compose.ui.text.style.TextAlign')


old_chat_content = """@Composable
fun ChatContent(viewModel: AiViewModel, isPremium: Boolean) {
    val aiChats by viewModel.aiChats.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    LaunchedEffect(aiChats.size) {
        if (aiChats.isNotEmpty()) {
            listState.animateScrollToItem(aiChats.size - 1)
        }
    }
    Column(modifier = Modifier.fillMaxSize().imePadding()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (aiChats.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                        Text("How can I help you today?", color = XFlowTextSecondary)
                    }
                }
            }
            items(aiChats) { chat ->
                ChatBubble(chat)
            }
            if (isGenerating) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "AI",
                                tint = XFlowAccent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            TypingIndicator()
                        }
                    }
                }
            }
        }
        if (isPremium) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(XFlowSurfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    BasicTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier.weight(1f).padding(vertical = 8.dp),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = XFlowTextPrimary),
                        cursorBrush = SolidColor(XFlowAccent),
                        decorationBox = { innerTextField ->
                            if (inputText.isEmpty()) {
                                Text("Message XFlow AI...", color = XFlowTextSecondary, style = MaterialTheme.typography.bodyLarge)
                            }
                            innerTextField()
                        }
                    )
                    
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank() && !isGenerating) {
                                viewModel.sendMessage(inputText)
                                inputText = ""
                            }
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .background(if (inputText.isNotBlank()) XFlowAccent else XFlowSurfaceVariant, RoundedCornerShape(20.dp))
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = if (inputText.isNotBlank()) Color.White else XFlowTextSecondary)
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurfaceVariant)
            ) {
                Text(
                    "AI Chat is a Premium feature.",
                    modifier = Modifier.padding(16.dp),
                    color = XFlowTextPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}"""

new_chat_content = """@Composable
fun ChatContent(viewModel: AiViewModel, isPremium: Boolean) {
    val aiChats by viewModel.aiChats.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()

    LaunchedEffect(aiChats.size) {
        if (aiChats.isNotEmpty()) {
            listState.animateScrollToItem(aiChats.size - 1)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().imePadding()) {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp, bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (aiChats.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                // Logo
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome, 
                                    contentDescription = "Logo",
                                    tint = Color(0xFF4A90E2),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(Modifier.height(16.dp))
                                Text("Ask away, yatri!", color = Color.White, style = MaterialTheme.typography.headlineMedium)
                            }
                        }
                    }
                }
                
                items(aiChats) { chat ->
                    ChatBubble(chat)
                }

                if (isGenerating) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = "AI",
                                    tint = XFlowAccent,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                TypingIndicator()
                            }
                        }
                    }
                }
            }
        }
        
        // Gradient overlay at the bottom
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(180.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color(0xFF001133).copy(alpha = 0.5f), Color(0xFF001133))
                    )
                )
        )
        
        // Floating Input Bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .padding(bottom = 16.dp)
                .imePadding()
        ) {
            if (isPremium) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color(0xFF1E1E1E))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { /* Add logic */ }, modifier = Modifier.size(40.dp)) {
                        Icon(Icons.Filled.Add, contentDescription = "Add", tint = Color.LightGray)
                    }
                    
                    BasicTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 12.dp),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.White),
                        cursorBrush = SolidColor(XFlowAccent),
                        decorationBox = { innerTextField ->
                            if (inputText.isEmpty()) {
                                Text("Ask FlowX", color = Color.Gray, style = MaterialTheme.typography.bodyLarge)
                            }
                            innerTextField()
                        }
                    )
                    
                    if (inputText.isBlank()) {
                        IconButton(onClick = { /* Mic */ }, modifier = Modifier.size(40.dp)) {
                            Icon(Icons.Filled.Mic, contentDescription = "Mic", tint = Color.LightGray)
                        }
                        IconButton(
                            onClick = { /* Voice Mode */ },
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .size(40.dp)
                                .background(Color(0xFF334466), RoundedCornerShape(20.dp))
                        ) {
                            Icon(Icons.Filled.GraphicEq, contentDescription = "Voice Mode", tint = Color.White)
                        }
                    } else {
                        IconButton(
                            onClick = {
                                if (inputText.isNotBlank() && !isGenerating) {
                                    viewModel.sendMessage(inputText)
                                    inputText = ""
                                }
                            },
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .size(40.dp)
                                .background(Color(0xFF334466), RoundedCornerShape(20.dp))
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    shape = RoundedCornerShape(32.dp)
                ) {
                    Text(
                        "AI Chat is a Premium feature.",
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}"""

content = content.replace(old_chat_content, new_chat_content)

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)
