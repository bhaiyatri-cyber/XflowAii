with open('app/src/main/java/com/example/ui/MockTestAttemptScreen.kt', 'r') as f:
    lines = f.readlines()

new_lines = lines[:232]
# Find the start of manual submit
start_idx = -1
for i, line in enumerate(lines):
    if "Button(" in line and "onClick = {" in lines[i+1] and "isTimerRunning = false" in lines[i+2]:
        start_idx = i
        break

end_idx = -1
for i in range(start_idx, len(lines)):
    if 'Text("Submit")' in lines[i]:
        end_idx = i + 3
        break

correct_submit_block = """                            Button(
                                onClick = {
                                    isTimerRunning = false
                                    var score = 0
                                    for (i in 0 until totalQuestions) {
                                        val q = questionsArray.getJSONObject(i)
                                        val ansIndex = q.getInt("answerIndex")
                                        if (userAnswers[i] == ansIndex) {
                                            score++
                                        }
                                    }
                                    
                                    val ansJson = JSONObject()
                                    userAnswers.forEach { (k, v) -> ansJson.put(k.toString(), v) }
                                    ansJson.put("timeTaken", timeTaken)
                                    
                                    val updatedTest = mockTest!!.copy(
                                        score = score,
                                        totalQuestions = totalQuestions,
                                        isCompleted = true,
                                        userAnswersJson = ansJson.toString()
                                    )
                                    scope.launch {
                                        dao.updateMockTest(updatedTest)
                                        mockTest = updatedTest
                                        showResults = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                                enabled = userAnswers.size == totalQuestions
                            ) {
                                Text("Submit")
                            }
                        }
                    }
                }
            }
        }
    }
}
"""

new_content = "".join(lines[:start_idx]) + correct_submit_block + "".join(lines[end_idx+6:])

with open('app/src/main/java/com/example/ui/MockTestAttemptScreen.kt', 'w') as f:
    f.write(new_content)
