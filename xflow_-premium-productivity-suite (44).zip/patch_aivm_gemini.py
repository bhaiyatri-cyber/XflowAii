with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

old_gen_config = """                    generationConfig = if (isMockTestRequest) {
                         GenerationConfig(
                             responseFormat = ResponseFormat(
                                 text = ResponseFormatText(
                                     mimeType = "application/json"
                                 )
                             )
                         )
                    } else null,"""

new_gen_config = """                    generationConfig = if (isMockTestRequest) {
                         GenerationConfig(
                             responseMimeType = "application/json"
                         )
                    } else null,"""
content = content.replace(old_gen_config, new_gen_config)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
