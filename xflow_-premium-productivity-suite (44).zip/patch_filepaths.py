with open('app/src/main/res/xml/filepaths.xml', 'r') as f:
    content = f.read()

if 'external-files-path name="download"' not in content:
    content = content.replace('</paths>', '    <external-files-path name="download" path="Download/" />\n</paths>')
    with open('app/src/main/res/xml/filepaths.xml', 'w') as f:
        f.write(content)
