import re

with open('app/src/main/java/com/example/ui/YouTubeScreen.kt', 'r') as f:
    content = f.read()

old_settings = """                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false"""

new_settings = """                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.setSupportZoom(true)
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false"""

content = content.replace(old_settings, new_settings)

with open('app/src/main/java/com/example/ui/YouTubeScreen.kt', 'w') as f:
    f.write(content)

