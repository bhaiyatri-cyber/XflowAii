import re

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()

# Make sure BasicTextField is imported
if 'import androidx.compose.foundation.text.BasicTextField' not in content:
    content = content.replace(
        'import androidx.compose.foundation.background',
        'import androidx.compose.foundation.background\nimport androidx.compose.foundation.text.BasicTextField'
    )
if 'import androidx.compose.ui.graphics.SolidColor' not in content:
    content = content.replace(
        'import androidx.compose.ui.graphics.Color',
        'import androidx.compose.ui.graphics.Color\nimport androidx.compose.ui.graphics.SolidColor'
    )

old_input = """        if (isPremium) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask anything or 'Create a mock test'...") },
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = XFlowAccent,
                        unfocusedBorderColor = XFlowSurfaceVariant,
                        focusedTextColor = XFlowTextPrimary
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank() && !isGenerating) {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(XFlowAccent, RoundedCornerShape(24.dp))
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                }
            }
        }"""

new_input = """        if (isPremium) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(XFlowSurfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    BasicTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier.weight(1f).padding(vertical = 8.dp),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = XFlowTextPrimary),
                        cursorBrush = SolidColor(XFlowAccent),
                        decorationBox = { innerTextField ->
                            if (inputText.isEmpty()) {
                                Text("Message XFlow AI...", color = XFlowTextSecondary, style = MaterialTheme.typography.bodyLarge)
                            }
                            innerTextField()
                        }
                    )
                    
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank() && !isGenerating) {
                                viewModel.sendMessage(inputText)
                                inputText = ""
                            }
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .background(if (inputText.isNotBlank()) XFlowAccent else XFlowSurfaceVariant, RoundedCornerShape(20.dp))
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = if (inputText.isNotBlank()) Color.White else XFlowTextSecondary)
                    }
                }
            }
        }"""
content = content.replace(old_input, new_input)


old_bubble = """        } else {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth(0.85f).padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "AI",
                    tint = XFlowAccent,
                    modifier = Modifier.size(24.dp).padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = 4.dp,
                            bottomEnd = 16.dp
                        ))
                        .background(XFlowSurfaceVariant)
                        .padding(12.dp)
                ) {
                    Text(
                        text = displayedText,
                        color = XFlowTextPrimary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }"""

new_bubble = """        } else {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "AI",
                    tint = XFlowAccent,
                    modifier = Modifier.size(24.dp).padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = displayedText,
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f).padding(top = 2.dp)
                )
            }
        }"""
content = content.replace(old_bubble, new_bubble)


with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)
