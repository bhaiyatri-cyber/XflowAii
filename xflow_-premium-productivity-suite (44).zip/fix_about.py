with open('app/src/main/java/com/example/ui/AboutScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'Offline Face-Down Tracking',
    'Offline Tracking'
)

with open('app/src/main/java/com/example/ui/AboutScreen.kt', 'w') as f:
    f.write(content)
