with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import android.app.NotificationChannel',
    'import android.app.NotificationChannel\nimport android.app.PendingIntent\nimport android.net.Uri'
)

old_alert = """            val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setAutoCancel(true)
                .setVibrate(longArrayOf(0, 2000))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()"""
new_alert = """            val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("xflow://home"))
            val pendingIntent = PendingIntent.getActivity(this, id, deepLinkIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

            val notification = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_recent_history)
                .setAutoCancel(true)
                .setVibrate(longArrayOf(0, 2000))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()"""
content = content.replace(old_alert, new_alert)

old_notif = """        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .build()"""
new_notif = """        val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("xflow://home"))
        val pendingIntent = PendingIntent.getActivity(this, 0, deepLinkIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()"""
content = content.replace(old_notif, new_notif)

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)
