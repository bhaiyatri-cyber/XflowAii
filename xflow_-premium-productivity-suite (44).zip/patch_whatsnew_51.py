import re

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

old_changes = """                    val changes = listOf(
                        "Lock Screen Notifications: See tracking updates without unlocking your phone.",
                        "History Layout Fixes: Fixed the layout shrinking issue in the All Time history view.",
                        "Improved Overtime Tracking: Track daily and all-time overtime.",
                        "Under-the-hood bug fixes and UI performance improvements."
                    )"""

new_changes = """                    val changes = listOf(
                        "Fixed Data & Web Hub: You can now download and open files easily.",
                        "YouTube Sizing: Videos now properly scale to fit the screen.",
                        "ChatGPT Fix: Resolved loading issues and optimized the chat view.",
                        "Full-Screen Updates: Removed popup dialogs for a cleaner update announcement screen.",
                        "Performance and stability improvements."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)

