content = """package com.example.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.data.MockTest
import com.example.data.XFlowDatabase
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockTestAttemptScreen(navController: NavController, testId: Int) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { XFlowDatabase.getDatabase(context).dao() }
    
    var mockTest by remember { mutableStateOf<MockTest?>(null) }
    var currentQuestionIndex by remember { mutableIntStateOf(0) }
    var userAnswers by remember { mutableStateOf<Map<Int, Int>>(emptyMap()) }
    
    var showResults by remember { mutableStateOf(false) }
    var showAnalysis by remember { mutableStateOf(false) }
    
    var timeRemaining by remember { mutableIntStateOf(0) }
    var timeTaken by remember { mutableIntStateOf(0) }
    var isTimerRunning by remember { mutableStateOf(false) }

    LaunchedEffect(testId) {
        mockTest = dao.getMockTestById(testId)
        mockTest?.let { test ->
            if (test.isCompleted) {
                showResults = true
                val ansJson = JSONObject(test.userAnswersJson)
                val ansMap = mutableMapOf<Int, Int>()
                ansJson.keys().forEach { key ->
                    if (key != "timeTaken") ansMap[key.toInt()] = ansJson.getInt(key)
                }
                userAnswers = ansMap
                if (ansJson.has("timeTaken")) timeTaken = ansJson.getInt("timeTaken")
            } else {
                val testData = JSONObject(test.testDataJson)
                val totalQ = testData.getJSONArray("questions").length()
                timeRemaining = totalQ * 60 // 1 min per question
                isTimerRunning = true
            }
        }
    }
    
    LaunchedEffect(isTimerRunning, timeRemaining) {
        if (isTimerRunning && timeRemaining > 0) {
            delay(1000L)
            timeRemaining--
            timeTaken++
        } else if (isTimerRunning && timeRemaining == 0) {
            isTimerRunning = false
            // Auto submit
            val test = mockTest ?: return@LaunchedEffect
            val testData = JSONObject(test.testDataJson)
            val questionsArray = testData.getJSONArray("questions")
            val totalQuestions = questionsArray.length()
            
            var score = 0
            for (i in 0 until totalQuestions) {
                val q = questionsArray.getJSONObject(i)
                val ansIndex = q.getInt("answerIndex")
                if (userAnswers[i] == ansIndex) score++
            }
            
            val ansJson = JSONObject()
            userAnswers.forEach { (k, v) -> ansJson.put(k.toString(), v) }
            ansJson.put("timeTaken", timeTaken)
            
            val updatedTest = test.copy(
                score = score,
                totalQuestions = totalQuestions,
                isCompleted = true,
                userAnswersJson = ansJson.toString()
            )
            scope.launch {
                dao.updateMockTest(updatedTest)
                mockTest = updatedTest
                showResults = true
            }
        }
    }

    if (mockTest == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = XFlowAccent)
        }
        return
    }

    val test = mockTest!!
    val testData = JSONObject(test.testDataJson)
    val questionsArray = testData.getJSONArray("questions")
    val totalQuestions = questionsArray.length()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mock Test", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        if (totalQuestions == 0) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No questions found.", color = XFlowTextPrimary)
            }
            return@Scaffold
        }
        
        if (showAnalysis) {
            MockTestAnalysis(test, questionsArray, userAnswers, padding)
        } else if (showResults) {
            MockTestResults(test, timeTaken, padding) { showAnalysis = true }
        } else {
            val currentQuestion = questionsArray.getJSONObject(currentQuestionIndex)
            val qText = currentQuestion.getString("q")
            val optionsArray = currentQuestion.getJSONArray("options")

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Question ${currentQuestionIndex + 1} of $totalQuestions",
                        color = XFlowTextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = String.format("%02d:%02d", timeRemaining / 60, timeRemaining % 60),
                        color = XFlowAccent,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = qText,
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(32.dp))

                for (i in 0 until optionsArray.length()) {
                    val optionText = optionsArray.getString(i)
                    val isSelected = userAnswers[currentQuestionIndex] == i

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .clickable {
                                val newAnswers = userAnswers.toMutableMap()
                                newAnswers[currentQuestionIndex] = i
                                userAnswers = newAnswers
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) XFlowAccent.copy(alpha = 0.2f) else XFlowSurfaceVariant
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 0.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = null,
                                colors = RadioButtonDefaults.colors(selectedColor = XFlowAccent, unselectedColor = XFlowTextSecondary)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(text = optionText, color = XFlowTextPrimary)
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.height(32.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (currentQuestionIndex > 0) {
                        OutlinedButton(
                            onClick = { currentQuestionIndex-- },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = XFlowAccent)
                        ) {
                            Text("Previous")
                        }
                    } else {
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    if (currentQuestionIndex < totalQuestions - 1) {
                        Button(
                            onClick = { currentQuestionIndex++ },
                            colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                            enabled = userAnswers.containsKey(currentQuestionIndex)
                        ) {
                            Text("Next")
                        }
                    } else {
                        Button(
                            onClick = {
                                isTimerRunning = false
                                var score = 0
                                for (i in 0 until totalQuestions) {
                                    val q = questionsArray.getJSONObject(i)
                                    val ansIndex = q.getInt("answerIndex")
                                    if (userAnswers[i] == ansIndex) {
                                        score++
                                    }
                                }
                                
                                val ansJson = JSONObject()
                                userAnswers.forEach { (k, v) -> ansJson.put(k.toString(), v) }
                                ansJson.put("timeTaken", timeTaken)
                                
                                val updatedTest = mockTest!!.copy(
                                    score = score,
                                    totalQuestions = totalQuestions,
                                    isCompleted = true,
                                    userAnswersJson = ansJson.toString()
                                )
                                scope.launch {
                                    dao.updateMockTest(updatedTest)
                                    mockTest = updatedTest
                                    showResults = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                            enabled = userAnswers.size == totalQuestions
                        ) {
                            Text("Submit")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MockTestResults(test: MockTest, timeTaken: Int, padding: PaddingValues, onShowAnalysis: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = XFlowAccent, modifier = Modifier.size(80.dp))
        Spacer(modifier = Modifier.height(24.dp))
        Text("Test Completed!", color = XFlowTextPrimary, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(32.dp))
        
        Card(
            colors = CardDefaults.cardColors(containerColor = XFlowSurface),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Your Score", color = XFlowTextSecondary, style = MaterialTheme.typography.titleMedium)
                Text("${test.score} / ${test.totalQuestions}", color = XFlowTextPrimary, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                
                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = XFlowSurfaceVariant)
                Spacer(modifier = Modifier.height(16.dp))
                
                Text("Time Taken", color = XFlowTextSecondary, style = MaterialTheme.typography.titleMedium)
                Text(String.format("%02d:%02d", timeTaken / 60, timeTaken % 60), color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = onShowAnalysis,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent)
        ) {
            Text("View Analysis", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MockTestAnalysis(test: MockTest, questionsArray: JSONArray, userAnswers: Map<Int, Int>, padding: PaddingValues) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "Analysis",
            color = XFlowTextPrimary,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        for (i in 0 until test.totalQuestions) {
            val q = questionsArray.getJSONObject(i)
            val qText = q.getString("q")
            val optionsArray = q.getJSONArray("options")
            val correctIndex = q.getInt("answerIndex")
            val selectedIndex = userAnswers[i] ?: -1
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Q${i + 1}: $qText", color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    for (j in 0 until optionsArray.length()) {
                        val optionText = optionsArray.getString(j)
                        val isCorrect = j == correctIndex
                        val isSelected = j == selectedIndex
                        
                        val textColor = when {
                            isCorrect -> Color(0xFF4CAF50)
                            isSelected && !isCorrect -> Color(0xFFF44336)
                            else -> XFlowTextSecondary
                        }
                        val icon = when {
                            isCorrect -> "✓"
                            isSelected && !isCorrect -> "✗"
                            else -> "•"
                        }
                        
                        Text(
                            text = "$icon $optionText",
                            color = textColor,
                            modifier = Modifier.padding(vertical = 4.dp),
                            fontWeight = if (isCorrect || isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}
"""
with open('app/src/main/java/com/example/ui/MockTestAttemptScreen.kt', 'w') as f:
    f.write(content)
