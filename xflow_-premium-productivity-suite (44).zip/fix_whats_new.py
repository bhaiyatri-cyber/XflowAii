import re

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('fun WhatsNewScreen(onDismiss: () -> Unit) {', 'fun WhatsNewScreen(isFirstInstall: Boolean = false, onDismiss: () -> Unit) {')

content = content.replace('text = "App Updated to ${com.example.BuildConfig.VERSION_NAME}!",', 'text = if (isFirstInstall) "Welcome to XFlow Premium!" else "App Updated to ${com.example.BuildConfig.VERSION_NAME}!",')

content = content.replace('text = "What\'s New in this version:",', 'text = if (isFirstInstall) "What you can do with XFlow:" else "What\'s New in this version:",')

replacement = """                    val changes = if (isFirstInstall) listOf(
                        "Study Plans & Timers: Create and manage strict focus schedules to maximize your productivity.",
                        "AI Chat & Mock Tests: Use our Gemini-powered AI Assistant to generate quizzes, get focus tips, and more.",
                        "Premium Themes: Customize your experience with beautiful card styles and premium UI components.",
                        "Detailed Analytics: Track your daily and lifetime study hours, streaks, and focus metrics."
                    ) else listOf(
                        "Mock Tests: Generate and take custom MCQ mock tests on any topic using the new AI Assistant.",
                        "Fixed Chat Overlap: Corrected visual bugs in the AI Assistant chat interface where messages would overlap.",
                        "Updated Notification Icon: Notifications now display the premium app logo instead of the old default icon."
                    )"""

content = re.sub(r'val changes = listOf\(.*?\)[\s\S]*?(?=\s*changes\.forEach)', replacement + "\n\n", content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)

