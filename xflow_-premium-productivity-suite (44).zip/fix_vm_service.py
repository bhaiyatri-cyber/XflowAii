with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

import re

old_start = """if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }"""

new_start = """try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }"""

content = content.replace(old_start, new_start)

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(content)
