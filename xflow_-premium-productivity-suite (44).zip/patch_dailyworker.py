with open('app/src/main/java/com/example/service/DailySummaryWorker.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import android.app.NotificationChannel',
    'import android.app.NotificationChannel\nimport android.app.PendingIntent\nimport android.content.Intent\nimport android.net.Uri'
)

old_notif = """    private fun sendPremiumNotification(title: String, text: String, id: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    "xflow_daily_vibrate",
                    "Daily Summary",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                val manager = context.getSystemService(NotificationManager::class.java)
                channel.enableVibration(true)
                channel.vibrationPattern = longArrayOf(0, 2000)
                manager?.createNotificationChannel(channel)
            }
            
            val notification = NotificationCompat.Builder(context, "xflow_daily_vibrate")
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.star_on) // using a star icon for premium look
                .setColor(0xFFFFD700.toInt()) // Gold color
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setVibrate(longArrayOf(0, 2000))
                .build()
            
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Ignore
        }
    }"""
new_notif = """    private fun sendPremiumNotification(title: String, text: String, id: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    "xflow_daily_vibrate",
                    "Daily Summary",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                val manager = context.getSystemService(NotificationManager::class.java)
                channel.enableVibration(true)
                channel.vibrationPattern = longArrayOf(0, 2000)
                manager?.createNotificationChannel(channel)
            }
            
            val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("xflow://home"))
            val pendingIntent = PendingIntent.getActivity(context, id, deepLinkIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

            val notification = NotificationCompat.Builder(context, "xflow_daily_vibrate")
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.star_on) // using a star icon for premium look
                .setColor(0xFFFFD700.toInt()) // Gold color
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setVibrate(longArrayOf(0, 2000))
                .build()
            
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Ignore
        }
    }"""
content = content.replace(old_notif, new_notif)

with open('app/src/main/java/com/example/service/DailySummaryWorker.kt', 'w') as f:
    f.write(content)
