with open('gradle/libs.versions.toml', 'r') as f:
    content = f.read()

content = content.replace('[versions]\n', '[versions]\nkotlinxSerializationJson = "1.6.3"\nretrofitConverterSerialization = "2.11.0"\n')

lib_addition = """retrofit = { group = "com.squareup.retrofit2", name = "retrofit", version.ref = "retrofit" }
kotlinx-serialization-json = { group = "org.jetbrains.kotlinx", name = "kotlinx-serialization-json", version.ref = "kotlinxSerializationJson" }
retrofit-converter-serialization = { group = "com.squareup.retrofit2", name = "converter-kotlinx-serialization", version.ref = "retrofitConverterSerialization" }"""
content = content.replace('retrofit = { group = "com.squareup.retrofit2", name = "retrofit", version.ref = "retrofit" }', lib_addition)

plugin_addition = """google-services = { id = "com.google.gms.google-services", version.ref = "googleServices" }
kotlin-serialization = { id = "org.jetbrains.kotlin.plugin.serialization", version.ref = "kotlin" }"""
content = content.replace('google-services = { id = "com.google.gms.google-services", version.ref = "googleServices" }', plugin_addition)

with open('gradle/libs.versions.toml', 'w') as f:
    f.write(content)
