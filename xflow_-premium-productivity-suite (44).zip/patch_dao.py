import re

with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

func = """    @Query("DELETE FROM aichats")
    suspend fun deleteAllAiChats()
"""

content = content.replace('    @Insert', func + '\n    @Insert')

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)
