with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

import re

# Fix PremiumStudyPlanButton
new_premium_btn = """fun PremiumStudyPlanButton(isPremium: Boolean, onClick: () -> Unit) {
    val brush = androidx.compose.ui.graphics.Brush.linearGradient(
        colors = listOf(
            androidx.compose.ui.graphics.Color(0xFFFFD700),
            androidx.compose.ui.graphics.Color(0xFFFFA500)
        )
    )
    Box(
        modifier = Modifier
            .padding(end = 8.dp)
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(XFlowSurface)
            .border(
                width = 2.dp,
                brush = brush,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Add, contentDescription = "Study Plan", tint = androidx.compose.ui.graphics.Color(0xFFFFD700), modifier = Modifier.size(16.dp))
            Text("Study Plan", color = XFlowTextPrimary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            if (!isPremium) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text("PRO", color = androidx.compose.ui.graphics.Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}"""

pattern_premium = r'fun PremiumStudyPlanButton.*?\}\s*\}'
content = re.sub(pattern_premium, new_premium_btn, content, flags=re.DOTALL)

# Fix OnlineAnimation using graphicsLayer
new_online_anim = """@Composable
fun OnlineAnimation() {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(4000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        )
    )
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(XFlowSurfaceVariant.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        val accent = XFlowAccent
        
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(accent)
            )
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .androidx.compose.ui.graphics.graphicsLayer { rotationZ = rotation }
            ) {
                val appColors = listOf(
                    androidx.compose.ui.graphics.Color(0xFF4285F4),
                    androidx.compose.ui.graphics.Color(0xFF34A853),
                    androidx.compose.ui.graphics.Color(0xFFFBBC05),
                    androidx.compose.ui.graphics.Color(0xFFEA4335)
                )
                
                Box(modifier = Modifier.size(12.dp).align(Alignment.TopCenter).clip(RoundedCornerShape(3.dp)).background(appColors[0]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.CenterEnd).clip(RoundedCornerShape(3.dp)).background(appColors[1]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.BottomCenter).clip(RoundedCornerShape(3.dp)).background(appColors[2]))
                Box(modifier = Modifier.size(12.dp).align(Alignment.CenterStart).clip(RoundedCornerShape(3.dp)).background(appColors[3]))
            }
        }
    }
}"""

pattern_online = r'@Composable\s*fun OnlineAnimation\(\)\s*\{.*?\}\s*\}\s*\}\s*\}\s*\}'
content = re.sub(pattern_online, new_online_anim, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
