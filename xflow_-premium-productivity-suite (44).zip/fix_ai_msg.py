with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'val reply = "I am running in offline mode. Please configure a valid Gemini API Key (starting with \'AIza\') in Settings/Secrets to enable full AI chat. For now, try asking me to \'create a mock test\' or \'create a schedule\'."',
    'val reply = "I am running in offline mode. The Gemini API Key was not configured properly during the build. For now, try asking me to \'create a mock test\' or \'create a schedule\'."'
)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
