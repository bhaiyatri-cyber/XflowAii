with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

bad_string = '''"What's New in this version:

• Cleaned up App Settings menu
• Improved Theme & Appearance section
• Enhanced layout and spacing
• Removed clutter from dashboard stats
• Under-the-hood bug fixes and performance improvements"'''

good_string = '\"\"\"What\'s New in this version:\\n\\n• Cleaned up App Settings menu\\n• Improved Theme & Appearance section\\n• Enhanced layout and spacing\\n• Removed clutter from dashboard stats\\n• Under-the-hood bug fixes and performance improvements\"\"\"'

content = content.replace(bad_string, good_string)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
