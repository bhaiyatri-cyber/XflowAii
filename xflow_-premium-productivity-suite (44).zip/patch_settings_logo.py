import re

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('import androidx.compose.foundation.layout.*', 'import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.ui.draw.clip\nimport androidx.compose.foundation.shape.RoundedCornerShape')

old_logo = """                Icon(
                    imageVector = Icons.Default.AvTimer,
                    contentDescription = "XFlow Logo",
                    tint = XFlowAccent,
                    modifier = Modifier.size(64.dp)
                )"""

new_logo = """                Image(
                    painter = painterResource(id = R.drawable.app_logo),
                    contentDescription = "XFlow Logo",
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
                )"""

content = content.replace(old_logo, new_logo)

old_dialog_logo = """                    Icon(Icons.Default.AvTimer, contentDescription = "Logo", tint = XFlowAccent, modifier = Modifier.size(32.dp))"""
new_dialog_logo = """                    Image(painter = painterResource(id = R.drawable.app_logo), contentDescription = "Logo", modifier = Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)))"""

content = content.replace(old_dialog_logo, new_dialog_logo)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)
