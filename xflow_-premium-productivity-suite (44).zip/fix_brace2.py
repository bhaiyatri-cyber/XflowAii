with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("            }\n        }\n    }\n}\n\n@Composable\nfun HistoryScreen", "            }\n        }\n    }\n    }\n}\n\n@Composable\nfun HistoryScreen")

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
