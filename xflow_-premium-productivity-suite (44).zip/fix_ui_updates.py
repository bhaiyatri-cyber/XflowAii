with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

# Make sure version 66 is referenced
if "version 65" in content.lower():
    content = content.replace("version 65", "version 66").replace("Version 65", "Version 66")

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)

