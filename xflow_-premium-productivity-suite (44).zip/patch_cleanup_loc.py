import re

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

# Remove cleanupOldUpdates() from start of checkForUpdate
content = content.replace('        cleanupOldUpdates()\n        CoroutineScope', '        CoroutineScope')

# Put it before startDownload
old_start = """                            prefs.edit().putInt("last_downloaded_version", latestVersion).apply()
                            
                            withContext(Dispatchers.Main) {
                                startDownload(downloadUrl)
                            }"""

new_start = """                            prefs.edit().putInt("last_downloaded_version", latestVersion).apply()
                            
                            // Delete old apks before downloading the new one
                            cleanupOldUpdates()
                            
                            withContext(Dispatchers.Main) {
                                startDownload(downloadUrl)
                            }"""
content = content.replace(old_start, new_start)

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)
