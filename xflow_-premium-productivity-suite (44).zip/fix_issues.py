import re

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'r') as f:
    content = f.read()

if 'import androidx.compose.foundation.horizontalScroll' not in content:
    content = content.replace('import androidx.compose.foundation.verticalScroll', 'import androidx.compose.foundation.verticalScroll\nimport androidx.compose.foundation.horizontalScroll')

old_row = """            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cardStyles.forEach { style ->"""
new_row = """            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                cardStyles.forEach { style ->"""
content = content.replace(old_row, new_row)

with open('app/src/main/java/com/example/ui/ThemeSettingsScreen.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/CreateScheduleScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'options = listOf("Online", "Offline (Face-down)")',
    'options = listOf("Online", "Offline")'
)

with open('app/src/main/java/com/example/ui/CreateScheduleScreen.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/StudyPlanScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'options = listOf("Online", "Offline (Face-down)")',
    'options = listOf("Online", "Offline")'
)

with open('app/src/main/java/com/example/ui/StudyPlanScreen.kt', 'w') as f:
    f.write(content)
