with open('app/build.gradle.kts', 'r') as f:
    content = f.read()
content = content.replace('versionCode = 68', 'versionCode = 69').replace('versionName = "68.0"', 'versionName = "69.0"')
with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
