with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    vm = f.read()

old_insert = """                    title = name,
                    description = "$description\\nTime: $time",
                    totalDurationMinutes = 25,
                    isPomodoro = true,
                    isActive = true"""
new_insert = """                    subject = name,
                    description = "$description\\nTime: $time",
                    isDurationMode = true,
                    durationMinutes = 25,
                    startTimeStr = "",
                    endTimeStr = "",
                    isOnlineMode = false,
                    selectedAppPackage = null,
                    isActive = true"""

vm = vm.replace(old_insert, new_insert)

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(vm)
