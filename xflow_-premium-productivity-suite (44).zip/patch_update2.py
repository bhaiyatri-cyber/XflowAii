with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

# Make sure we use applicationContext
content = content.replace('class UpdateManager(private val context: Context) {', 'class UpdateManager(context: Context) {\n\n    private val context = context.applicationContext')

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)
print("Patched UpdateManager to use applicationContext")
