import re

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

# Replace top version hardcode
content = re.sub(
    r'Text\(\s*text\s*=\s*"Version [^"]+",\s*color\s*=\s*XFlowTextSecondary,',
    r'Text(\n                    text = "Version ${com.example.BuildConfig.VERSION_NAME}",\n                    color = XFlowTextSecondary,',
    content
)

# Remove "App Details" section entirely
# Note: we need to remove:
#             SettingsSection("App Details") {
#                 SettingsItem(icon = Icons.Default.Info, title = "App Version", subtitle = "1.1.1 (Build 1)", onClick = { showStatsDialog = true })
#             }
app_details_regex = r'SettingsSection\("App Details"\)\s*\{[\s\S]*?\}\n'
content = re.sub(app_details_regex, '', content)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)

