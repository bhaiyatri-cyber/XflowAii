with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'StudyStatus.RUNNING -> Badge(text = "In Progress", isAccent = true)',
    'StudyStatus.RUNNING -> Badge(text = "Live 🔴", isAccent = true)'
)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
