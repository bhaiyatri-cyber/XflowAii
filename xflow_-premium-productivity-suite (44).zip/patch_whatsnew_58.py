import re

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'r') as f:
    content = f.read()

old_changes = """                    val changes = listOf(
                        "Premium New Logo: Rebranded the entire app with a fresh, futuristic abstract XFlow monogram.",
                        "Security Enhancements: Advanced security protocols added to protect your flow data.",
                        "Bug Fixes: General system stability improvements and UI refinements."
                    )"""

new_changes = """                    val changes = listOf(
                        "Abstract Monogram Logo: Redesigned the brand identity with a premium geometric icon combining X, F, L, O, and W elements.",
                        "Performance & Security: Enhanced core security and fixed various bugs for a smoother, safer experience.",
                        "Consistent Branding: The new premium logo is now seamlessly integrated across the Home, Splash, Settings, and Notifications."
                    )"""

content = content.replace(old_changes, new_changes)

with open('app/src/main/java/com/example/ui/WhatsNewScreen.kt', 'w') as f:
    f.write(content)
