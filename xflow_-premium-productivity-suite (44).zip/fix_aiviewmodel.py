with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace('recentChats.removeFirst()', 'recentChats.removeAt(0)')
content = content.replace('alternatingChats.removeLast()', 'alternatingChats.removeAt(alternatingChats.lastIndex)')

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)

print("AiViewModel fixed")
