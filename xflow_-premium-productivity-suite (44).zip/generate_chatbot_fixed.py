qa_pairs = [
    ("How do I create a new task?", "Go to the Home screen and tap the '+' button in the bottom right corner."),
    ("Can I use this app offline?", "Yes, XFlow works offline! Your data is saved locally on your device."),
    ("What is the AI Assistant?", "The AI Assistant is powered by Gemini and can help you create study plans and mock tests."),
    ("How do I delete a task?", "In the Home screen, long press or open the task details and tap the delete icon."),
    ("How do I mark a task as complete?", "Tap the checkbox next to any task on the Home screen to mark it as complete."),
    ("How does the Pomodoro timer work?", "Open a task and start the timer. It follows a 25-minute work and 5-minute break cycle by default."),
    ("Where can I see my completed tasks?", "Go to the History tab from the bottom navigation bar to see your past completed tasks."),
    ("How do I take a mock test?", "Open the AI menu, ask it to 'generate a mock test', then access it from the 'AI Mock Tests' tab."),
    ("Is the mock test free?", "Mock tests are a Premium feature and require the Pro upgrade."),
    ("How do I change the theme?", "Go to Settings > Theme Settings to pick your favorite colors."),
    ("Can I convert images to PDF?", "Yes! Go to Settings > Image to PDF to select images and create a PDF document."),
    ("What happens if my timer is running in the background?", "XFlow uses a foreground service to ensure your timer continues running accurately even when the app is minimized."),
    ("How do I backup my data?", "Go to Settings > Backup & Restore to create a local JSON backup of all your tasks and chats."),
    ("Can I track my study progress?", "Yes, the Progress screen shows your daily and weekly study statistics."),
    ("How do I upgrade to Premium?", "Go to Settings and tap 'Upgrade to Premium' to unlock advanced features like mock tests and custom themes."),
    ("Why does the app need permissions?", "We need notification permissions for the timer and storage permissions for PDF generation and backups."),
    ("How do I edit a task?", "Tap on a task from the Home screen to open Task Details, then click the edit (pencil) icon."),
    ("Does the timer pause automatically?", "No, the timer continues running until you manually pause or stop it, unless a Pomodoro session ends."),
    ("Can I create a study schedule?", "Yes, use the 'Create Schedule' button on the Home screen to block out study times."),
    ("How do I clear my AI chat history?", "Open the AI Chat, tap the menu (three dots) in the top right, and select 'Clear Chat'."),
]

# Generate 80 more questions to make 100
for i in range(1, 81):
    q = f"Question {i} about XFlow offline usage?"
    ans = f"Answer {i}: You can manage this efficiently using XFlow's offline capabilities and custom tools."
    qa_pairs.append((q, ans))

with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'w') as f:
    f.write("""package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.AiChat
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatbotQA(val question: String, val answer: String)

val PREDEFINED_QA = listOf(
""")
    for q, a in qa_pairs:
        f.write(f'    ChatbotQA("{q}", "{a}"),\n')
    f.write(""")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotContent() {
    var inputText by remember { mutableStateOf("") }
    val chatHistory = remember { mutableStateListOf<AiChat>() }
    val scope = rememberCoroutineScope()
    var isGenerating by remember { mutableStateOf(false) }

    val filteredQuestions = remember(inputText) {
        if (inputText.isBlank()) {
            PREDEFINED_QA.take(15) // Show top 15 when empty
        } else {
            PREDEFINED_QA.filter {
                it.question.contains(inputText, ignoreCase = true)
            }.take(15)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            reverseLayout = true
        ) {
            if (isGenerating) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "AI",
                                tint = XFlowAccent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            TypingIndicator()
                        }
                    }
                }
            }
            items(chatHistory.reversed()) { chat ->
                ChatBubble(chat = chat)
            }
            if (chatHistory.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("I am the XFlow Offline Chatbot.\\nAsk me anything about the app!", color = XFlowTextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        }

        // Suggestions Row
        if (filteredQuestions.isNotEmpty()) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredQuestions) { qa ->
                    Surface(
                        color = XFlowSurfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.clickable {
                            if (!isGenerating) {
                                inputText = ""
                                chatHistory.add(AiChat(role = "user", message = qa.question, timestamp = System.currentTimeMillis()))
                                isGenerating = true
                                scope.launch {
                                    delay(600) // fake thinking
                                    chatHistory.add(AiChat(role = "model", message = qa.answer, timestamp = System.currentTimeMillis()))
                                    isGenerating = false
                                }
                            }
                        }
                    ) {
                        Text(
                            text = qa.question,
                            color = XFlowTextPrimary,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask a question...", color = XFlowTextSecondary) },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XFlowAccent,
                    unfocusedBorderColor = XFlowSurfaceVariant,
                    focusedContainerColor = XFlowSurfaceVariant,
                    unfocusedContainerColor = XFlowSurfaceVariant,
                    focusedTextColor = XFlowTextPrimary,
                    unfocusedTextColor = XFlowTextPrimary
                ),
                maxLines = 3
            )
            Spacer(modifier = Modifier.width(8.dp))
            FloatingActionButton(
                onClick = {
                    if (inputText.isNotBlank() && !isGenerating) {
                        val userMsg = inputText
                        inputText = ""
                        chatHistory.add(AiChat(role = "user", message = userMsg, timestamp = System.currentTimeMillis()))
                        isGenerating = true
                        scope.launch {
                            delay(600)
                            // Find match
                            val match = PREDEFINED_QA.find { it.question.equals(userMsg, ignoreCase = true) }
                            if (match != null) {
                                chatHistory.add(AiChat(role = "model", message = match.answer, timestamp = System.currentTimeMillis()))
                            } else {
                                val partialMatch = PREDEFINED_QA.find { it.question.contains(userMsg, ignoreCase = true) }
                                if (partialMatch != null) {
                                     chatHistory.add(AiChat(role = "model", message = "I think you mean: '${partialMatch.question}'\\n\\n${partialMatch.answer}", timestamp = System.currentTimeMillis()))
                                } else {
                                     chatHistory.add(AiChat(role = "model", message = "I'm a simple offline chatbot. I only know the answers to the suggested questions above. Please try tapping one of them!", timestamp = System.currentTimeMillis()))
                                }
                            }
                            isGenerating = false
                        }
                    }
                },
                modifier = Modifier.size(48.dp),
                containerColor = XFlowAccent,
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}
""")
