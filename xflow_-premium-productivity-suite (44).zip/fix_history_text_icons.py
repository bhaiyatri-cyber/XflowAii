with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

target = """                                    Icon(
                                        imageVector = if (isExpanded) androidx.compose.material.icons.Icons.Default.run { androidx.compose.material.icons.filled.ArrowDropUp } else androidx.compose.material.icons.Icons.Default.run { androidx.compose.material.icons.filled.ArrowDropDown },
                                        contentDescription = "Toggle",
                                        tint = XFlowTextSecondary
                                    )"""
replacement = """                                    Text(
                                        text = if (isExpanded) "▲" else "▼",
                                        color = XFlowTextSecondary,
                                        style = MaterialTheme.typography.titleMedium
                                    )"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
print("Replaced with Text")
