with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('androidx.compose.material.icons.filled.KeyboardArrowDown', 'androidx.compose.material.icons.filled.ArrowDropDown')
content = content.replace('androidx.compose.material.icons.filled.KeyboardArrowUp', 'androidx.compose.material.icons.filled.ArrowDropUp')

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
print("Fixed icons")
