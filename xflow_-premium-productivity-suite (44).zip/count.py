with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    text = f.read()

count = 0
in_string = False
escaped = False
stack = []
for i, c in enumerate(text):
    if c == '"' and not escaped:
        in_string = not in_string
    if c == '\\':
        escaped = not escaped
    else:
        escaped = False
    
    if not in_string:
        if c == '{': 
            count += 1
            stack.append(i)
        elif c == '}':
            count -= 1
            if count < 0:
                print(f"Negative at {i}, near {text[max(0, i-20):min(len(text), i+20)]}")
                break
            stack.pop()

print("Final count:", count)
if count > 0:
    for i in stack:
        print(f"Unclosed at {i}, near {text[max(0, i-20):min(len(text), i+20)]}")

