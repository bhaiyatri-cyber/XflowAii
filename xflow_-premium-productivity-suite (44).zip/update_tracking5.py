import re
import io

with io.open('app/src/main/java/com/example/service/TrackingService.kt', 'r', encoding='utf-8') as f:
    content = f.read()

pattern = re.compile(r'\} else if \(\!schedule\.isOnlineMode\) \{.*?\/\/ Offline Mode.*?(?=\n\s*updateNotification\()', re.DOTALL)

new_code = r"""} else if (!schedule.isOnlineMode) {
                        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                        val isScreenOn = powerManager.isInteractive
                        
                        if (!isScreenOn) {
                            trackingAny = true
                            if (schedule.elapsedSeconds < targetTime) {
                                // increment elapsed
                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                titleText = "Offline Tracking: ${schedule.subject}"
                                contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                            } else {
                                // elapsed is at target, increment overtime
                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                titleText = "🔥 Offline Overtime: ${schedule.subject}"
                                contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                            }
                        } else {
                            if (schedule.elapsedSeconds >= targetTime) {
                                // Screen turned on during overtime or right after finishing
                                db.dao().insertHistory(
                                    com.example.data.HistorySession(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        mode = if (isDuration) "Duration" else "Exact Time",
                                        date = System.currentTimeMillis(),
                                        timeStudiedSeconds = schedule.elapsedSeconds,
                                        completionPercentage = 100,
                                        status = "Completed"
                                    )
                                )
                                if (schedule.overtimeSeconds > 0) {
                                    db.dao().insertOvertimeEntry(
                                        com.example.data.OvertimeEntry(
                                            scheduleId = schedule.id,
                                            subject = schedule.subject,
                                            overtimeSeconds = schedule.overtimeSeconds,
                                            date = System.currentTimeMillis()
                                        )
                                    )
                                }
                                db.dao().deactivateSchedule(schedule.id)
                                sendAlertNotification(
                                    "Goal Reached \uD83C\uDF89",
                                    "You've completed your focus session for '${schedule.subject}'!",
                                    schedule.id + 2000
                                )
                            } else {
                                db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                            }
                        }
                    }
                }"""

updated_content = pattern.sub(new_code, content)

with io.open('app/src/main/java/com/example/service/TrackingService.kt', 'w', encoding='utf-8') as f:
    f.write(updated_content)
