import re

with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()
content = content.replace('database.execSQL', 'db.execSQL')
with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/AiScreen.kt', 'r') as f:
    content = f.read()
content = content.replace('Icons.AutoMirrored.Filled.Article', 'Icons.Filled.Article')
with open('app/src/main/java/com/example/ui/AiScreen.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'r') as f:
    content = f.read()
content = content.replace('Icons.AutoMirrored.Filled.Article', 'Icons.Filled.Article')
with open('app/src/main/java/com/example/ui/ImageToPdfScreen.kt', 'w') as f:
    f.write(content)

print("Compiler errors fixed")
