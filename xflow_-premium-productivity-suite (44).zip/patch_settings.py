with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    content = f.read()

target1 = """            SettingsSection("Data & Web") {
                SettingsItem(icon = Icons.Filled.Public, title = "Data Drive", subtitle = "Secure In-App Browser & Storage", onClick = onNavigateToDataDrive)
                SettingsItem(icon = Icons.Filled.PlayCircle, title = "YouTube", subtitle = "Watch videos in full screen", onClick = onNavigateToYouTube)
                SettingsItem(icon = Icons.Filled.Chat, title = "ChatGPT", subtitle = "AI Chat Assistant", onClick = onNavigateToChatGPT)
            }"""

replacement1 = """            SettingsSection("Data & Web") {
                SettingsItem(icon = Icons.Filled.Public, title = "Data & Web Hub", subtitle = "Access Data Drive, YouTube & ChatGPT", onClick = { showDataOptions = true })
            }"""

target2 = """            SettingsSection("Tools / Utilities") {
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "24h Daily Report", subtitle = "Study vs Wasted Time", onClick = onNavigateToDailyReport)
                SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { if (isPremium) onNavigateToPdf() else showPremiumDialog = true })
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "🔥 Overtime (PRO)", onClick = { if (isPremium) onNavigateToOvertime() else showPremiumDialog = true })
                SettingsItem(icon = Icons.Default.Build, title = "Backup & Restore", onClick = onNavigateToBackup)
            }"""

replacement2 = """            SettingsSection("Tools / Utilities") {
                SettingsItem(icon = Icons.Default.Build, title = "Tools Hub", subtitle = "Access all utilities & tools", onClick = { showToolOptions = true })
            }"""

content = content.replace(target1, replacement1)
content = content.replace(target2, replacement2)

var_decl = """    var showStatsDialog by remember { mutableStateOf(false) }"""
var_decl_new = """    var showStatsDialog by remember { mutableStateOf(false) }
    var showDataOptions by remember { mutableStateOf(false) }
    var showToolOptions by remember { mutableStateOf(false) }"""

content = content.replace(var_decl, var_decl_new)

# Add BottomSheets at the end of the Scaffold
end_scaffold = """            Spacer(modifier = Modifier.height(32.dp))
        }
    }"""

bottom_sheets = """            Spacer(modifier = Modifier.height(32.dp))
        }
    }
    
    if (showDataOptions) {
        ModalBottomSheet(
            onDismissRequest = { showDataOptions = false },
            containerColor = XFlowSurface,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                Text("Data & Web Hub", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                SettingsItem(icon = Icons.Filled.Public, title = "Data Drive", subtitle = "Secure In-App Browser & Storage", onClick = { showDataOptions = false; onNavigateToDataDrive() })
                SettingsItem(icon = Icons.Filled.PlayCircle, title = "YouTube", subtitle = "Watch videos in full screen", onClick = { showDataOptions = false; onNavigateToYouTube() })
                SettingsItem(icon = Icons.Filled.Chat, title = "ChatGPT", subtitle = "AI Chat Assistant", onClick = { showDataOptions = false; onNavigateToChatGPT() })
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
    
    if (showToolOptions) {
        ModalBottomSheet(
            onDismissRequest = { showToolOptions = false },
            containerColor = XFlowSurface,
            contentColor = XFlowTextPrimary
        ) {
            Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                Text("Tools Hub", color = XFlowTextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "24h Daily Report", subtitle = "Study vs Wasted Time", onClick = { showToolOptions = false; onNavigateToDailyReport() })
                SettingsItem(icon = Icons.Default.Build, title = "Image to PDF Converter (PRO)", onClick = { showToolOptions = false; if (isPremium) onNavigateToPdf() else showPremiumDialog = true })
                SettingsItem(icon = androidx.compose.material.icons.Icons.Default.AvTimer, title = "🔥 Overtime (PRO)", onClick = { showToolOptions = false; if (isPremium) onNavigateToOvertime() else showPremiumDialog = true })
                SettingsItem(icon = Icons.Default.Build, title = "Backup & Restore", onClick = { showToolOptions = false; onNavigateToBackup() })
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }"""

content = content.replace(end_scaffold, bottom_sheets)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(content)
