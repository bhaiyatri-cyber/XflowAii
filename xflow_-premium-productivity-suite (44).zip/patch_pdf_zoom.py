import re

with open('app/src/main/java/com/example/ui/PdfViewerScreen.kt', 'r') as f:
    content = f.read()

# Add imports for gesture detection
import_str = """import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
"""
if "detectTransformGestures" not in content:
    content = content.replace("import androidx.compose.ui.unit.dp\n", "import androidx.compose.ui.unit.dp\n" + import_str)

# Modify PdfViewerScreen to add zoom state
old_screen_start = """fun PdfViewerScreen(
    pdfFile: File,
    onBack: () -> Unit
) {
    var pdfRenderer by remember { mutableStateOf<PdfRenderer?>(null) }"""

new_screen_start = """fun PdfViewerScreen(
    pdfFile: File,
    onBack: () -> Unit
) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    
    var pdfRenderer by remember { mutableStateOf<PdfRenderer?>(null) }"""

if "var scale by remember" not in content:
    content = content.replace(old_screen_start, new_screen_start)

old_lazy_column = """        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(androidx.compose.ui.graphics.Color.LightGray)
        ) {"""

new_lazy_column = """        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(androidx.compose.ui.graphics.Color.LightGray)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 5f)
                        val maxOffset = (scale - 1) * size.width // Approximate bounding
                        val x = (offset.x + pan.x * scale).coerceIn(-maxOffset, maxOffset)
                        val y = (offset.y + pan.y * scale).coerceIn(-maxOffset * 2, maxOffset * 2) 
                        offset = androidx.compose.ui.geometry.Offset(x, y)
                    }
                }
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    ),
                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
            ) {"""

if "detectTransformGestures" not in content.replace(new_lazy_column, ""): # just checking if we applied it
    content = content.replace(old_lazy_column, new_lazy_column)
    content = content.replace("            }\n        }\n    }\n}", "            }\n            }\n        }\n    }\n}") # Add closing bracket for Box

with open('app/src/main/java/com/example/ui/PdfViewerScreen.kt', 'w') as f:
    f.write(content)
print("Patched PDF Zoom")
