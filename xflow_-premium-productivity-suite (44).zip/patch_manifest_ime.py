with open('app/src/main/AndroidManifest.xml', 'r') as f:
    content = f.read()

content = content.replace(
    'android:name=".MainActivity"\n            android:exported="true"',
    'android:name=".MainActivity"\n            android:exported="true"\n            android:windowSoftInputMode="adjustResize"'
)

with open('app/src/main/AndroidManifest.xml', 'w') as f:
    f.write(content)
