import os
print(os.path.exists(".env"))
with open(".env", "a") as f:
    f.write("\nGEMINI_API_KEY=AIzaSyBw...\n")
