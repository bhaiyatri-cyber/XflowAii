with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'r') as f:
    chatbot = f.read()
chatbot = chatbot.replace('androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack', 'androidx.compose.material.icons.automirrored.filled.ArrowBack')
chatbot = chatbot.replace('import androidx.compose.material.icons.Icons', 'import androidx.compose.material.icons.Icons\nimport androidx.compose.material.icons.automirrored.filled.ArrowBack')
chatbot = chatbot.replace('Icon(androidx.compose.material.icons.automirrored.filled.ArrowBack', 'Icon(Icons.AutoMirrored.Filled.ArrowBack')
with open('app/src/main/java/com/example/ui/ChatbotScreen.kt', 'w') as f:
    f.write(chatbot)

with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'r') as f:
    settings = f.read()
settings = settings.replace('androidx.compose.material.icons.Icons.AutoMirrored.Filled.Message', 'androidx.compose.material.icons.Icons.Default.MailOutline')
with open('app/src/main/java/com/example/ui/SettingsScreen.kt', 'w') as f:
    f.write(settings)
