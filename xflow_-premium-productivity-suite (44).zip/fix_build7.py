import re
with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace('        envFile.appendText("GEMINI_API_KEY=$ciGeminiKey")', '        envFile.appendText("\\nGEMINI_API_KEY=$ciGeminiKey\\n")')

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
