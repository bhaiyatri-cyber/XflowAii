import re

with open('app/build.gradle.kts', 'r') as f:
    content = f.read()

content = content.replace("""    } 
    else {
        val newContent = propContent.replace(Regex("GEMINI_API_KEY=.*"), "GEMINI_API_KEY=$ciGeminiKey")
        localProps.writeText(newContent)
    }
}""", """    }
}""")

with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
