with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

import re

# Fix PremiumDialog
premium_old = """        if (showPremiumDialog) {
            PremiumDialog(
                onDismiss = { showPremiumDialog = false },
                onActivate = { code -> 
                    val success = viewModel.activatePremium(code)
                    if (success) {
                        showPremiumDialog = false
                        Toast.makeText(context, "PRO Activated!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Invalid PRO code.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }"""
premium_new = """        PremiumDialog(
            showDialog = showPremiumDialog,
            onDismiss = { showPremiumDialog = false },
            viewModel = viewModel
        )"""

content = content.replace(premium_old, premium_new)

# Add clickable import
if "import androidx.compose.foundation.clickable" not in content:
    content = content.replace("import androidx.compose.foundation.background", "import androidx.compose.foundation.background\nimport androidx.compose.foundation.clickable")

with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
