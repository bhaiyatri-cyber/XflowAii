import re

with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

# I will find the block using regex
pattern = re.compile(r'\} else if \(\!schedule\.isOnlineMode\) \{[\s\S]*?\} else if')
# wait, there's no `} else if` after offline block. It ends the loop.
# Let's find the specific block
pattern = re.compile(r'\} else if \(\!schedule\.isOnlineMode\) \{.*?\/\/ Offline Mode.*?updateNotification\(titleText', re.DOTALL)

match = pattern.search(content)
if match:
    # Print the match to see what we are dealing with
    print("MATCH FOUND")
else:
    print("NO MATCH")

