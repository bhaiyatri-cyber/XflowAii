with open('app/src/main/java/com/example/ui/AboutScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('import androidx.compose.ui.unit.dp', 'import androidx.compose.ui.unit.dp\nimport androidx.compose.foundation.Image\nimport androidx.compose.ui.res.painterResource\nimport com.example.R\nimport androidx.compose.ui.Alignment')

with open('app/src/main/java/com/example/ui/AboutScreen.kt', 'w') as f:
    f.write(content)
