import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Add StudyStatus and getResultStatus if not present
if "enum class StudyStatus" not in content:
    content += """

enum class StudyStatus {
    UPCOMING,
    RUNNING,
    PAUSED,
    COMPLETED,
    MISSED
}

fun getResultStatus(percent: Int): String {
    return when (percent) {
        100 -> "Perfect 🏆"
        in 90..99 -> "Outstanding"
        in 80..89 -> "Excellent"
        in 70..79 -> "Very Good"
        in 60..69 -> "Good"
        in 50..59 -> "Average"
        in 40..49 -> "Below Average"
        in 20..39 -> "Poor"
        else -> "Very Poor"
    }
}
"""

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
