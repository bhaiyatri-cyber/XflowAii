with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'r') as f:
    content = f.read()

import re

dialog_old = """    var isOnlineMode by remember { mutableStateOf(schedule.isOnlineMode) }"""
dialog_new = """    var isOnlineMode by remember { mutableStateOf(schedule.isOnlineMode) }
    var durationMinutes by remember { mutableStateOf(schedule.durationMinutes.toString()) }
    var selectedAppPackage by remember { mutableStateOf(schedule.selectedAppPackage ?: "") }"""

content = content.replace(dialog_old, dialog_new)

body_old = """                Spacer(modifier = Modifier.height(16.dp))
                
                Text("Tracking Type", color = XFlowTextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))"""

body_new = """                Spacer(modifier = Modifier.height(12.dp))
                
                if (schedule.isDurationMode) {
                    OutlinedTextField(
                        value = durationMinutes,
                        onValueChange = { durationMinutes = it },
                        label = { Text("Duration (minutes)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = XFlowAccent,
                            unfocusedBorderColor = XFlowSurfaceVariant,
                            focusedLabelColor = XFlowAccent,
                            unfocusedLabelColor = XFlowTextSecondary,
                            focusedTextColor = XFlowTextPrimary,
                            unfocusedTextColor = XFlowTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text("Tracking Type", color = XFlowTextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))"""

content = content.replace(body_old, body_new)

save_old = """                                    subject = subject,
                                    description = description,
                                    isOnlineMode = isOnlineMode
                                ))"""

save_new = """                                    subject = subject,
                                    description = description,
                                    isOnlineMode = isOnlineMode,
                                    durationMinutes = durationMinutes.toIntOrNull() ?: schedule.durationMinutes
                                ))"""

content = content.replace(save_old, save_new)

with open('app/src/main/java/com/example/ui/TaskDetailsScreen.kt', 'w') as f:
    f.write(content)
