with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'r') as f:
    content = f.read()

target = """            request.setTitle("XFlow Update")
            request.setDescription("Downloading new version...")
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)"""

replacement = """            request.setTitle("XFlow Update")
            request.setDescription("Downloading new version...")
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
            request.setAllowedOverRoaming(true)
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/utils/UpdateManager.kt', 'w') as f:
    f.write(content)
