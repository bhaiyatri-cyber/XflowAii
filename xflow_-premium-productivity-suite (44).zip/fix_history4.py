with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    lines = f.readlines()

new_lines = []
for i, line in enumerate(lines):
    if i == 239 and line.strip() == "}":
        continue
    new_lines.append(line)

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.writelines(new_lines)

