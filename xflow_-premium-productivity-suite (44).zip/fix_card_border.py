with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

import re
old = "elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)"
new = "elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),\n        border = androidx.compose.foundation.BorderStroke(1.dp, XFlowSurfaceVariant)"
content = content.replace(old, new)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
