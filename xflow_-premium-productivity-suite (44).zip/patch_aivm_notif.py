with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import android.app.NotificationManager',
    'import android.app.NotificationManager\nimport android.content.Intent\nimport android.app.PendingIntent\nimport android.net.Uri'
)

old_notif_fun = """    private fun sendMockTestReadyNotification(title: String) {
        val context = getApplication<Application>()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "AiMockTestChannel"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "AI Mock Tests",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for AI generated mock tests"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // We'll use a default icon here
            .setContentTitle("Mock Test Ready!")
            .setContentText("Your test '$title' has been generated and is ready to attempt.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }"""

new_notif_fun = """    private fun sendMockTestReadyNotification(title: String, testId: Int) {
        val context = getApplication<Application>()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "AiMockTestChannel"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "AI Mock Tests",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for AI generated mock tests"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse("xflow://mock_test/$testId"))
        val pendingIntent = PendingIntent.getActivity(context, testId, deepLinkIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Mock Test Ready!")
            .setContentText("Your test '$title' has been generated and is ready to attempt. Tap to start!")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        notificationManager.notify(testId, builder.build())
    }"""
content = content.replace(old_notif_fun, new_notif_fun)

old_insert = """                        val testTitle = org.json.JSONObject(responseText).optString("title", "Generated Mock Test")
                        db.dao().insertMockTest(MockTest(
                            title = testTitle,
                            testDataJson = responseText,
                            date = System.currentTimeMillis()
                        ))
                        db.dao().insertAiChat(AiChat(role = "model", message = "I have generated a new Mock Test for you. You can find it in the AI Mock Tests section.", timestamp = System.currentTimeMillis()))
                        sendMockTestReadyNotification(testTitle)"""
new_insert = """                        val testTitle = org.json.JSONObject(responseText).optString("title", "Generated Mock Test")
                        val insertedId = db.dao().insertMockTest(MockTest(
                            title = testTitle,
                            testDataJson = responseText,
                            date = System.currentTimeMillis()
                        ))
                        db.dao().insertAiChat(AiChat(role = "model", message = "I have generated a new Mock Test for you. You can find it in the AI Mock Tests section.", timestamp = System.currentTimeMillis()))
                        sendMockTestReadyNotification(testTitle, insertedId.toInt())"""
content = content.replace(old_insert, new_insert)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
