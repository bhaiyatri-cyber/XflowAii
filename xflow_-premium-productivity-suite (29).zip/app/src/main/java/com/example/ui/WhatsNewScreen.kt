package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

@Composable
fun WhatsNewScreen(onDismiss: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = XFlowBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.WorkspacePremium,
                contentDescription = null,
                tint = XFlowAccent,
                modifier = Modifier.size(120.dp)
            )
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "App Updated to ${com.example.BuildConfig.VERSION_NAME}!",
                style = MaterialTheme.typography.headlineMedium,
                color = XFlowTextPrimary,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(32.dp))
            
            Card(
                colors = CardDefaults.cardColors(containerColor = XFlowSurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "What's New in this version:",
                        style = MaterialTheme.typography.titleLarge,
                        color = XFlowTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    val changes = listOf(
                        "Time Format Improvement: Stats now display hours and minutes intuitively instead of decimals (e.g., 4h 12m instead of 4.2h).",
                        "All Time History Scroll Fix: The entire history page is now fully scrollable so you can easily view your timeline, streaks, and all your history folders without getting stuck.",
                        "Data & Web Hub Fixes: Resolved file download & open issues.",
                        "YouTube & ChatGPT Fixes: Improved scaling, loading, and chat views.",
                        "Full-Screen Updates: Removed popup dialogs for a cleaner screen."
                    )
                    
                    changes.forEach { change ->
                        Row(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(
                                text = "•",
                                style = MaterialTheme.typography.bodyLarge,
                                color = XFlowAccent,
                                modifier = Modifier.padding(end = 8.dp)
                            )
                            Text(
                                text = change,
                                style = MaterialTheme.typography.bodyLarge,
                                color = XFlowTextSecondary
                            )
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text("Awesome, Let's Go!", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
