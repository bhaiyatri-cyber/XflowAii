import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Replace today and lifetime stat cards to omit overtimeText
old_stat_cards = """                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    overtimeText = if (todayOvertimeHours > 0f) String.format("+%.1fh OT", todayOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToTodayHistory() }
                )
                StatCard(
                    title = "All Time",
                    value = String.format("%.1fh", lifetimeHours),
                    overtimeText = if (lifetimeOvertimeHours > 0f) String.format("+%.1fh OT", lifetimeOvertimeHours) else "",
                    modifier = Modifier.weight(1f).clickable { onNavigateToAllTimeHistory() }
                )"""

new_stat_cards = """                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToTodayHistory() }
                )
                StatCard(
                    title = "All Time",
                    value = String.format("%.1fh", lifetimeHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToAllTimeHistory() }
                )"""
content = content.replace(old_stat_cards, new_stat_cards)

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(content)
