with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'r') as f:
    content = f.read()

new_method = """    fun updateSchedule(schedule: Schedule) {
        viewModelScope.launch {
            db.dao().updateSchedule(schedule)
        }
    }

    fun completeSession"""

content = content.replace("    fun completeSession", new_method)

with open('app/src/main/java/com/example/ui/XFlowViewModel.kt', 'w') as f:
    f.write(content)
