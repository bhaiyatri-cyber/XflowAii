import re

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'r') as f:
    content = f.read()

old_func = """    fun sendMessage(message: String) {
        viewModelScope.launch {
            // Check if user is asking for a mock test
            val isMockTestRequest = message.lowercase().contains("mock test") || message.lowercase().contains("test")
            
            db.dao().insertAiChat(AiChat(role = "user", message = message, timestamp = System.currentTimeMillis()))
            
            isGenerating.value = true
            
            val prompt = if (isMockTestRequest) {
                // Generate Mock Test
                "Generate a mock test based on this request: '$message'. Respond ONLY with a valid JSON format (No Markdown block quotes, just the raw JSON) following this structure: {\\"title\\": \\"Title of Test\\", \\"questions\\": [{\\"q\\": \\"Question text\\", \\"options\\": [\\"Option 1\\", \\"Option 2\\", \\"Option 3\\", \\"Option 4\\"], \\"answerIndex\\": 0}]}"
            } else {
                message
            }

            try {
                // Construct history
                val history = aiChats.value.takeLast(10).map { 
                     Content(role = it.role, parts = listOf(Part(text = it.message))) 
                 }.toMutableList()
                 
                if (isMockTestRequest && history.isNotEmpty()) {
                    history[history.size - 1] = Content(role = "user", parts = listOf(Part(text = prompt)))
                }"""

new_func = """    fun sendMessage(message: String) {
        // Capture current history BEFORE we insert the new message
        val currentHistory = aiChats.value.takeLast(10).map { 
            Content(role = it.role, parts = listOf(Part(text = it.message))) 
        }.toMutableList()

        viewModelScope.launch {
            // Check if user is asking for a mock test
            val isMockTestRequest = message.lowercase().contains("mock test") || message.lowercase().contains("test")
            
            db.dao().insertAiChat(AiChat(role = "user", message = message, timestamp = System.currentTimeMillis()))
            
            isGenerating.value = true
            
            val prompt = if (isMockTestRequest) {
                // Generate Mock Test
                "Generate a mock test based on this request: '$message'. Respond ONLY with a valid JSON format (No Markdown block quotes, just the raw JSON) following this structure: {\\"title\\": \\"Title of Test\\", \\"questions\\": [{\\"q\\": \\"Question text\\", \\"options\\": [\\"Option 1\\", \\"Option 2\\", \\"Option 3\\", \\"Option 4\\"], \\"answerIndex\\": 0}]}"
            } else {
                message
            }

            try {
                // Construct history using the captured history, then add the new prompt
                val history = currentHistory
                history.add(Content(role = "user", parts = listOf(Part(text = prompt))))"""

content = content.replace(old_func, new_func)

with open('app/src/main/java/com/example/ui/AiViewModel.kt', 'w') as f:
    f.write(content)
