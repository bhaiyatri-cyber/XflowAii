import re

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'r') as f:
    content = f.read()

# Find the start of the block
start_match = re.search(r'^\s*if \(showPremiumDialog\) \{', content, re.MULTILINE)
if not start_match:
    print("Could not find showPremiumDialog block")
    exit(1)

start_idx = start_match.start()

# Find the end of the block (matching braces)
brace_count = 0
in_block = False
end_idx = -1

for i in range(start_idx, len(content)):
    if content[i] == '{':
        brace_count += 1
        in_block = True
    elif content[i] == '}':
        brace_count -= 1
        
    if in_block and brace_count == 0:
        end_idx = i + 1
        break

if end_idx == -1:
    print("Could not find end of showPremiumDialog block")
    exit(1)

new_dialog = """    if (showPremiumDialog) {
        Dialog(onDismissRequest = { showPremiumDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = XFlowSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "Premium",
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "XFlow Pro",
                        style = MaterialTheme.typography.headlineMedium,
                        color = XFlowTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Unlock exclusive features and elevate your productivity.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = XFlowTextSecondary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    PremiumFeatureRow(Icons.Default.Palette, "Custom Themes & Colors")
                    Spacer(modifier = Modifier.height(12.dp))
                    PremiumFeatureRow(Icons.Default.PictureAsPdf, "Image to PDF Converter")
                    Spacer(modifier = Modifier.height(12.dp))
                    PremiumFeatureRow(Icons.Default.AutoGraph, "Advanced Study Plans")
                    
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    OutlinedTextField(
                        value = premiumCode,
                        onValueChange = { premiumCode = it },
                        label = { Text("Activation Code") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = XFlowAccent,
                            focusedLabelColor = XFlowAccent,
                            cursorColor = XFlowAccent
                        ),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Button(
                        onClick = {
                            if (viewModel.activatePremium(premiumCode)) {
                                showPremiumDialog = false
                                Toast.makeText(context, "Premium Activated!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Invalid Code", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = XFlowBackground),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Upgrade to PRO", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    TextButton(onClick = { showPremiumDialog = false }) {
                        Text("Maybe Later", color = XFlowTextSecondary)
                    }
                }
            }
        }
    }"""

new_content = content[:start_idx] + new_dialog + content[end_idx:]

with open('app/src/main/java/com/example/ui/HomeScreen.kt', 'w') as f:
    f.write(new_content)

print("Patch applied")
