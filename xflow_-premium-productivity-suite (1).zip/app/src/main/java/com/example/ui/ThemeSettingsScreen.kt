package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.XFlowBackground
import com.example.ui.theme.XFlowTextPrimary
import com.example.ui.theme.XFlowTextSecondary
import com.example.ui.theme.XFlowSurface
import com.example.ui.theme.XFlowAccent
import com.example.ui.theme.XFlowSurfaceVariant

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeSettingsScreen(viewModel: XFlowViewModel, onBack: () -> Unit) {
    val currentThemeColorLong by viewModel.themeColor.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val currentThemeColor = Color(currentThemeColorLong)

    var showPremiumDialog by remember { mutableStateOf(false) }

    val freeOptions = listOf(
        ThemeColorOption("Cyan (Default)", 0xFF00E5FF),
        ThemeColorOption("Green", 0xFF10B981),
        ThemeColorOption("Red", 0xFFF43F5E)
    )

    // For custom color picker
    var customHue by remember { mutableStateOf(0f) }
    val customColor = remember(customHue) { Color.hsv(customHue, 1f, 1f) }
    
    // Set custom hue initially if current theme is not in free options
    LaunchedEffect(Unit) {
        if (freeOptions.none { it.colorValue == currentThemeColorLong }) {
            customHue = 180f 
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Theme & Appearance", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Free Themes", style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                freeOptions.forEach { option ->
                    val color = Color(option.colorValue)
                    val isSelected = option.colorValue == currentThemeColorLong
                    
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            viewModel.updateThemeColor(option.colorValue)
                        }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 0.dp,
                                    color = if (isSelected) XFlowTextPrimary else Color.Transparent,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = if (color.luminance() > 0.5f) Color.Black else Color.White
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(option.name, color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            val currentThemeStyle by viewModel.themeStyle.collectAsStateWithLifecycle()
            val themeStyles = listOf("Dark", "Light", "Neon")
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Base Theme Style (PRO)", style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                if (!isPremium) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Default.Lock, contentDescription = "Locked", tint = XFlowTextSecondary, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                themeStyles.forEach { style ->
                    FilterChip(
                        selected = currentThemeStyle == style,
                        onClick = {
                            if (isPremium) {
                                viewModel.updateThemeStyle(style)
                            } else {
                                showPremiumDialog = true
                            }
                        },
                        label = { Text(style) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = XFlowAccent,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(32.dp))

            val currentCardStyle by viewModel.cardStyle.collectAsStateWithLifecycle()
            val cardStyles = listOf("Solid", "Image")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Card Background (PRO)", style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                if (!isPremium) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Default.Lock, contentDescription = "Locked", tint = XFlowTextSecondary, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cardStyles.forEach { style ->
                    FilterChip(
                        selected = currentCardStyle == style,
                        onClick = {
                            if (isPremium) {
                                viewModel.updateCardStyle(style)
                            } else {
                                showPremiumDialog = true
                            }
                        },
                        label = { Text(style) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = XFlowAccent,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(32.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Custom Theme (PRO)", style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                if (!isPremium) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Default.Lock, contentDescription = "Locked", tint = XFlowTextSecondary, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Pick any color you want for buttons, accents, and text highlights.", style = MaterialTheme.typography.bodyMedium, color = XFlowTextSecondary)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Custom Color Picker
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                val maxWidth = constraints.maxWidth.toFloat()
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color.hsv(0f, 1f, 1f),
                                    Color.hsv(60f, 1f, 1f),
                                    Color.hsv(120f, 1f, 1f),
                                    Color.hsv(180f, 1f, 1f),
                                    Color.hsv(240f, 1f, 1f),
                                    Color.hsv(300f, 1f, 1f),
                                    Color.hsv(360f, 1f, 1f)
                                )
                            )
                        )
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                if (!isPremium) {
                                    showPremiumDialog = true
                                    return@detectDragGestures
                                }
                                val position = change.position.x.coerceIn(0f, maxWidth)
                                customHue = (position / maxWidth) * 360f
                            }
                        }
                        .clickable {
                            if (!isPremium) {
                                showPremiumDialog = true
                            }
                        }
                ) {
                    // Selector thumb
                    if (isPremium) {
                        Box(
                            modifier = Modifier
                                .offset(
                                    x = ((customHue / 360f) * (this@BoxWithConstraints.maxWidth.value - 24)).dp,
                                    y = 8.dp
                                )
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(customColor)
                                .border(2.dp, Color.White, CircleShape)
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            if (isPremium) {
                Button(
                    onClick = {
                        val hsvColor = Color.hsv(customHue, 1f, 1f)
                        val r = (hsvColor.red * 255).toLong()
                        val g = (hsvColor.green * 255).toLong()
                        val b = (hsvColor.blue * 255).toLong()
                        val colorLong = 0xFF000000L or (r shl 16) or (g shl 8) or b
                        viewModel.updateThemeColor(colorLong)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = customColor)
                ) {
                    Text("Apply Custom Color", color = if (customColor.luminance() > 0.5f) Color.Black else Color.White, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = { showPremiumDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowTextPrimary)
                ) {
                    Icon(Icons.Default.Lock, contentDescription = "Locked")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Unlock Custom Colors (PRO)")
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            OutlinedCard(
                colors = CardDefaults.outlinedCardColors(containerColor = XFlowSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, currentThemeColor)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(currentThemeColor))
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("This color is applied to buttons and highlights.", color = XFlowTextPrimary)
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
    
    if (showPremiumDialog) {
        AlertDialog(
            onDismissRequest = { showPremiumDialog = false },
            title = { Text("Premium Feature", color = XFlowTextPrimary) },
            text = { Text("Custom colors are a Premium feature. Please upgrade from the Home screen by tapping the 'PRO' badge.", color = XFlowTextSecondary) },
            confirmButton = {
                TextButton(onClick = { showPremiumDialog = false }) {
                    Text("OK", color = XFlowAccent)
                }
            },
            containerColor = XFlowSurface
        )
    }
}

data class ThemeColorOption(val name: String, val colorValue: Long)

fun Color.luminance(): Float {
    val r = this.red.toDouble()
    val g = this.green.toDouble()
    val b = this.blue.toDouble()
    return (0.299 * r + 0.587 * g + 0.114 * b).toFloat()
}
