package com.example.ui

import android.content.pm.PackageManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.Schedule
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items

data class AppInfo(val name: String, val packageName: String)

fun getInstalledApps(pm: PackageManager): List<AppInfo> {
    val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
    return packages.mapNotNull { info ->
        if (pm.getLaunchIntentForPackage(info.packageName) != null) {
            val name = pm.getApplicationLabel(info).toString()
            AppInfo(name, info.packageName)
        } else null
    }.sortedBy { it.name.lowercase() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateScheduleScreen(
    viewModel: XFlowViewModel,
    onBack: () -> Unit
) {
    var subject by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var isDurationMode by remember { mutableStateOf(true) }
    var durationMinutes by remember { mutableStateOf("25") }
    var startTimeStr by remember { mutableStateOf("09:00") }
    var endTimeStr by remember { mutableStateOf("09:25") }
    var isOnlineMode by remember { mutableStateOf(true) }
    var selectedAppPackage by remember { mutableStateOf("com.example.app") } // Default Mock
    var selectedAppName by remember { mutableStateOf("Select App") }
    var showAppSelector by remember { mutableStateOf(false) }
    var appsList by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    
    val context = LocalContext.current
    
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val apps = getInstalledApps(context.packageManager)
            withContext(Dispatchers.Main) {
                appsList = apps
                if (apps.isNotEmpty()) {
                    selectedAppPackage = apps[0].packageName
                    selectedAppName = apps[0].name
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("New Schedule", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = subject,
                onValueChange = { subject = it },
                label = { Text("Subject") },
                modifier = Modifier.fillMaxWidth(),
                colors = outlinedTextFieldColors()
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                modifier = Modifier.fillMaxWidth(),
                colors = outlinedTextFieldColors()
            )
            Spacer(modifier = Modifier.height(24.dp))
            
            Text("Mode", color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            SegmentedControl(
                options = listOf("Duration", "Exact Time"),
                selectedIndex = if (isDurationMode) 0 else 1,
                onOptionSelected = { isDurationMode = it == 0 }
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            if (isDurationMode) {
                OutlinedTextField(
                    value = durationMinutes,
                    onValueChange = { durationMinutes = it },
                    label = { Text("Duration (minutes)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = outlinedTextFieldColors()
                )
            } else {
                val showTimePicker = { isStart: Boolean ->
                    val calendar = java.util.Calendar.getInstance()
                    val currentHour = calendar.get(java.util.Calendar.HOUR_OF_DAY)
                    val currentMinute = calendar.get(java.util.Calendar.MINUTE)
                    
                    android.app.TimePickerDialog(
                        context,
                        { _, hourOfDay, minute ->
                            val timeStr = String.format("%02d:%02d", hourOfDay, minute)
                            if (isStart) startTimeStr = timeStr else endTimeStr = timeStr
                        },
                        currentHour,
                        currentMinute,
                        true
                    ).show()
                }

                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    OutlinedTextField(
                        value = startTimeStr,
                        onValueChange = { },
                        readOnly = true,
                        label = { Text("Start Time") },
                        modifier = Modifier.weight(1f).clickable { showTimePicker(true) },
                        enabled = false,
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = XFlowTextPrimary,
                            disabledBorderColor = XFlowSurfaceVariant,
                            disabledLabelColor = XFlowTextSecondary
                        )
                    )
                    OutlinedTextField(
                        value = endTimeStr,
                        onValueChange = { },
                        readOnly = true,
                        label = { Text("End Time") },
                        modifier = Modifier.weight(1f).clickable { showTimePicker(false) },
                        enabled = false,
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = XFlowTextPrimary,
                            disabledBorderColor = XFlowSurfaceVariant,
                            disabledLabelColor = XFlowTextSecondary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("Tracking Type", color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            SegmentedControl(
                options = listOf("Online", "Offline (Face-down)"),
                selectedIndex = if (isOnlineMode) 0 else 1,
                onOptionSelected = { isOnlineMode = it == 0 }
            )

            if (isOnlineMode) {
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedCard(
                    modifier = Modifier.fillMaxWidth().clickable { showAppSelector = true },
                    colors = CardDefaults.outlinedCardColors(containerColor = XFlowBackground),
                    border = androidx.compose.foundation.BorderStroke(1.dp, XFlowSurfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Target App", color = XFlowTextSecondary, style = MaterialTheme.typography.labelMedium)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(selectedAppName, color = XFlowTextPrimary, style = MaterialTheme.typography.bodyLarge)
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Select App", tint = XFlowTextSecondary)
                    }
                }
            }

            val isFormValid = subject.isNotBlank() &&
                (if (isDurationMode) durationMinutes.isNotBlank() && durationMinutes.toIntOrNull() != null else startTimeStr.isNotBlank() && endTimeStr.isNotBlank()) &&
                (if (isOnlineMode) selectedAppPackage.isNotBlank() else true)

            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = {
                    viewModel.addSchedule(
                        Schedule(
                            subject = subject,
                            description = description,
                            isDurationMode = isDurationMode,
                            durationMinutes = durationMinutes.toIntOrNull() ?: 25,
                            startTimeStr = startTimeStr,
                            endTimeStr = endTimeStr,
                            isOnlineMode = isOnlineMode,
                            selectedAppPackage = if (isOnlineMode) selectedAppPackage else null
                        ),
                        context
                    )
                    onBack()
                },
                enabled = isFormValid,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = XFlowAccent, contentColor = XFlowBackground)
            ) {
                Text("Save Schedule", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showAppSelector) {
        ModalBottomSheet(
            onDismissRequest = { showAppSelector = false },
            containerColor = XFlowSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("Select Target App", style = MaterialTheme.typography.titleMedium, color = XFlowTextPrimary, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                
                if (appsList.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = XFlowAccent)
                    }
                } else {
                    LazyColumn {
                        items(appsList) { app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedAppPackage = app.packageName
                                        selectedAppName = app.name
                                        showAppSelector = false
                                    }
                                    .padding(vertical = 12.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(app.name, color = XFlowTextPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun outlinedTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = XFlowAccent,
    unfocusedBorderColor = XFlowSurfaceVariant,
    focusedLabelColor = XFlowAccent,
    unfocusedLabelColor = XFlowTextSecondary,
    focusedTextColor = XFlowTextPrimary,
    unfocusedTextColor = XFlowTextPrimary,
    cursorColor = XFlowAccent
)

@Composable
fun SegmentedControl(options: List<String>, selectedIndex: Int, onOptionSelected: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(XFlowSurfaceVariant)
            .padding(4.dp)
    ) {
        options.forEachIndexed { index, option ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (index == selectedIndex) XFlowSurface else XFlowSurfaceVariant)
                    .clickable { onOptionSelected(index) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = option,
                    color = if (index == selectedIndex) XFlowTextPrimary else XFlowTextSecondary,
                    fontWeight = if (index == selectedIndex) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}
