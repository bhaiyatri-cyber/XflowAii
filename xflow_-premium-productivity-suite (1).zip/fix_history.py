import re

with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'r') as f:
    content = f.read()

# Add ModalBottomSheet imports
if "import androidx.compose.material3.ModalBottomSheet" not in content:
    content = content.replace("import androidx.compose.material3.*", "import androidx.compose.material3.*\nimport androidx.compose.material3.ModalBottomSheet\nimport androidx.compose.material3.ExperimentalMaterial3Api\nimport androidx.compose.animation.AnimatedVisibility\nimport androidx.compose.animation.fadeIn\nimport androidx.compose.animation.scaleIn\nimport androidx.compose.animation.core.tween")

new_history_card = """@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryCard(session: HistorySession) {
    var showSheet by remember { mutableStateOf(false) }

    val progress = (session.completionPercentage.toFloat() / 100f).coerceIn(0f, 1f)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { showSheet = true },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = XFlowSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, XFlowSurfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(session.subject, color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date(session.date)),
                    color = XFlowTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = if (session.status == "Completed") XFlowSupport else XFlowAccent,
                trackColor = XFlowSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Badge(text = session.status, isAccent = session.status == "Completed")
                Badge(text = session.mode)
                Badge(text = "${session.timeStudiedSeconds / 60} min")
            }
        }
    }

    if (showSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            containerColor = XFlowSurface,
            contentColor = XFlowTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = session.subject,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = XFlowTextPrimary
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault()).format(Date(session.date)),
                    style = MaterialTheme.typography.bodyMedium,
                    color = XFlowTextSecondary
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = session.status,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (session.status == "Completed") XFlowSupport else XFlowTextPrimary
                    )
                    Text(
                        text = "${session.completionPercentage}%",
                        color = XFlowAccent,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (session.status == "Completed") XFlowSupport else XFlowAccent,
                    trackColor = XFlowSurfaceVariant
                )

                Spacer(modifier = Modifier.height(20.dp))

                HorizontalDivider(color = XFlowSurfaceVariant)

                Spacer(modifier = Modifier.height(16.dp))

                val studiedStr = String.format("%02d:%02d:%02d", session.timeStudiedSeconds / 3600, (session.timeStudiedSeconds % 3600) / 60, session.timeStudiedSeconds % 60)
                DetailRow("Studied Time", studiedStr)
                DetailRow("Tracking Mode", session.mode)
                DetailRow("Completion", "${session.completionPercentage}%")
                
                AnimatedVisibility(
                    visible = session.status == "Completed",
                    enter = fadeIn(tween(300)) + scaleIn(tween(350))
                ) {
                    Column(modifier = Modifier.padding(top = 16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("✓ Session Completed", color = XFlowSupport, fontWeight = FontWeight.Bold)
                        Text(getResultStatus(session.completionPercentage), color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium)
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
"""

start_idx = content.find("@Composable\nfun HistoryCard(")
if start_idx != -1:
    end_idx = content.find("@Composable\nfun HistoryScreen", start_idx)
    content = content[:start_idx] + new_history_card + content[end_idx:]
    
with open('app/src/main/java/com/example/ui/HistoryScreen.kt', 'w') as f:
    f.write(content)
