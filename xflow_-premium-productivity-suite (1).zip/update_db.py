import re

with open('app/src/main/java/com/example/data/Database.kt', 'r') as f:
    content = f.read()

# Add overtimeSeconds to Schedule
content = content.replace(
    'val isRunning: Boolean = false,',
    'val isRunning: Boolean = false,\n    val overtimeSeconds: Int = 0,'
)

# Add OvertimeEntry entity
overtime_entity = """
@Entity(tableName = "overtime_entries")
data class OvertimeEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val scheduleId: Int,
    val subject: String,
    val overtimeSeconds: Int,
    val date: Long
)
"""
content = content.replace(
    '@Entity(tableName = "study_plans")',
    overtime_entity + '\n@Entity(tableName = "study_plans")'
)

# Add queries to XFlowDao
dao_queries = """
    @Query("UPDATE schedules SET elapsedSeconds = :elapsed, isRunning = :running WHERE id = :id")
    suspend fun updateScheduleProgress(id: Int, elapsed: Int, running: Boolean)

    @Query("UPDATE schedules SET overtimeSeconds = :overtime WHERE id = :id")
    suspend fun updateScheduleOvertime(id: Int, overtime: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOvertimeEntry(entry: OvertimeEntry)

    @Query("SELECT * FROM overtime_entries ORDER BY date DESC")
    fun getAllOvertimeEntries(): Flow<List<OvertimeEntry>>
"""
content = content.replace(
    '    @Query("UPDATE schedules SET elapsedSeconds = :elapsed, isRunning = :running WHERE id = :id")\n    suspend fun updateScheduleProgress(id: Int, elapsed: Int, running: Boolean)',
    dao_queries
)

# Update database version and entities array
content = content.replace(
    'version = 4',
    'version = 5'
)
content = content.replace(
    'entities = [Schedule::class, HistorySession::class, StudyPlan::class, StudyPlanItem::class]',
    'entities = [Schedule::class, HistorySession::class, StudyPlan::class, StudyPlanItem::class, OvertimeEntry::class]'
)

with open('app/src/main/java/com/example/data/Database.kt', 'w') as f:
    f.write(content)
