import re

with open('app/src/main/java/com/example/service/TrackingService.kt', 'r') as f:
    content = f.read()

# Replace the condition around online tracking
new_tracking_logic = r"""                    if (schedule.isOnlineMode && schedule.selectedAppPackage != null) {
                        if (schedule.selectedAppPackage == currentApp) {
                            trackingAny = true
                            if (schedule.elapsedSeconds < targetTime) {
                                // increment elapsed
                                val newElapsed = schedule.elapsedSeconds + 1
                                db.dao().updateScheduleProgress(schedule.id, newElapsed, true)
                                titleText = "Tracking: ${schedule.subject}"
                                contentText = "Time: ${String.format("%02d:%02d", newElapsed / 60, newElapsed % 60)} / ${String.format("%02d:%02d", targetTime / 60, targetTime % 60)}"
                            } else {
                                // elapsed is at target, increment overtime
                                val newOvertime = schedule.overtimeSeconds + 1
                                db.dao().updateScheduleOvertime(schedule.id, newOvertime)
                                titleText = "🔥 Overtime: ${schedule.subject}"
                                contentText = "Extra time: ${String.format("%02d:%02d", newOvertime / 60, newOvertime % 60)}"
                            }
                        } else {
                            if (schedule.elapsedSeconds >= targetTime) {
                                // Exited app during overtime or right after finishing
                                db.dao().insertHistory(
                                    com.example.data.HistorySession(
                                        scheduleId = schedule.id,
                                        subject = schedule.subject,
                                        mode = if (isDuration) "Duration" else "Exact Time",
                                        date = System.currentTimeMillis(),
                                        timeStudiedSeconds = schedule.elapsedSeconds,
                                        completionPercentage = 100,
                                        status = "Completed"
                                    )
                                )
                                if (schedule.overtimeSeconds > 0) {
                                    db.dao().insertOvertimeEntry(
                                        com.example.data.OvertimeEntry(
                                            scheduleId = schedule.id,
                                            subject = schedule.subject,
                                            overtimeSeconds = schedule.overtimeSeconds,
                                            date = System.currentTimeMillis()
                                        )
                                    )
                                }
                                db.dao().deactivateSchedule(schedule.id)
                                sendAlertNotification(
                                    "Goal Reached \uD83C\uDF89",
                                    "You've completed your focus session for '${schedule.subject}'!",
                                    schedule.id + 2000
                                )
                            } else {
                                db.dao().updateScheduleProgress(schedule.id, schedule.elapsedSeconds, false)
                            }
                        }
                    } else if (!schedule.isOnlineMode) {"""

pattern = r'if \(schedule\.isOnlineMode && schedule\.selectedAppPackage != null\) \{.*?\} else if \(!schedule\.isOnlineMode\) \{'
match = re.search(pattern, content, flags=re.DOTALL)
if match:
    content = content[:match.start()] + new_tracking_logic + content[match.end():]

with open('app/src/main/java/com/example/service/TrackingService.kt', 'w') as f:
    f.write(content)
