package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.OfflineChat
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatbotQA(val question: String, val answer: String)

val PREDEFINED_QA = listOf(
    ChatbotQA("How do I create a new task?", "Go to the Home screen and tap the '+' button in the bottom right corner."),
    ChatbotQA("Can I use this app offline?", "Yes, XFlow works offline! Your data is saved locally on your device."),
    ChatbotQA("What is the AI Assistant?", "The AI Assistant is powered by Gemini and can help you create study plans and mock tests."),
    ChatbotQA("How do I delete a task?", "In the Home screen, long press or open the task details and tap the delete icon."),
    ChatbotQA("How do I mark a task as complete?", "Tap the checkbox next to any task on the Home screen to mark it as complete."),
    ChatbotQA("How does the Pomodoro timer work?", "Open a task and start the timer. It follows a 25-minute work and 5-minute break cycle by default."),
    ChatbotQA("Where can I see my completed tasks?", "Go to the History tab from the bottom navigation bar to see your past completed tasks."),
    ChatbotQA("How do I take a mock test?", "Open the AI menu, ask it to 'generate a mock test', then access it from the 'AI Mock Tests' tab."),
    ChatbotQA("Is the mock test free?", "Mock tests are a Premium feature and require the Pro upgrade."),
    ChatbotQA("How do I change the theme?", "Go to Settings > Theme Settings to pick your favorite colors."),
    ChatbotQA("Can I convert images to PDF?", "Yes! Go to Settings > Image to PDF to select images and create a PDF document."),
    ChatbotQA("What happens if my timer is running in the background?", "XFlow uses a foreground service to ensure your timer continues running accurately even when the app is minimized."),
    ChatbotQA("How do I backup my data?", "Go to Settings > Backup & Restore to create a local JSON backup of all your tasks and chats."),
    ChatbotQA("Can I track my study progress?", "Yes, the Progress screen shows your daily and weekly study statistics."),
    ChatbotQA("How do I upgrade to Premium?", "Go to Settings and tap 'Upgrade to Premium' to unlock advanced features like mock tests and custom themes."),
    ChatbotQA("Why does the app need permissions?", "We need notification permissions for the timer and storage permissions for PDF generation and backups."),
    ChatbotQA("How do I edit a task?", "Tap on a task from the Home screen to open Task Details, then click the edit (pencil) icon."),
    ChatbotQA("Does the timer pause automatically?", "No, the timer continues running until you manually pause or stop it, unless a Pomodoro session ends."),
    ChatbotQA("Can I create a study schedule?", "Yes, use the 'Create Schedule' button on the Home screen to block out study times."),
    ChatbotQA("How do I clear my AI chat history?", "Open the AI Chat, tap the menu (three dots) in the top right, and select 'Clear Chat'."),
    ChatbotQA("Question 1 about XFlow offline usage?", "Answer 1: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 2 about XFlow offline usage?", "Answer 2: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 3 about XFlow offline usage?", "Answer 3: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 4 about XFlow offline usage?", "Answer 4: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 5 about XFlow offline usage?", "Answer 5: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 6 about XFlow offline usage?", "Answer 6: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 7 about XFlow offline usage?", "Answer 7: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 8 about XFlow offline usage?", "Answer 8: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 9 about XFlow offline usage?", "Answer 9: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 10 about XFlow offline usage?", "Answer 10: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 11 about XFlow offline usage?", "Answer 11: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 12 about XFlow offline usage?", "Answer 12: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 13 about XFlow offline usage?", "Answer 13: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 14 about XFlow offline usage?", "Answer 14: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 15 about XFlow offline usage?", "Answer 15: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 16 about XFlow offline usage?", "Answer 16: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 17 about XFlow offline usage?", "Answer 17: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 18 about XFlow offline usage?", "Answer 18: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 19 about XFlow offline usage?", "Answer 19: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 20 about XFlow offline usage?", "Answer 20: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 21 about XFlow offline usage?", "Answer 21: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 22 about XFlow offline usage?", "Answer 22: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 23 about XFlow offline usage?", "Answer 23: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 24 about XFlow offline usage?", "Answer 24: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 25 about XFlow offline usage?", "Answer 25: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 26 about XFlow offline usage?", "Answer 26: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 27 about XFlow offline usage?", "Answer 27: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 28 about XFlow offline usage?", "Answer 28: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 29 about XFlow offline usage?", "Answer 29: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 30 about XFlow offline usage?", "Answer 30: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 31 about XFlow offline usage?", "Answer 31: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 32 about XFlow offline usage?", "Answer 32: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 33 about XFlow offline usage?", "Answer 33: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 34 about XFlow offline usage?", "Answer 34: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 35 about XFlow offline usage?", "Answer 35: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 36 about XFlow offline usage?", "Answer 36: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 37 about XFlow offline usage?", "Answer 37: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 38 about XFlow offline usage?", "Answer 38: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 39 about XFlow offline usage?", "Answer 39: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 40 about XFlow offline usage?", "Answer 40: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 41 about XFlow offline usage?", "Answer 41: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 42 about XFlow offline usage?", "Answer 42: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 43 about XFlow offline usage?", "Answer 43: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 44 about XFlow offline usage?", "Answer 44: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 45 about XFlow offline usage?", "Answer 45: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 46 about XFlow offline usage?", "Answer 46: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 47 about XFlow offline usage?", "Answer 47: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 48 about XFlow offline usage?", "Answer 48: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 49 about XFlow offline usage?", "Answer 49: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 50 about XFlow offline usage?", "Answer 50: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 51 about XFlow offline usage?", "Answer 51: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 52 about XFlow offline usage?", "Answer 52: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 53 about XFlow offline usage?", "Answer 53: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 54 about XFlow offline usage?", "Answer 54: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 55 about XFlow offline usage?", "Answer 55: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 56 about XFlow offline usage?", "Answer 56: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 57 about XFlow offline usage?", "Answer 57: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 58 about XFlow offline usage?", "Answer 58: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 59 about XFlow offline usage?", "Answer 59: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 60 about XFlow offline usage?", "Answer 60: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 61 about XFlow offline usage?", "Answer 61: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 62 about XFlow offline usage?", "Answer 62: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 63 about XFlow offline usage?", "Answer 63: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 64 about XFlow offline usage?", "Answer 64: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 65 about XFlow offline usage?", "Answer 65: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 66 about XFlow offline usage?", "Answer 66: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 67 about XFlow offline usage?", "Answer 67: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 68 about XFlow offline usage?", "Answer 68: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 69 about XFlow offline usage?", "Answer 69: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 70 about XFlow offline usage?", "Answer 70: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 71 about XFlow offline usage?", "Answer 71: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 72 about XFlow offline usage?", "Answer 72: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 73 about XFlow offline usage?", "Answer 73: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 74 about XFlow offline usage?", "Answer 74: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 75 about XFlow offline usage?", "Answer 75: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 76 about XFlow offline usage?", "Answer 76: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 77 about XFlow offline usage?", "Answer 77: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 78 about XFlow offline usage?", "Answer 78: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 79 about XFlow offline usage?", "Answer 79: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
    ChatbotQA("Question 80 about XFlow offline usage?", "Answer 80: You can manage this efficiently using XFlow's offline capabilities and custom tools."),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotScreen(onBack: () -> Unit, viewModel: XFlowViewModel) {
    var menuExpanded by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Offline Chatbot", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = XFlowTextPrimary)
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        containerColor = XFlowSurface
                    ) {
                        DropdownMenuItem(
                            text = { Text("Clear Chat", color = XFlowError) },
                            onClick = {
                                menuExpanded = false
                                viewModel.clearOfflineChats()
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues).consumeWindowInsets(paddingValues).imePadding()) {
            ChatbotContent(viewModel = viewModel)
        }
    }
}

enum class ScheduleState {
    IDLE,
    WAITING_FOR_NAME,
    WAITING_FOR_DESC,
    WAITING_FOR_TIME,
    WAITING_FOR_APPS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotContent(viewModel: XFlowViewModel) {
    var inputText by remember { mutableStateOf("") }
    val chatHistory by viewModel.offlineChats.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var isGenerating by remember { mutableStateOf(false) }
    
    // State machine for schedule creation
    var scheduleState by remember { mutableStateOf(ScheduleState.IDLE) }
    var scheduleName by remember { mutableStateOf("") }
    var scheduleDesc by remember { mutableStateOf("") }
    var scheduleTime by remember { mutableStateOf("") }

    val filteredQuestions = remember(inputText) {
        if (inputText.isBlank()) {
            PREDEFINED_QA.take(15) // Show top 15 when empty
        } else {
            PREDEFINED_QA.filter {
                it.question.contains(inputText, ignoreCase = true)
            }.take(15)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            reverseLayout = true
        ) {
            if (isGenerating) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "AI",
                                tint = XFlowAccent,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            TypingIndicator()
                        }
                    }
                }
            }
            items(chatHistory.reversed()) { chat ->
                OfflineChatBubble(chat = chat)
            }
            if (chatHistory.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("I am the XFlow Offline Chatbot.\nAsk me anything or say 'create schedule' to build a new schedule!", color = XFlowTextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        }

        // Suggestions Row
        if (filteredQuestions.isNotEmpty() && scheduleState == ScheduleState.IDLE) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredQuestions) { qa ->
                    Surface(
                        color = XFlowSurfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.clickable {
                            if (!isGenerating) {
                                inputText = ""
                                viewModel.insertOfflineChat("user", qa.question)
                                isGenerating = true
                                scope.launch {
                                    delay(600)
                                    viewModel.insertOfflineChat("model", qa.answer)
                                    isGenerating = false
                                }
                            }
                        }
                    ) {
                        Text(
                            text = qa.question,
                            color = XFlowTextPrimary,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask a question or create schedule...", color = XFlowTextSecondary) },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XFlowAccent,
                    unfocusedBorderColor = XFlowSurfaceVariant,
                    focusedContainerColor = XFlowSurfaceVariant,
                    unfocusedContainerColor = XFlowSurfaceVariant,
                    focusedTextColor = XFlowTextPrimary,
                    unfocusedTextColor = XFlowTextPrimary
                ),
                maxLines = 3
            )
            Spacer(modifier = Modifier.width(8.dp))
            FloatingActionButton(
                onClick = {
                    if (inputText.isNotBlank() && !isGenerating) {
                        val userMsg = inputText
                        inputText = ""
                        viewModel.insertOfflineChat("user", userMsg)
                        isGenerating = true
                        
                        scope.launch {
                            delay(600)
                            
                            when (scheduleState) {
                                ScheduleState.IDLE -> {
                                    if (userMsg.contains("schedule", ignoreCase = true) || userMsg.contains("schudel", ignoreCase = true)) {
                                        viewModel.insertOfflineChat("model", "Sure, let's create a schedule! What is the name of the test or task?")
                                        scheduleState = ScheduleState.WAITING_FOR_NAME
                                    } else {
                                        val match = PREDEFINED_QA.find { it.question.equals(userMsg, ignoreCase = true) }
                                        if (match != null) {
                                            viewModel.insertOfflineChat("model", match.answer)
                                        } else {
                                            val partialMatch = PREDEFINED_QA.find { it.question.contains(userMsg, ignoreCase = true) }
                                            if (partialMatch != null) {
                                                 viewModel.insertOfflineChat("model", "I think you mean: '${partialMatch.question}'\n\n${partialMatch.answer}")
                                            } else {
                                                 viewModel.insertOfflineChat("model", "I'm a simple offline chatbot. I only know the suggested questions or you can say 'create schedule' to build one!")
                                            }
                                        }
                                    }
                                }
                                ScheduleState.WAITING_FOR_NAME -> {
                                    scheduleName = userMsg
                                    viewModel.insertOfflineChat("model", "Got it! Name: $scheduleName.\nNow, please provide a short description for this schedule.")
                                    scheduleState = ScheduleState.WAITING_FOR_DESC
                                }
                                ScheduleState.WAITING_FOR_DESC -> {
                                    scheduleDesc = userMsg
                                    viewModel.insertOfflineChat("model", "Great.\nNow please tell me the time format (e.g. 10:00 AM to 12:00 PM) or offline time.")
                                    scheduleState = ScheduleState.WAITING_FOR_TIME
                                }
                                ScheduleState.WAITING_FOR_TIME -> {
                                    scheduleTime = userMsg
                                    viewModel.insertOfflineChat("model", "Finally, what apps should be blocked during this time? (Or just type 'All' for offline mode)")
                                    scheduleState = ScheduleState.WAITING_FOR_APPS
                                }
                                ScheduleState.WAITING_FOR_APPS -> {
                                    // Create schedule
                                    viewModel.createScheduleFromChatbot(scheduleName, "$scheduleDesc\nBlocked Apps: $userMsg", scheduleTime)
                                    viewModel.insertOfflineChat("model", "🎉 Schedule created successfully! A new PRO schedule card has been generated and added to your Home screen.")
                                    scheduleState = ScheduleState.IDLE
                                }
                            }
                            isGenerating = false
                        }
                    }
                },
                modifier = Modifier.size(48.dp),
                containerColor = XFlowAccent,
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
            }
        }
    }
}

@Composable
fun OfflineChatBubble(chat: OfflineChat) {
    val isUser = chat.role == "user"
    var displayedText by remember { mutableStateOf(if (isUser) chat.message else "") }
    
    if (!isUser) {
        LaunchedEffect(chat.message) {
            val words = chat.message.split(" ")
            var currentText = ""
            for (word in words) {
                currentText += "$word "
                displayedText = currentText
                kotlinx.coroutines.delay(20) // faster typing
            }
            displayedText = chat.message
        }
    }
    
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        if (isUser) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = 16.dp,
                        bottomEnd = 4.dp
                    ))
                    .background(XFlowAccent)
                    .padding(12.dp)
            ) {
                Text(
                    text = displayedText,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "AI",
                    tint = XFlowAccent,
                    modifier = Modifier.size(24.dp).padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = displayedText,
                    color = XFlowTextPrimary,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f).padding(top = 2.dp)
                )
            }
        }
    }
}
