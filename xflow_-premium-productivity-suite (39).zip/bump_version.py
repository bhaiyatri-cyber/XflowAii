with open('app/build.gradle.kts', 'r') as f:
    content = f.read()
content = content.replace('versionCode = 67', 'versionCode = 68').replace('versionName = "67.0"', 'versionName = "68.0"')
with open('app/build.gradle.kts', 'w') as f:
    f.write(content)
